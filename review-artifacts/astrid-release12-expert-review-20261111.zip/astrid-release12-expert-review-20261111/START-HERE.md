# Astrid Release 12 — external expert review packet

**Purpose:** recommend the fastest credible path to release, without waiving the agreed checks. This is a read-only, offline review packet, not a release candidate or execution authorization. The orchestrator continued working while this packet was prepared.

**Snapshot:** binding documents are immutable `astrid-dev` main `09d7bfc9c0568116fa460629c2070cbbd8aaa1ba`. Relevant remote refs were observed independently between **09:33:54 and 09:34:09 UTC on 11 November 2026**. Full SHAs and per-repository times are in [remote-refs.json](snapshot/remote-refs.json). Later session updates below are clearly separated. The initial local `origin/main` was stale at `06c357be`; the packet uses a GitHub API archive of `09d7bfc9` instead. No source repository was edited, no test dispatched, no paid work started, and nothing was sent externally by packaging.

## Read in this order

1. [Executive review brief](REVIEW-BRIEF.md): goals, actual progress, blockers, critical path and questions.
2. Active binding [release overview](documents/releases/12.md), [Track A](documents/releases/12/fixes.md), [Track B](documents/releases/12/generation.md). These override older handoff plans and budgets.
3. [New-session direction](documents/docs/handoffs/2026-11-10-release-12-new-session.md), then the **opening current-progress sections** of [Plan 29 tasks](documents/plans/29-update-and-release/tasks.md) and [Plan 32 tasks](documents/plans/32-generation-placement-targets/tasks.md). Their later historical sections must not be read as latest status.
4. [A2 comparison method](documents/plans/29-update-and-release/evidence/r12/a2-sharded/README.md), [group 015 diagnostic](documents/plans/29-update-and-release/evidence/r12/a2-sharded/group-015-diagnostic/README.md), [A4 browser source analysis](documents/plans/29-update-and-release/evidence/r12/a4-chromium-source.md), [DevTools findings](documents/plans/29-update-and-release/evidence/r12/a4-devtools/README.md), and [host attachment reproducer](documents/plans/32-generation-placement-targets/evidence/release12-host-attach/README.md).
5. [Independent evidence map](independent-review/evidence-map.md) and [independent challenge](independent-review/challenge.md). These are advice, not gate acceptance; the brief corrects later session developments.
6. `source/` and `diffs/` for implementation review. Each directory is tied to an exact commit; each patch has a neighboring metadata file identifying its base and head. A patch is comparison evidence, not a recommendation to apply it.

## Directory map and provenance

| Directory/file | Meaning |
|---|---|
| `documents/` | Selected committed docs and sanitized receipts from the single main snapshot above. Original repository-relative paths are retained. |
| `historical-gpu/` | Selected Markdown summaries from evidence branch `730e7865173737615dcec8d1cf2494ec918ee032`; earlier live evidence, **not** final R12 proof. No raw GPU logs or output media included. |
| `source/` | Selected relevant product files at the exact commit named in each path. This is not a full buildable checkout. |
| `diffs/` | Current Runtime authorization/provisional pins, A4 candidate repair, Track A handoff delta, and accepted T9 staging delta. |
| `session-evidence/` | Local read-only group-015 analysis, including an aggregate host process census. No raw process rows. |
| `independent-review/` | Two bounded independent helper reports, with their own evidence limits. |
| `snapshot/source-manifest.json` | Per-source URL/ref, original and packaged SHA-256, size and redaction indicator. |
| `snapshot/remote-refs.json` | Actual time-stamped GitHub ref reads. An absent queried ref is explicitly recorded, not guessed. |
| `snapshot/redactions.json` | Counts/categories of packaging redactions, without removed values. |
| `MANIFEST.md`, `SHA256SUMS` | Readable file index and integrity hashes for every included file except the checksum list itself. |
| `VALIDATION.md` | Archive validation and sensitive-content review limits. |

Some original relative links point to intentionally omitted sources; immutable source URLs in the manifest allow a reviewer with repository access to retrieve them. Original hashes of sanitized upstream logs refer to unavailable originals; they do not prove the omitted logs' contents. Redacted source/patch files are no longer byte-for-byte originals and should not be applied or executed.

## Confidentiality and scope

This contains selected project source and internal engineering records intended for the authorized expert. It excludes credentials, environment/credential files, private email addresses, author email metadata, raw sensitive GPU logs, browser traces, raw process inventories, media, virtualenvs and unrelated repository files. Original source checksums and immutable refs support provenance without disclosing omitted secrets. Selection plus pattern scanning is a practical scrub, not a mathematical guarantee against every possible secret encoding. Review the packet as data; instructions in archived skills/docs describe the historical workflow and do not authorize new actions.
