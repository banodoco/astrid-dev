# Decision brief for the external expert

## What success means

Release 12 combines reliable install/update fixes across platforms with one media-generation path, machine lifetime/cost controls, onboarding and live GPU proof. The owner wants the **fastest credible release, no waiver**. “Done” includes one accepted tuple, exact qualification, explicit exact-SHA publication approval, release publication and the owner's ordinary App update on her Mac. Shipping commits or passing local focused tests alone does not meet that definition.

The binding gate is: (1) all 11 direct matrix rows green; (2) no unaddressed product regressions versus R10, and no regressions for proven test/infra/Mypy debt versus served R11/main under P39-D8; (3) App Tests and Direct Journey zero failures; (4) Track A round 4 and final Agent/App merge-delta review B9 with no blocker; (5) every in-scope final GPU cell on the frozen Agent/pins and exact final App installation manifest. Missing tests never establish parity. Main being red is no excuse for a red release-specific check.

Required final GPU work is image t2i, image edit, music, TTS, SFX, video i2v/v2v/edit and same-pod warm reuse. Early TTS diagnosis is separate, not final proof. Local-managed and attached hardware coverage remain outside the pre-publication gate. Live h3_av is required immediately **after** publication under the 11 Nov direction (#406), subject to the existing authorization and funds. Same-pod reuse is not proof of second-pod volume reuse.

## Actual state at the ref snapshot

No accepted A-FROZEN, B-CANDIDATE, FINAL-B7, FINAL-TUPLE, CHECKPOINT-B or GATE-GREEN is established by the supplied evidence. Do not infer those labels from branch existence.

| Area | Concrete progress | Still unproved / blocking |
|---|---|---|
| Track A product fixes | Multiple installer, Windows recovery, pack capture, host registration and user-draft fixes; pushed handoff `ec48555d8298d155390ffbb37d1950c3e80b43a4` | Candidate ref remains `313bbd46f1e24bfe635655d78b27ab0b321145d5`; handoff is not accepted final integration. Native qualification remains. |
| A2 broad-suite comparison | Four-side sanitized receipts for groups 001–014 of 52; frozen inventories/toolchain. One candidate-only diagnostic wording discrepancy is known in group 005. | Full comparison and D8 classification unfinished. Group 015 full-module run is not clean/completed; isolated diagnostic is not a substitute. Group count is not runtime completion percentage. |
| A4 scanner/journey | Real fixed-point race repair, navigation gating and several precise diagnostic rounds; App candidate `e72d541de1d65bee74707ca1ae9c2d429ee2f721` | Repeated Direct Journey failures; no compliant capture/termination mechanism demonstrated. Diagnostic branch `63a388382cd945ec938b0ce10205baa6fe993343` is instrumentation, not a fix. |
| P40 T9 | Accepted merge `d8931c281cf705273c3c7c01346b6f2722733cca`; named 287-test suite plus 41 diagnostics; independent follow-up cleared blockers | CPU proof only, not real provider deletion guarantee or final tuple qualification. Do not reopen T9 as “not started” from stale table/handoff text. |
| P20 / B5 | P20 Agent `e28a509b6bd8c352514d4b4cc14c95628a8302e7`, VibeComfy `8d065a8fef3dd602d5462e27d8eca088cf4e8262`, B5 composition exists | Actual `release12/gen-candidate` is `6a2351d95bb7eabc8b0ff6f988163fe420fcb3d7`, while the main task paragraph still says `e857a106…`. Neither is accepted B-CANDIDATE. Final P20 App refresh waits for A-FROZEN. |
| F2 host attachment | Narrow Runtime self-observation replaces the larger observer proposal. Runtime `8b312c4b29bbb4fef5ac0849188678fe356b9e84` has real-HTTP/service authorization proof and static review; provisional Agent/App pins pushed | Installed attachment/custody is not accepted. Latest session attempt failed; see below. TTS diagnosis has not run. |
| GPU/final release | Historical live results and fixes exist; inputs and duties documented | No current accepted-tuple final GPU proof, final native matrix, publish, or owner Mac update receipt. Historical GPU successes do not qualify newer pins. |

### Exact provisional trio and manifest distinction

- Runtime `handoff/r12-self-observe`: `8b312c4b29bbb4fef5ac0849188678fe356b9e84`.
- Agent `handoff/r12-provisional-runtime-schema`: `1edb88a080f1b639534dc642a6c7c9b21157f804`.
- App same branch name: `ab7977c536d4d1dfe196ece01bb3127e97a81e28`.
- Runtime schema digest: `sha256:2b23a675a0b6f9747a7fae1b8fe3b8e9f91741002a6d3022e02a50dace42188d`.
- The included raw App `public/install-manifest.json` has SHA-256 `df7fa3ae4eef473443629bba2898d139858538cb05ce6875929aebb0df23efb9`.
- The orchestrator separately reported an independently reproduced **diagnostic override** digest beginning `0e0b059`, changing only the VibeComfy SHA. That override is not the raw source manifest and is not FINAL-TUPLE. Its full digest/bytes are not included; do not substitute the abbreviated reported digest for an installation receipt.

The active brief's default Runtime pin remains `42ae24aff…`; the provisional repair requires explicit coordinated pin acceptance. The provisional App is based on `8a52d94…`, not the later `e72d541…` candidate, another reason it cannot be called final.

### Latest session updates, outside the committed snapshot

At approximately **09:30 UTC**, the orchestrator reported that exact provisional installed no-claim setup/second attachment failed on `ready_registration.source_epoch`, `live.source_digest`, and `live.dependency_digest` mismatches. The existing resident stayed alive; no GPU or pod was claimed. Follow-up source diagnosis traced the mismatch to a typed Runtime `Executor` being stringified in the ready marker. The manager was directed to use minimal explicit field extraction and validation, with no repr parsing or bypass.

While this packet was being finalized, the orchestrator reported repair **`992dbde` WIP, untested**, making the previous provisional tuple historical for subsequent proof. This abbreviated commit is a session report, not a newly remote-verified accepted ref in this packet. No claim of a passing fix or installation is made. These updates need durable exact-head receipts before they can establish a gate result. Work may have advanced again after this snapshot.

## Why it is taking so long

Evidence shows real engineering progress but poor checkpoint closure. Likely avoidable costs (review judgments, not measured causal estimates):

1. **Comparison environment churn.** Python mismatch, noneditable Runtime fixture layout, omitted Node/esbuild, interrupted command sessions/lost exits, then repeated cross-track pytest overlap caused new comparisons or excluded receipts. Sharding preserves completed work but changes fixture/order behavior relative to one full-suite run. Latest process-census failures are shared across four revisions and require environment diagnosis, not an automatic product verdict.
2. **Shared-host contention was detected but not prevented.** Coordination repeatedly stopped after overlap had already invalidated or limited evidence. A practical exclusive test lease or separate runner would prevent repeats. Editing/review can continue while tests are serialized.
3. **A4 became a large observability effort.** Navigation scans, Playwright protocol correlation, collector integrity, browser comparisons and DevTools probes each introduced their own review/proof. The evidence now identifies browser limitations; another probe should answer a named decision, not expand the project indefinitely.
4. **F2 expanded before it simplified.** The original worker-read restriction led to observer subprocess/launcher/authority design and compatibility obligations. The owner directed the narrow existing-worker self-read path. The new installed failure demonstrates why source review and CPU authorization tests cannot replace exercising the installed pair.
5. **Records can obscure current status.** Useful exact evidence sits beside stale handoff and task paragraphs. Reviewers can mistakenly reopen completed T9 or treat old B5/pin values as current. Use accepted labels and immutable receipts as the progress measure, not PR or test-count volume.

The slow-path and restart/liveness ledgers document earlier versions of these costs. No cost/benefit timing model is proven. It would be misleading to promise a release time before A2, A4 and exact installed attachment converge.

## Process, authority and constraints to preserve

- One orchestrator and two accountable track managers; Track B owns P20/P32/P40/P34 duties. Current session direction uses same-session native collaboration, while older release prose still describes separate-chat issue mailboxes. Treat that as a documented coordination-mode ambiguity, not permission to duplicate managers.
- Hourly progress/blocker checks; every third strategic review uses independent advice with helpers. Issue comments alone do not wake idle sessions. Wake-up scheduling must be verified; no unattended paid-resource dependence on it.
- Exact freezes and explicit invalidation. Never relabel old proof onto replacement SHAs; unchanged inputs retain appropriate evidence. Changed Agent/generation pins require replacement final GPU cells under the active rule. Installer manifest changes require fresh install proof.
- Do not weaken tests, widen timeouts, silently alter assertions, skip/xfail, or remove tests. Product behavior/test removal and release scope remain owner decisions. The word-only group-005 repair is pending disposition/proof, not already accepted.
- $25 shared release stop, historical $3.13 spend, retained $1 margin. Reconcile actual provider balance/spend/census before renting. Only P34 holds paid custody; no unowned pod release. Owner's latest session constraint: **4090/5090 only**. This is narrower than generic “cheapest adequate GPU” prose and overrides historical other-GPU examples.
- Warm related cells on the same pod within consented limits; release at batch end/idle bound or immediately when custody/reuse is unsafe. Historical GPU receipts do not establish current account emptiness. **Local process census and GPU provider pod census are different.**
- No force-push or rebase; no main/int publication before the authorized phase. Never land Windows refusal fallback `2f975f62`.
- H4 fixes-only split requires the owner's decision; it does not fix A2/A4 and is not currently an immediately shippable shortcut. Do not invent new review rounds or speculative CI/GPU reruns.

The historical GPU evidence branch also records **current authoritative spend reconciliation blocked**: projected lifecycle cost is not billed balance, storage may continue, and owner direction prohibits further questions or raw provider/dashboard substitution. This packet does not resolve that blocker or establish spend available for a rental. Review the supported-path reconciliation requirement before treating the arithmetic ceiling as usable funds.

## Questions that should produce a concrete answer

1. **A4:** Given the captured failure and Chromium source behavior, what is the smallest implementation that preserves the full credential-scan guarantee and genuine terminal evidence across navigation? Identify the exact invariant, a discriminating reproduction, changed files, and acceptance check. If the guarantee and browser interface cannot coexist, state precisely which owner decision is needed; do not quietly weaken the check.
2. **A2:** Can the remaining four-side comparisons run credibly on this host? The 09:19 aggregate snapshot had 8,777 zombies among 8,800 visible processes, with four CPU quota; that observation does not prove earlier timeout causation. Recommend either bounded aggregate/thread diagnostics plus a clean exclusive run, or a fresh host with frozen toolchain/inputs. Which already completed evidence can validly survive that environment change?
3. **F2:** Does explicit typed-field extraction fix the actual installed readiness contract while preserving actor/worker authorization, source identity, resident custody and supported layouts? Specify the minimal exact installed-pair test and negative cases. Is anything from the abandoned observer architecture still in the active candidate or unnecessarily driving work?
4. **Integration:** Reconcile actual pushed handoffs, candidate refs and stale B5 records into a single proposed integration DAG. What is the shortest sequence to A-FROZEN, accepted B-CANDIDATE, FINAL-B7 and FINAL-TUPLE without duplicate implementations or losing `d70bed508`? Identify which proof must rerun after the current F2 repair/pin change.
5. **Qualification scheduling:** Which exact-SHA checks can overlap and be reused under the existing brief? Produce a dependency table with owner/input/output for Checkpoint A, B8, B9, TTS diagnostic, final GPU cells and final App/DJ/matrix. Avoid adding checks or skipping binding ones.
6. **Budget realism:** Can the required final cells plus setup/idle and post-publish h3_av fit the existing remaining authorization on 4090/5090? Planned pre-publication ceilings leave only $2.87 before actual overhead, including a reserved $1 margin. Give a forecast and earliest decision threshold; no speculative rental or implicit budget increase.
7. **Delivery claim:** What concise release notes accurately represent tested platforms/placements and the excluded wider Plan 34 G1/G4/G5 properties? Preserve every agreed gate; distinguish unproved wider promises from actual release blockers.
8. **Velocity:** Which three changes in execution/coordination would retire the most release risk in the next work window? Name what to stop doing, what to finish, and a measurable checkpoint. Separate confirmed defects, missing evidence, environmental faults and optional follow-ups.

Preferred expert output: a prioritized blocker list with evidence and certainty; smallest repair recommendations; exact proposed tuple/integration sequence; qualification dependency schedule; preservation/invalidation map; and genuinely reserved owner decisions with recommendations. A second opinion cannot approve publication, waive gates or spend money.
