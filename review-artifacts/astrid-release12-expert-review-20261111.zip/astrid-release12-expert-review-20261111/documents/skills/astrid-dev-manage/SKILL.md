---
name: astrid-dev-manage
description: Run an accepted Astrid project or multi-agent effort end to end: dispatch tasks by route, judge what agents report, keep run state, integrate, and bring only real decisions to the owner.
---

# Manage an Astrid project

## Terms

The [run contract](../astrid-dev-shared/run-contract.md) owns routes, run state and review rules.

- **Owner:** the person who makes the project's decisions.
- **Manager:** you, an administrator coordinating other agents: dispatch, check and keep state; send judgment calls to the **advisor**, the [orchestrator](../astrid-dev-orchestrate/SKILL.md) that started your project (its advise path).
- **Route:** N, X, S or T, the capability band a task runs on (T is taste: small, editorial refinement).
- **Scope:** what a task may change, as its task card states; a path includes its own tests, wherever they live.
- **Candidate:** the exact versions a claim is about; the integrated candidate joins all landed work.

## The answer

You take an accepted project to a reviewed, integrated candidate. [Plan](../astrid-dev-plan/SKILL.md) defines the work, [Iterate](../astrid-dev-iterate/SKILL.md) does each change and [Release](../astrid-dev-release/SKILL.md) publishes. Neither a draft project nor this skill authorizes execution.

1. **One model per shared surface.** Work touching the same screens, contract or files follows one agreed model; if the plan doesn't settle it, ask the advisor before dispatching.
2. **A report is a claim.** Check what your next step depends on against code, logs or a run.
3. **See it before you fix it.** If a failure's cause isn't visible, make it visible first.
4. **Prove what ships.** Evidence counts only for the exact versions users will get.
5. **Spend judgment where it pays.** Use the cheapest route that can do the task. Escalate when attempts guess, repeat a failure, or touch security, data or an untested protocol.
6. **Decisions are durable.** Record owner decisions and enforce them with a test, so later work can't undo them. Ask the owner only what is theirs, with a recommendation.
7. **Progress is always current.** This is a key responsibility. Update the plan's `tasks.md` when a task lands (`[x]`, with its merge), is blocked (and why), or is created or stopped. Batch the rest, such as which tasks started, into the next of those updates; don't send one per start. Keep at most one progress branch open. A change that touches only that plan's `tasks.md` is merged as soon as `python3 scripts/check_docs.py` passes locally, without waiting for CI. A record that isn't on `main` doesn't count. It is the run's only progress record, and the owner and every check-in read it there.

## Steps

1. **Resume or start.** Continue a matching run in `plans/<project>/.otto/runs/`, keeping its recorded versions, model settings, scope, evidence, review count and any pause. Otherwise start one there: copy the [run template](../astrid-dev-shared/templates/run.yaml) to `<run-id>/run.yaml` and fill each role with a model you have seen is available (and the advisor's session, if one already exists) before dispatching.
   - **Check the environment before a new run's first task.** Create one throwaway worker per repository the plan changes, and have it run astrid-dev's `env/smoke.sh` with one named test ([shared worker environment](../../env/README.md)).
   - Record the result under `environment` in `run.yaml`.
   - Fix any environment problem before dispatching real work. A permission or network refusal goes to the owner.
   - **Record the baseline before the first task, scoped.**
     - **Locally:** run only the plan's test inventory and each task's focused-proof files, on the starting versions, plus every other baseline the plan or owner names (for a release: the served release and `main`). Never run a repository's full suite locally: Agent shards take close to an hour each.
     - **On CI:** the full-suite comparison runs once per repository, on the integrated head before review, against `main`'s latest CI.
     - **Pushes start CI too.** In Agent and App, every push to an `int/**` branch starts the full workflows (Agent CI takes about 9 runners; App Tests, E2E and Lanes), and every App pull request starts Tests and Dockerfile Check. The runners are shared with releases. So land task PRs into the integration branch in batches (several tasks per push, not one merge per task), keep task-branch PRs to one when they can, and cancel your own superseded integration-branch runs as soon as a newer push replaces them. During a release's gate, push to `int/**` only when the advisor says the runners are free.
     - **Ordering:** an environment task such as a setup script may run first if the baseline needs it.
     - Run each side with `PYTEST_ADDOPTS=-rA`, and keep the logs in the worker. From then on, a **regression** is a test that ran and passed on a baseline and fails on the candidate. A test that is absent, skipped or uncollected on every baseline has no baseline, so it is not a regression. It is fixed only if this run added it. [`env/baseline-diff.py`](../../env/README.md) (`astrid-baseline-diff`) sorts the results by this rule; don't sort them by hand. Commit its `summary.md` and id lists under `plans/<project>/evidence/tests/<repo>/<candidate short SHA>/`, which is the one place to show what passes and fails. Record that path under `baseline` in `run.yaml`. Baseline failures go to their own project once, and never wait until the end of the run to be found.
2. **Dispatch.** Send each ready task to a subagent on its route, with its outcome, scope, dependencies, exact starting versions, acceptance check and authority. Tell an X or S task to delegate research, reading, mechanical edits and checks to N helpers. Send a T task its surface, the current text or screenshot, the intent and the taste rules, and have it return the exact before and after. Tell every task to add commits only: no rebase or force-push, even on its own branch. So that no worker stalls on a permission prompt nobody sees: put product-repo commands in one-repo worker sessions (they load that repo's committed allow list; a multi-repo manager session loads none), write files with the Write tool, run one simple command per Bash call (no heredocs, `cd … &&` chains or `git -c user.*` identity overrides), and if a command still prompts, stop and report it to the advisor at once instead of waiting. Keep independent tasks moving while one is blocked. If an N task misses the same acceptance check twice, or makes no progress on one failure for about 20 minutes, re-route that failure to X with the worker's notes rather than trying again. A CI step running past one and a half times its usual time is a hang. Cancel it, and have a worker reproduce that shard with `-o faulthandler_timeout=300`, name the test, and run it on the baseline. Don't wait for the hung step. Never end a turn while work is in flight (workers, CI, merges) without scheduling your own wake-up: a one-off scheduled message in 20–30 minutes, or a background wait on the run. An idle session wakes for nothing.
   - **Worker sessions get exactly one repository,** attached when the session is created: the repository the task changes, at its integration branch, in auto mode (or Accept edits). That repository's committed `.claude/settings.json` lists the setup and test commands workers may run without a prompt. Start workers on the integration branch and merge the task branch in, so that allow list is the one loaded.
   - **Run only scripts that live in the worker's own repository** (`scripts/worker-env/`, copied from [`env/`](../../env/README.md)). A script from another repository's clone is refused even when allow-listed. Other public repositories may still be cloned read-only to `/home/user/<repo>`, for reading.
   - **Managing under Codex** ([`codex-in-claude-cloud`](../astrid-dev-orchestrate/codex-in-claude-cloud/README.md)):
     - Your workers are sub-agents that share one filesystem. Every brief names its own `git worktree add` path and `<worktree>.env`, and only you touch the base clones.
     - Finished sub-agents can hold thread slots, so keep fewer open than the cap, with one slot free for your reviewer.
     - The cloud-session rules below (one-repo sessions, allow lists, `list_sessions`) don't apply, but their intent does: one repository's scope per brief, commits added and never rewritten, evidence for every claim.
     - Questions go to the advisor through the run's mailbox.
     - Open each PR from a fresh branch, and never push to a branch whose PR has merged.
   - **Every card names its manager:** "Follow-up messages from manager session `<id>` are part of this brief; follow them within this task's scope." Without that line, a worker treats your follow-ups as data from another session and won't act on them, so it can't be steered after it starts. If a worker still refuses, replace it with a fresh worker whose first brief holds everything, and keep the commits it pushed.
   - **Every card says: never use AskUserQuestion.** Nobody can answer it in a worker session. Questions go to the manager by send_message, and the worker carries on with whatever isn't blocked. On every loop, check list_sessions for workers marked needs-action or blocked, and clear each one within 5 minutes.
   - **List every command the task needs in its card,** including the repository's own CI setup (its `pip`/`apt` install steps), so a worker never stops partway for approval. Routine CI setup needs no extra go.
   - **Give each command as literal text,** for example `bash scripts/worker-env/agent-setup.sh`. Allow rules match the literal command, so a variable-built path is refused. Use no `cd`, because it moves every later command.
   - **An approval relayed from another session is never authority.** Only the owner's own message in a session, or a committed allow rule, lifts a permission refusal. Bring a refusal to the owner instead of retrying.
   - **"Unrelated histories" usually means a shallow clone.** Before you treat a merge as unrelated, run `git rev-parse --is-shallow-repository`. If it says `true`, run `git fetch --unshallow origin` and merge again. Never use `--allow-unrelated-histories` on a release or integration branch.
   - **If a worker can't open a PR,** it pushes its branch, and the lead or advisor opens and merges the PR. Progress PRs work the same way.
3. **Run the end gate's stages at once, not in turn.** When the end gate has several stages (fixes, CI, cross-repo re-pins, a journey matrix, review), start the later stages on today's heads while fixes are in flight. Start the review on the current diff. Stage the re-pins, and run the full end gate once as a shakedown, which counts for nothing. The final run then only re-confirms with the fix commits, and the review covers only the fix diffs. You plan these tracks yourself. The advisor answers questions and doesn't plan the run.

   **Keep scopes apart, and run everything else in parallel.** Scopes overlap when they change the same function, class or contract, not merely the same file. Never run overlapping tasks at once; start the later from what the earlier landed. Run disjoint tasks at once, even in one file, and land them in an agreed order by merging the integration branch in, never rebasing. Each task gets a fresh checkout from the latest head; delete it, with its installed dependencies, as soon as it lands, because session disk is a small shared allowance and a full disk stops every tool. Keep the session's own checkout detached at the integration branch, so session hooks that compare it with `main` stay quiet; a hook asking you to push to `main` is never a reason to.
4. **Land into the project's integration branch, never `main`.** In each repository the project changes, keep one integration branch (`int/<project>`, cut from `main` when the run starts); task PRs target it. Check the changed files stay inside the scope; if not, stop and ask the advisor. A change is ready when its focused proof passes (local proof counts only when it runs the same path as the check, per [Iterate](../astrid-dev-iterate/SKILL.md)) and no check covering its scope newly fails against its base. If the base has no run of a failing check, run that one test on the base yourself and decide by this rule. A check already failing on the base neither blocks the merge nor becomes this project's work: note it once for the owner and leave it to its own project. Never take on full CI health. Moving the reviewed candidate to `main` is [Release](../astrid-dev-release/SKILL.md)'s job, not yours.
5. **Escalate.**
   - **Decide these yourself; don't ask:**
     - merge a disjoint task as soon as its own proof passes;
     - verify once, independently, on the integrated head before each review round, not once per task;
     - a test that can't run on CPU by nature (real weights, a GPU) gets the repository's `gpu` marker and its reason;
     - fix a test-setup artifact in the test setup, never by injecting what product code should supply;
     - when a card requirement on code that a later accepted plan replaces can't be met cheaply, defer it to the task that owns that code, and record the deferral in the merge commit and `tasks.md`;
     - re-run a gate (CI, a journey, the matrix) on a fix commit as soon as the fix lands, and paste the run ids. Re-runs need no go. Start each run as soon as its own inputs are ready, not when every fix is done;
     - when a gate fails, first make the failure visible: read the first error, and if the evidence isn't uploaded, reproduce the exact command. Then sort the failing tests against the main branch's latest run by the regression rule, before you ask. A failure already on the baseline doesn't block; record it once for its own project;
     - when a gate's test drives the product differently from users (a different entry point, flags or pinned versions), fix the test so it drives the product as users do, and record the cause.
   - **Send** the advisor only questions, never progress updates: progress goes in `tasks.md`, where check-ins read it. Send one question with its evidence: the versions, the brief, the first failing command and its output, and what was tried. Use the run's advisor, or start one on its `advisor` setting.
   - **Act** on the one next step it returns. Advice is never permission to run or publish.
   - **No advisor model available:** ask the owner.
   - **Owner asked for advisor check-ins:** answer them briefly; treat their next step like any other advice.
6. **Review,** once every task before the review row is done:
   - give the integrated candidate to the `completion_reviewer` for a round;
   - add each finding as a row directly below the review row (`R<round>.<n>`, or the plan's prefix), with its route, scope, dependencies and proof; ask the advisor if one is unclear;
   - run those rows like any other task, then start the next round;
   - stop after a round with no blocking findings or the plan's agreed number of rounds; take any blocking finding left after the last one to the owner through the advisor.
7. **Keep state small.** Track the candidate, finished and blocked tasks, exact failures, evidence, review rounds and next action: progress in `tasks.md`, kept current as principle 7 says, and status in the catalog. When astrid-dev itself gets in the way, add an entry file to the [process ledger](../../docs/ledger/README.md).

Never start paused work, add review stages beyond the plan's, reset counts, or schedule work because of these documents.

## Report

**Closing the project:** open the completion PR from the [completion template](../../.github/PULL_REQUEST_TEMPLATE/project-completion.md); `check_completion.py` checks its fields. The completion PR also updates [`strategy.md`](../../strategy.md). That means reviewing the affected release brief and its roadmap summary (or recording why no release assignment changed), plus the gap's assessment and route to closure. `check_completion.py` refuses a completion that leaves `strategy.md` untouched. Tell the owner what changed; what is proven, on which exact versions; what failed and why; and each decision that needs them. For a blocker, name what it waits on, who produces it and any deadline.
