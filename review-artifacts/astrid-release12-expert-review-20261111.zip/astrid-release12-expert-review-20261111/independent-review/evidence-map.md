# Release 12 evidence map

Read-only review prepared 11 Nov 2026 09:33 UTC. Canonical documentation source: `origin/main` snapshot `09d7bfc9c0568116fa460629c2070cbbd8aaa1ba` (commit time 2026-11-11 10:25:47 +0100), independently preserved at `/workspace/r12-expert-review-inputs/dev-snapshot`. Product branch tips below were checked with `git ls-remote` at preparation time; they are live ref observations, not release acceptance. No repository files were changed.

## Findings

- **Release status:** still draft. Neither A-FROZEN/B-CANDIDATE nor FINAL-B7/FINAL-TUPLE/CHECKPOINT-B/GATE-GREEN is established in the active brief. Product work and focused proofs do not close the release gates.
- **Latest observed product refs:** Agent `handoff/r12-provisional-runtime-schema` = `1edb88a080f1b639534dc642a6c7c9b21157f804`; Runtime `handoff/r12-self-observe` = `8b312c4b29bbb4fef5ac0849188678fe356b9e84`; App `handoff/r12-provisional-runtime-schema` = `ab7977c536d4d1dfe196ece01bb3127e97a81e28`. This is a provisional cross-repo schema trio, not an accepted/installed tuple: the latest committed P32 record says coordinated Agent/App artifacts, exact installed attachment/custody proof, and renewed diagnostic authorization remain open. Runtime's narrow authorization tests and static review passed at 8b312c4, but do not prove installed attachment.
- **Release candidate refs remain older:** Agent `cand/29-r12` = `313bbd46f1e24bfe635655d78b27ab0b321145d5`; App `cand/29-r12` = `e72d541de1d65bee74707ca1ae9c2d429ee2f721`; Runtime `main` = `4f5477cb0f5b03d28bec991a1fe34edcd8fc309f`; VibeComfy `release12/vibecomfy` = `8d065a8fef3dd602d5462e27d8eca088cf4e8262`. Agent `release12/gen-candidate` currently resolves to `6a2351d95bb7eabc8b0ff6f988163fe420fcb3d7`.
- **Conflicting generation ref:** P32 `tasks.md` calls `release12/gen-candidate` `e857a106986e337491165305e103b78a304f8919`, but the live remote ref resolves to `6a2351d95bb7eabc8b0ff6f988163fe420fcb3d7`. Treat the task-record SHA as stale or unresolved until reconciled; neither is accepted B-CANDIDATE. The record also says the documented e857 candidate had unresolved pin/version mismatch and incomplete exact-head proof.
- **A2 comparison:** 14 of 52 deterministic groups have four-side receipts. This is partial evidence, not an overall parity verdict. Group 015's original R10 side hit the unchanged 600-second timeout under observed concurrent pytest activity. The later coordinated diagnostic found a first-census readiness timeout on all four sides; it did not explain the earlier timeout. A host process-count observation is only a hypothesis, and the proposed aggregate measurement/continuation has not run. Candidate-only failure in group 005 and shared baseline differences still need final D8 classification.
- **A4 remains blocked:** latest records report no compliant mechanism that both observes genuine request termination and preserves complete response bodies/navigation semantics. Local Playwright/Chromium and DevTools probes did not establish a fix. In particular, treating Playwright's inferred navigation failure as a genuine terminal weakens the stated check; durable buffering could not restore bytes the browser never received; an independent CDP session did not reproduce the missing terminal. The current App candidate's earlier journeys failed; no later candidate journey qualifies A4.
- **F2/TTS:** exact installed attach and custody proof remain open; current P32 task row says TTS diagnosis has not run and no pod was rented for this repair. Historical P34 GPU successes/failures belong to older candidates and do not satisfy this release tuple.
- **Fresh-session evidence outside the snapshot:** the orchestrator's 09:30 UTC note reports a provisional installed no-claim attachment failure: `ready_registration.source_epoch` disagreed with `live.source_digest` / `live.dependency_digest`; resident stayed alive and no pod was claimed. Cause is unresolved. This post-snapshot note is not yet in the preserved `09d7bfc` docs, so keep it separate from canonical committed evidence.

## Most useful source paths for the review ZIP

Paths are relative to `astrid-dev` at the snapshot SHA above. Prefer these 18 files; together they cover authority, exact refs, gates, comparison receipts, browser evidence and paid-proof limits.

1. `releases/12.md`
2. `releases/12/fixes.md`
3. `releases/12/generation.md`
4. `docs/handoffs/2026-11-10-release-12-new-session.md`
5. `docs/handoffs/2026-11-10-track-a-codex-resume.md`
6. `docs/handoffs/2026-11-10-release12-track-b-resume.md`
7. `plans/29-update-and-release/tasks.md`
8. `plans/29-update-and-release/evidence/r12/a2-sharded/README.md`
9. `plans/29-update-and-release/evidence/r12/a2-sharded/final-batches.json`
10. `plans/29-update-and-release/evidence/r12/a2-sharded/batches-001-006/README.md`
11. `plans/29-update-and-release/evidence/r12/a2-sharded/batches-007-008/README.md`
12. `plans/29-update-and-release/evidence/r12/a2-sharded/batches-009-010/README.md`
13. `plans/29-update-and-release/evidence/r12/a2-sharded/batch-011/README.md`
14. `plans/29-update-and-release/evidence/r12/a2-sharded/batch-012/README.md`
15. `plans/29-update-and-release/evidence/r12/a2-sharded/batches-013-014/README.md`
16. `plans/29-update-and-release/evidence/r12/a2-sharded/group-015-diagnostic/README.md`
17. `plans/29-update-and-release/evidence/r12/a2-sharded/group-015-diagnostic/continuation-proposal.md`
18. `plans/29-update-and-release/evidence/r12/a4-devtools/README.md`

For a slightly larger ZIP, add `plans/29-update-and-release/evidence/r12/dj-protocol-42954826041.md`, `plans/29-update-and-release/evidence/r12/a4-browser-lifecycle/README.md`, `plans/32-generation-placement-targets/tasks.md`, `plans/32-generation-placement-targets/evidence/release12-host-attach/README.md`, and `plans/34-real-gpu-proof/handoff.md`. The P34 handoff is explicitly historical; the active paid-work rules are in `releases/12/generation.md`.

## Provenance and caveats

The active briefs and current task records came from the preserved `09d7bfc` snapshot, not the worktree's earlier `06c357b` state. The separate F2 observation above is a direct orchestrator status note, not a committed source path. The six-digit SHAs shown in many narrative records are abbreviations; the live refs above were independently resolved to full hashes. Ref observations are time-bound. The P32 generation candidate SHA conflict is material and should be resolved before any review packet describes an accepted candidate. No tests, paid provider calls, secret files, or external write actions were used.
