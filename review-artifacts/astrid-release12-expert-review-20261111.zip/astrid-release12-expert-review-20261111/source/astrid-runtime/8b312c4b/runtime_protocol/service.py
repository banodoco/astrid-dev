from __future__ import annotations

from . import platform

from .cas import ContentAddressedStore, StagedObject, DEFAULT_MAX_OBJECT_BYTES, file_identity
from .canonical_schema import generation_tag_expression
from .backup import create_backup, restore_backup, structured_export
from .store import (
    GENERATION_INTENT_STORAGE_KEY,
    OBJECT_ID_RE,
    RealmStore,
    read_pack_admissions,
    pack_asset_path,
    PACK_ID_RE,
    PACK_DIGEST_RE,
    execution_placement_matches,
    normalize_execution_facts,
    normalize_verified_execution_placement,
    _normalize_execution_target,
    _normalize_execution_request,
    public_task_spec,
    command_result,
    expired_command_result,
    IDEMPOTENCY_RESULT_MARKER,
    IDEMPOTENCY_RESULT_WINDOW_SECONDS,
)
from .util import atomic_json_write
from .util import canonical_json, durable_json_bytes, new_id, now, sha256_bytes
from .render_observer import admitted_run_id
from .idempotency import command_result, compact_result
import hashlib
import json
import sqlite3
import base64
import copy
import hmac
from .dirfd import filesystem as os
import re
import secrets
import subprocess
import uuid
import stat
import math
from collections.abc import Mapping
from functools import wraps
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import quote
from .errors import RuntimeErrorBase, AuthorizationError, ForbiddenError, ConflictError, NotFoundError, ValidationError, LeaseError, InvalidRequestError, RealmAdmissionError, RetiredRouteError
from .errors import VerificationReceiptMissingError, CandidateNotVerifiedError, VerificationDigestMismatchError
from .contract_metadata import PROTOCOL, SCHEMA_DIGEST
from .dirfd import close_pinned as _close_pinned, mkdir_chain_at as _mkdir_chain_at, open_directory_chain as _open_directory_chain, pin_directory as _pin_directory, write_bytes_at as _write_bytes_at
from .timeline_commit_store import timeline_scope_is_empty
from .timeline_commit_execution import timed_timeline_commit
from .shot_dependencies import analyze_invalidation
from .timeline_inspection import inspect as inspect_timeline_closure
from .timeline_view import markdown as render_timeline_markdown, png as render_timeline_png
from .visual_seam import evaluate_closure, load_closure


CHECKPOINT_MAX_BYTES = 1024 * 1024
OBJECT_MAX_BYTES = DEFAULT_MAX_OBJECT_BYTES
MEDIA_IMPORT_CAPABILITY = "runtime.media.import.v1"
MEDIA_IMPORT_EXECUTOR = "runtime-host-media-import"
MEDIA_IMPORT_CAPABILITY_DIGEST = "sha256:" + hashlib.sha256(MEDIA_IMPORT_CAPABILITY.encode()).hexdigest()
TARGETED_EXECUTION_BINDING_CAPABILITY = "execution_binding.targeted.v1"
QUALIFIED_REMOTE_CAPABILITY = "h3_av.transform"
PLACEMENT_RECOVERY_SCHEMA_VERSION = 1
PLACEMENT_LOSS_EVIDENCE_MAX_AGE_SECONDS = 15 * 60
SESSION_IDEMPOTENCY_WINDOW_SECONDS = 60 * 60
REBOOT_COMMAND_ALLOWLIST = frozenset({"reboot", "resume"})
PAGE_DEFAULT_LIMIT = 50
PAGE_MAX_LIMIT = 200
CHILD_LIMITS = {
    "max_children": 64,
    "max_active_children": 64,
    "max_derived_objects": 256,
    "max_derived_bytes": 256 * 1024 * 1024,
    "max_child_inputs": 256,
    "max_child_bytes": 256 * 1024 * 1024,
    "max_recoverable_snapshots": 64,
    "max_recoverable_bytes": 64 * 1024 * 1024,
    "max_snapshot_bytes": 1024 * 1024,
}
CHILD_LIMIT_CEILINGS = CHILD_LIMITS | {
    "max_children": 4096,
    "max_derived_objects": 1024,
    "max_derived_bytes": 4 * 1024 * 1024 * 1024,
    "max_recoverable_snapshots": 1024,
    "max_recoverable_bytes": 4 * 1024 * 1024 * 1024,
    "max_snapshot_bytes": OBJECT_MAX_BYTES,
}
def _valid_import_effect_difference(value, *, allow_unresolved_unpinned=False):
    if not isinstance(value, dict):
        return False
    pack_id, kind, element_id = value.get("packId"), value.get("kind"), value.get("id")
    if not isinstance(pack_id, str) or not isinstance(kind, str) or not kind or not isinstance(element_id, str) or not element_id:
        return False
    if "revision" in value and value["revision"] is not None and not isinstance(value["revision"], str):
        return False
    if "pinned" in value and not isinstance(value["pinned"], bool):
        return False
    if pack_id:
        return True
    return allow_unresolved_unpinned and value.get("pinned") is False


# Fail-closed prototype caps; these are not certified discovery workload sizes.
DISCOVERY_GRANT_CEILINGS = {
    "max_discovery_rows": 750,
    "max_discovery_metadata_bytes": 64 * 1024 * 1024,
    "max_selected_output_objects": 2,
    "max_selected_output_bytes": 16 * 1024 * 1024,
    "max_child_media_bindings": 1,
    "max_child_media_bytes": 16 * 1024 * 1024,
}
IDEMPOTENCY_KEY_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._~-]{0,255}$")
MANAGED_COVERAGE_MODES = frozenset({"interval", "clips", "cuts", "shots"})
MANAGED_COVERAGE_REASONS = frozenset({"interval", "before_cut", "after_cut", "clip_first", "shot_midpoint"})
MANAGED_DURABILITIES = frozenset({"durable", "temporary"})
TEXT_BINDING_KINDS = ("prompt", "voiceover_script", "transcript")
TEXT_BINDING_MAX_BYTES = 1_048_576
TEXT_BINDING_SLOT_RE = re.compile(r"^[a-z][a-z0-9-]{0,63}$")
TEXT_BINDING_IDENTITY_SCHEMA = "workspace.shot.text_binding.identity/v1"
TRANSCRIPT_DOCUMENT_KIND = "media.transcript"
TRANSCRIPT_DOCUMENT_SCHEMA = "media.transcript/v1"
TRANSCRIPT_DOCUMENT_PREFIX = "transcript:"
TRANSCRIPT_MAX_BYTES = 1_048_576
TRANSCRIPT_MAX_SEGMENTS = 10_000
TRANSCRIPT_MAX_WORDS = 100_000
TRANSCRIPT_MAX_TIME_SECONDS = 1_000_000_000
TRANSCRIPT_ID_MAX_BYTES = 256
TRANSCRIPT_SOURCE_ID_MAX_BYTES = 512
TRANSCRIPT_TEXT_MAX_BYTES = 16_384
MEDIA_PROBE_TIMEOUT_SECONDS = 10
SUPPORTED_COMPOSITION_EFFECTS = frozenset({
    "crop", "fade", "gain", "opacity", "position", "scale", "transform", "volume",
})


LEGACY_MANAGED_OUTPUT_PREFIXES = frozenset({"images", "videos", "audio"})


def _canonical_execution_input_filename(value, field):
    """Validate the filename carried by a delegated execution input.

    Runtime resolves the object identity from the producer association, but
    the filename remains part of the worker-facing execution contract.  Keep
    it a flat, non-empty basename so the worker and Runtime normalize the
    same descriptor.
    """
    if (
        not isinstance(value, str)
        or not value
        or len(value) > 512
        or any(ord(char) < 32 for char in value)
    ):
        raise ValidationError(f"{field} must be a non-empty safe basename")
    path = Path(value)
    if path.is_absolute() or path.name != value or ".." in path.parts:
        raise ValidationError(f"{field} must be a non-empty safe basename")
    return value


def _canonical_managed_output_filename(value):
    """Return a flat export name for the known producer-relative namespaces."""
    if not isinstance(value, str) or not value or len(value) > 512:
        raise ValidationError("output filename is invalid")
    if any(ord(char) < 32 for char in value):
        raise ValidationError("output filename is invalid")
    if value not in {".", ".."} and "/" not in value and "\\" not in value:
        return value
    prefix, separator, leaf = value.partition("/")
    if separator and prefix in LEGACY_MANAGED_OUTPUT_PREFIXES:
        if leaf and leaf not in {".", ".."} and "/" not in leaf and "\\" not in leaf:
            return leaf
    raise ValidationError("output filename must be a direct safe file name or a known producer namespace/<direct safe file name>")


def _validate_rational(value, field):
    """Validate the V1 exact rational wire form without floating-point loss."""
    if isinstance(value, str):
        match = re.fullmatch(r"([0-9]+)/([1-9][0-9]*)", value)
        if match:
            return value
    elif isinstance(value, dict) and set(value) == {"numerator", "denominator"}:
        numerator, denominator = value["numerator"], value["denominator"]
        if (
            isinstance(numerator, int) and not isinstance(numerator, bool) and numerator >= 0
            and isinstance(denominator, int) and not isinstance(denominator, bool) and denominator > 0
        ):
            return {"numerator": numerator, "denominator": denominator}
    raise ValidationError(f"{field} must be a non-negative rational")


def _validate_coverage(value):
    """Validate the V1 sampling evidence carried by a managed output."""
    if not isinstance(value, dict) or set(value) != {"sampling"}:
        raise ValidationError(
            "output coverage must contain only V1 sampling evidence",
            details={"required": "sampling", "modes": sorted(MANAGED_COVERAGE_MODES)},
        )
    sampling = value["sampling"]
    if not isinstance(sampling, dict):
        raise ValidationError("output coverage.sampling must be an object")
    allowed = {"mode", "range", "step_frames_rational", "every", "every_frames", "cards"}
    unknown = set(sampling) - allowed
    if unknown:
        raise ValidationError("output coverage.sampling contains unsupported fields", details={"fields": sorted(unknown)})
    mode = sampling.get("mode")
    if mode not in MANAGED_COVERAGE_MODES:
        raise ValidationError("output coverage.sampling.mode is invalid", details={"modes": sorted(MANAGED_COVERAGE_MODES)})
    rendered_range = sampling.get("range")
    if not isinstance(rendered_range, dict) or set(rendered_range) != {"start", "end"}:
        raise ValidationError("output coverage.sampling.range must be a half-open object")
    start, end = rendered_range["start"], rendered_range["end"]
    if (
        isinstance(start, bool) or not isinstance(start, int) or start < 0
        or isinstance(end, bool) or not isinstance(end, int) or end <= start
    ):
        raise ValidationError("output coverage.sampling.range must satisfy 0 <= start < end")
    if "step_frames_rational" in sampling:
        _validate_rational(sampling["step_frames_rational"], "output coverage.sampling.step_frames_rational")
    if "every" in sampling and "every_frames" in sampling:
        raise ValidationError("output coverage.sampling.every and every_frames are mutually exclusive")
    if ("every" in sampling or "every_frames" in sampling) and mode != "interval":
        raise ValidationError("output coverage.sampling.every/every_frames are valid only for interval mode")
    if "every" in sampling and (
        isinstance(sampling["every"], bool) or not isinstance(sampling["every"], (int, float))
        or not math.isfinite(float(sampling["every"])) or float(sampling["every"]) <= 0
    ):
        raise ValidationError("output coverage.sampling.every must be a positive finite number")
    if "every_frames" in sampling and (
        isinstance(sampling["every_frames"], bool) or not isinstance(sampling["every_frames"], int)
        or sampling["every_frames"] <= 0
    ):
        raise ValidationError("output coverage.sampling.every_frames must be a positive integer")
    cards = sampling.get("cards", [])
    if not isinstance(cards, list):
        raise ValidationError("output coverage.sampling.cards must be a list")
    for card in cards:
        if not isinstance(card, dict) or set(card) != {"frame", "time_seconds", "time_rational", "sample_reasons"}:
            raise ValidationError("each coverage card requires frame, time_seconds, time_rational, and sample_reasons")
        if isinstance(card["frame"], bool) or not isinstance(card["frame"], int) or card["frame"] < 0:
            raise ValidationError("coverage card frame must be a non-negative integer")
        if (
            isinstance(card["time_seconds"], bool) or not isinstance(card["time_seconds"], (int, float))
            or not math.isfinite(float(card["time_seconds"])) or float(card["time_seconds"]) < 0
        ):
            raise ValidationError("coverage card time_seconds must be a non-negative finite number")
        _validate_rational(card["time_rational"], "coverage card time_rational")
        reasons = card["sample_reasons"]
        if not isinstance(reasons, list) or not reasons or any(reason not in MANAGED_COVERAGE_REASONS for reason in reasons):
            raise ValidationError("coverage card sample_reasons contains an invalid reason")
    return value


def _contains_latest(value):
    if isinstance(value, str):
        return value.lower() == "latest"
    if isinstance(value, dict):
        return any(_contains_latest(key) or _contains_latest(item) for key, item in value.items())
    if isinstance(value, list):
        return any(_contains_latest(item) for item in value)
    return False


def _validate_regeneration(value):
    """Validate the immutable regeneration declaration, including unavailable."""
    if not isinstance(value, dict) or set(value) != {"available", "capability_id", "source_refs", "recipe_digest", "exact_inputs"}:
        raise ValidationError(
            "output regeneration requires exactly available, capability_id, source_refs, recipe_digest, and exact_inputs"
        )
    available = value["available"]
    if not isinstance(available, bool):
        raise ValidationError("output regeneration.available must be a boolean")
    capability_id = value["capability_id"]
    if capability_id is not None and (not isinstance(capability_id, str) or not capability_id):
        raise ValidationError("output regeneration.capability_id must be a non-empty string or null")
    if available and capability_id is None:
        raise ValidationError("available regeneration requires capability_id")
    source_refs = value["source_refs"]
    if not isinstance(source_refs, list) or any(
        not isinstance(reference, str) or not OBJECT_ID_RE.fullmatch(reference) or not reference.startswith("sha256:")
        for reference in source_refs
    ):
        raise ValidationError("output regeneration.source_refs must contain canonical sha256 object IDs")
    recipe_digest = value["recipe_digest"]
    if not isinstance(recipe_digest, str) or not OBJECT_ID_RE.fullmatch(recipe_digest) or not recipe_digest.startswith("sha256:"):
        raise ValidationError("output regeneration.recipe_digest must be a canonical sha256 digest")
    exact_inputs = value["exact_inputs"]
    if not isinstance(exact_inputs, (dict, list)):
        raise ValidationError("output regeneration.exact_inputs must be an object or list")
    if _contains_latest(exact_inputs):
        raise ValidationError("output regeneration.exact_inputs must never use latest")
    return value


def validate_idempotency_key(value):
    """Validate the wire-level idempotency-key grammar in one place."""
    if not isinstance(value, str) or not IDEMPOTENCY_KEY_RE.fullmatch(value):
        raise InvalidRequestError(
            "Idempotency-Key must start with an alphanumeric character and contain at most 256 ASCII characters"
        )
    return value


def require_idempotency_key(value):
    """Require and validate the key for every durable state mutation."""
    if value is None:
        raise InvalidRequestError("Idempotency-Key is required for state mutations")
    return validate_idempotency_key(value)
def _wire_string(body, field):
    value = body.get(field)
    if not isinstance(value, str) or not value:
        raise ValidationError(f"{field} is required")
    return value


def _wire_integer(body, field, *, positive=False):
    value = body.get(field)
    if isinstance(value, bool) or not isinstance(value, int) or (positive and value < 1):
        kind = "positive integer" if positive else "an integer"
        raise ValidationError(f"{field} must be {kind}")
    return value
def _wire_object(body, *, required=(), allowed=()):
    """Validate a worker JSON object before any durable lookup or side effect."""
    if not isinstance(body, dict):
        raise InvalidRequestError("request body must be a JSON object")
    missing = sorted(field for field in required if field not in body)
    if missing:
        raise ValidationError("request body is missing required fields", details={"fields": missing})
    unknown = sorted(set(body) - set(allowed))
    if unknown:
        raise ValidationError("request body contains unsupported fields", details={"fields": unknown})
    return body


def _require_runtime_epoch_for_lease(body):
    """Reject an omitted epoch as malformed request data before any lookup."""
    if isinstance(body, dict) and "runtime_epoch" not in body:
        raise ValidationError(
            "request body is missing required fields",
            details={"fields": ["runtime_epoch"]},
        )


def _probe_media_bytes(data):
    """Return verified stream facts for media bytes without a metadata service."""
    try:
        completed = subprocess.run(
            [
                "ffprobe", "-v", "error", "-print_format", "json",
                "-show_entries", "stream=codec_type,duration:format=duration",
                "-i", "pipe:0",
            ],
            input=data,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
            timeout=MEDIA_PROBE_TIMEOUT_SECONDS,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ValidationError("source media could not be verified") from exc
    if completed.returncode != 0:
        raise ValidationError("source media is malformed")
    try:
        value = json.loads(completed.stdout.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValidationError("source media probe returned malformed metadata") from exc
    if not isinstance(value, dict) or not isinstance(value.get("streams"), list) or not value["streams"]:
        raise ValidationError("source media has no streams")
    stream_types = []
    durations = {}
    for stream in value["streams"]:
        if not isinstance(stream, dict) or not isinstance(stream.get("codec_type"), str):
            raise ValidationError("source media stream metadata is malformed")
        stream_type = stream["codec_type"]
        stream_types.append(stream_type)
        raw_duration = stream.get("duration")
        if raw_duration is not None and raw_duration not in ("N/A", ""):
            try:
                duration = float(raw_duration)
            except (TypeError, ValueError) as exc:
                raise ValidationError("source media duration is malformed") from exc
            if not math.isfinite(duration) or duration < 0:
                raise ValidationError("source media duration is malformed")
            durations.setdefault(stream_type, duration)
    raw_format_duration = (value.get("format") or {}).get("duration") if isinstance(value.get("format"), dict) else None
    format_duration = None
    if raw_format_duration is not None and raw_format_duration not in ("N/A", ""):
        try:
            format_duration = float(raw_format_duration)
        except (TypeError, ValueError) as exc:
            raise ValidationError("source media duration is malformed") from exc
        if not math.isfinite(format_duration) or format_duration < 0:
            raise ValidationError("source media duration is malformed")
    return {"stream_types": tuple(stream_types), "durations": durations, "format_duration": format_duration}


def _generation_filters(*, kind=None, model=None, target=None, tag=None):
    """Share exact metadata.gen matching between generation and object pages."""
    filters = {name: value for name, value in
               (("kind", kind), ("model", model), ("target", target), ("tag", tag))
               if value is not None}
    predicates, parameters = [], []
    for name, value in filters.items():
        if not isinstance(value, str) or not value:
            raise InvalidRequestError(f"{name} must be a non-empty string")
        if name == "tag":
            # Historical optional fields may be absent or have the wrong
            # shape. json_each must only receive a verified JSON array.
            predicates.append(
                "EXISTS (SELECT 1 FROM json_each("
                "CASE WHEN json_valid(metadata_json) THEN "
                "CASE WHEN json_type(metadata_json, '$.gen.tags')='array' "
                "THEN json_extract(metadata_json, '$.gen.tags') ELSE '[]' END "
                "ELSE '[]' END) WHERE type='text' AND value=?)"
            )
        else:
            predicates.append(f"{generation_tag_expression(name)}=?")
        parameters.append(value)
    return filters, predicates, parameters


def _page_args(cursor, limit):
    """Validate the public page arguments and decode an opaque keyset cursor."""
    if isinstance(limit, bool):
        raise InvalidRequestError("limit must be an integer between 1 and 200")
    try:
        limit = int(limit)
    except (TypeError, ValueError) as exc:
        raise InvalidRequestError("limit must be an integer between 1 and 200") from exc
    if limit < 1 or limit > PAGE_MAX_LIMIT:
        raise InvalidRequestError("limit must be an integer between 1 and 200")
    if cursor in (None, ""):
        return limit, None
    if not isinstance(cursor, str):
        raise InvalidRequestError("cursor must be a non-empty string")
    try:
        raw = base64.urlsafe_b64decode(cursor + "=" * (-len(cursor) % 4))
        value = json.loads(raw.decode("utf-8"))
    except (ValueError, TypeError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise InvalidRequestError("cursor is invalid") from exc
    if not isinstance(value, dict) or value.get("v") != 1 or not isinstance(value.get("k"), list) or not value["k"]:
        raise InvalidRequestError("cursor is invalid")
    return limit, value


def reject_retired_timeline_writer():
    """Reject a legacy timeline writer before it can reach publication code."""
    raise RetiredRouteError(
        "legacy timeline writes are retired; submit EditCommands through commitTimeline",
        details={"status": "refused", "reason": "timeline_commit_required",
                 "hint": "Submit a timeline commit instead of the retired save route.",
                 "suggested_command": "timeline commit",
                 "replacement": "POST /v1/projects/{project_id}/timelines/{timeline_id}/commit"},
    )


def _page_cursor(scope, key, *, numeric=False):
    value = {"v": 1, "s": scope, "k": list(key)}
    if numeric:
        value["numeric"] = True
    raw = json.dumps(value, separators=(",", ":"), sort_keys=True).encode("utf-8")
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _page_rows(rows, *, scope, cursor, limit, key_fn, resource_fn, skip_after=None):
    limit, decoded = _page_args(cursor, limit)
    if decoded is not None and decoded.get("s") != scope:
        raise InvalidRequestError("cursor does not belong to this collection")
    after = tuple(decoded["k"]) if decoded is not None else None
    selected = []
    for row in rows:
        key = tuple(key_fn(row))
        if after is not None:
            if len(key) != len(after):
                raise InvalidRequestError("cursor is invalid")
            try:
                before = skip_after(key, after) if skip_after is not None else key <= after
            except (TypeError, IndexError) as exc:
                raise InvalidRequestError("cursor is invalid") from exc
            if before:
                continue
        selected.append((key, resource_fn(row)))
        if len(selected) > limit:
            break
    has_more = len(selected) > limit
    selected = selected[:limit]
    return {"items": [resource for _, resource in selected], "next_cursor": _page_cursor(scope, selected[-1][0]) if has_more else None}


def _clear_replay_on_refusal(function):
    @wraps(function)
    def wrapped(self, *args, **kwargs):
        try:
            return function(self, *args, **kwargs)
        except BaseException:
            if self._timeline_commit_store is not None:
                self._timeline_commit_store.clear_replay_memo()
            raise
    return wrapped


def _verified_mutation(function):
    """Fence the complete mutation against a concurrent admission loss."""
    @wraps(function)
    def wrapped(self, *args, **kwargs):
        with self.store._mutex:
            self._assert_mutation_admitted()
            return function(self, *args, **kwargs)
    return wrapped


def _durable_mutation(function=None, *, reap_task_lifetimes=False):
    """Keep a project mutation and its idempotency receipt atomic."""
    if function is None:
        return lambda target: _durable_mutation(target, reap_task_lifetimes=reap_task_lifetimes)
    @wraps(function)
    def wrapped(self, *args, **kwargs):
        with self.store._mutex:
            self._assert_mutation_admitted()
            if reap_task_lifetimes:
                # A rejected late settlement must not roll back its independent
                # Runtime-owned terminal deadline transition.
                self.store.reap_overdue_leases()
            try:
                with self.store._transaction():
                    result = function(self, *args, **kwargs)
            except Exception:
                # A CAS publication is journaled before its destination is
                # renamed.  Reconcile after SQLite has rolled back so a
                # failed commit cannot leave an unreferenced object behind.
                self._recover_cas_publication_journals()
                if reap_task_lifetimes:
                    self.store.reap_overdue_leases()
                raise
            self._recover_cas_publication_journals()
            return result
    return wrapped


def _refuse_direct_shot_write(self, *args, **kwargs):
    raise RetiredRouteError("direct shot writes are retired; use timeline commands")


class RuntimeService:
    """Neutral application service composed by the daemon or an isolated test."""

    def __init__(self, root, *, display_name="Workspace", realm_id=None, support_root=None, export_root=None, reboot_executor=None, reboot_allowlist=None, runtime_epoch_floor=None, admission_timeout=None, _admission_fd=None, pack_admissions=None, _local_worker_composition=None, _local_worker_composition_required=False):
        if pack_admissions is not None and not callable(pack_admissions):
            raise ValidationError("pack_admissions must be an installed admission snapshot reader")
        self._pack_admissions = pack_admissions
        self._pack_leases = {}
        from .local_worker_composition import _retain_local_worker_composition
        # Retain owner declarations before opening the realm; this neither
        # invokes a producer nor changes ordinary task admission below.
        self._local_worker_composition = _retain_local_worker_composition(
            _local_worker_composition, required=_local_worker_composition_required)
        configured_max = os.environ.get("RUNTIME_MAX_OBJECT_BYTES", str(OBJECT_MAX_BYTES))
        if not re.fullmatch(r"[0-9]{1,20}", configured_max):
            raise ValidationError("RUNTIME_MAX_OBJECT_BYTES must be a positive decimal integer")
        self.max_object_bytes = int(configured_max, 10)
        if not 0 < self.max_object_bytes <= OBJECT_MAX_BYTES:
            raise ValidationError("RUNTIME_MAX_OBJECT_BYTES must be between 1 and 5368709120")
        root_path = Path(root).expanduser().resolve()
        # Service startup is an open/admission operation.  Realm creation is
        # explicit through RealmStore.initialize; a missing path must fail
        # before schema, identity, lock, or storage roots can be created.
        store_kwargs = {}
        if _admission_fd is not None:
            store_kwargs["_admission_fd"] = _admission_fd
        if admission_timeout is not None:
            try:
                admission_timeout = float(admission_timeout)
            except (TypeError, ValueError) as exc:
                raise ValidationError("admission_timeout must be a finite positive number") from exc
            if not math.isfinite(admission_timeout) or admission_timeout <= 0:
                raise ValidationError("admission_timeout must be a finite positive number")
            store_kwargs["admission_timeout"] = admission_timeout
        self.store = RealmStore(root_path, **store_kwargs)
        self._verified = False
        self._admission_failure = None
        self._readiness_callback = None
        self._timeline_commit_provider = None
        self._v33_provider_registered = False
        self._timeline_commit_started = False
        self._timeline_commit_store = None
        self._timeline_commit_coordinator = None
        try:
            if not self.store.admission_report.get("ok"):
                raise RealmAdmissionError(
                    "realm failed startup admission",
                    details=self.store.admission_report,
                )
            self.cas = ContentAddressedStore(self.store.cas_root)
            self.realm = self.store.ensure_realm(display_name, realm_id=realm_id)
            self.runtime_session_id = new_id()
            self._child_authority_key = secrets.token_bytes(32)
            self._runtime_state = self.store.begin_runtime_session(
                self.runtime_session_id, epoch_floor=runtime_epoch_floor
            )
            # Lease and registration requests are fenced by this boot's epoch.
            # Their replay payloads belong to the SQLite session, not the
            # permanent command ledger copied into backups.
            self.store.conn.execute(
                "CREATE TEMP TABLE session_command_replay ("
                "command_kind TEXT NOT NULL, aggregate_id TEXT NOT NULL, idempotency_key TEXT NOT NULL, "
                "request_hash TEXT NOT NULL, result_json TEXT NOT NULL, created_at TEXT NOT NULL, "
                "is_expired INTEGER NOT NULL DEFAULT 0, "
                "PRIMARY KEY(command_kind, aggregate_id, idempotency_key))"
            )
            self.store.conn.execute(
                "CREATE INDEX temp.session_replay_expiration ON session_command_replay(is_expired, created_at)"
            )
            self._verified = True
        except Exception:
            self.store.close()
            raise
        self.support_root = Path(support_root).expanduser().resolve() if support_root else None
        # Reconstruct before any admission/replay. An unreadable existing fence
        # is uncertainty, never an unfenced generation. The daemon installs the
        # credential-owner verifier before starting HTTP or a local launcher.
        self._local_claim_actor = "astrid-pack-host"
        self._local_generation_verifier = None
        self._local_claim_fence_unknown = False
        self._local_claim_fence = None
        self._load_local_claim_fence()
        self.export_root = Path(export_root).expanduser().resolve() if export_root else None
        if self.export_root is not None:
            if self.export_root == self.store.root or self.export_root.is_relative_to(self.store.root) or self.store.root.is_relative_to(self.export_root):
                raise ValidationError("managed-output export root must be outside the active realm root")
            if self.export_root.is_symlink() or not self.export_root.is_dir():
                raise ValidationError("managed-output export root must be an existing ordinary directory")
        self.reboot_executor = reboot_executor
        configured_allowlist = frozenset(reboot_allowlist or REBOOT_COMMAND_ALLOWLIST)
        if not configured_allowlist or not configured_allowlist.issubset(REBOOT_COMMAND_ALLOWLIST):
            raise ValidationError("reboot allowlist contains an unsupported command", details={"allowlist": sorted(configured_allowlist), "supported": sorted(REBOOT_COMMAND_ALLOWLIST)})
        self.reboot_allowlist = configured_allowlist
        self._verified_cas_objects = {}
        self._recover_cas_publication_journals()
        # Only startup may remove abandoned transfers: live handlers own their files.
        upload_dir = self.store.staging_root / "uploads"
        if upload_dir.exists():
            fd = _open_directory_chain(upload_dir)
            try:
                for entry in os.scandir(fd):
                    if re.fullmatch(r"[0-9a-f]{32}\.upload", entry.name):
                        os.unlink(entry.name, dir_fd=fd)
                os.fsync(fd)
            finally:
                os.close(fd)

    def close(self):
        for _record, fd in self._pack_leases.values():
            os.close(fd)
        self._pack_leases.clear()
        self.store.close()

    def _local_claim_fence_path(self):
        return (self.support_root or self.store.root) / "local-execution-claim-fence.json"

    def _load_local_claim_fence(self):
        from .local_execution_handoff import read_protected, validate_fence
        path = self._local_claim_fence_path()
        if not path.exists() and not path.is_symlink():
            return
        try:
            self._local_claim_fence = validate_fence(read_protected(path))
            if self._local_claim_fence["workspace_uuid"] != self.realm["id"]:
                raise ConflictError("claim fence workspace differs")
        except Exception:
            self._local_claim_fence_unknown = True

    def set_local_claim_generation_verifier(self, callback, *, actor):
        """Daemon-only composition, not an RPC or a new credential API."""
        self._local_generation_verifier = callback
        self._local_claim_actor = actor

    def _assert_local_claim_admission(self, executor_id, *, identity=None, registration=False):
        if executor_id != self._local_claim_actor:
            return
        self._load_local_claim_fence()
        fence = self._local_claim_fence
        if self._local_claim_fence_unknown:
            raise ConflictError("local execution claim fence is unresolved")
        if fence is None:
            return
        verifier = self._local_generation_verifier
        if verifier is None or verifier(fence, identity) != fence["credential_generation_digest"]:
            raise ConflictError("local execution credential generation is unresolved")
        if fence["state"] == "held":
            if not registration:
                raise ConflictError("local execution claims are fenced")
            binding = identity.get("execution_binding") if isinstance(identity, dict) else None
            if not isinstance(binding, dict) or binding.get("executor_incarnation") != fence["executor_incarnation"]:
                raise ConflictError("registration differs from fenced incarnation")

    def hold_local_claim_fence(self, value, *, assert_no_work):
        """No-work check and durable fence share the canonical claim mutex."""
        from .local_execution_handoff import validate_fence, write_protected
        value = validate_fence(dict(value))
        with self.store._mutex:
            self._assert_mutation_admitted()
            self._load_local_claim_fence()
            if self._local_claim_fence_unknown or value["state"] != "held" or value["workspace_uuid"] != self.realm["id"]:
                raise ConflictError("claim fence cannot be published")
            previous = self._local_claim_fence
            if previous == value:
                return dict(previous)
            if previous is not None and (previous["state"] != "released" or value["fence_generation"] != previous["fence_generation"] + 1):
                raise ConflictError("claim fence generation conflicts")
            if previous is None and value["fence_generation"] != 1:
                raise ConflictError("initial claim fence generation must be one")
            verifier = self._local_generation_verifier
            if verifier is None or verifier(value, None) != value["credential_generation_digest"]:
                raise ConflictError("claim fence credential generation differs")
            assert_no_work()
            write_protected(self._local_claim_fence_path(), value)
            self._local_claim_fence = value
            return dict(value)

    def release_local_claim_fence(self, held, *, durable_ack, verify_ack):
        """Only a daemon-verified durable terminal outcome permits release."""
        from .local_execution_handoff import digest, validate_fence, write_protected
        validate_fence(held)
        with self.store._mutex:
            self._load_local_claim_fence()
            if self._local_claim_fence_unknown or self._local_claim_fence != held or held["state"] != "held":
                raise ConflictError("claim fence release has no exact held generation")
            verifier = self._local_generation_verifier
            if verifier is None or verifier(held, None) != held["credential_generation_digest"]:
                raise ConflictError("claim fence credential generation changed")
            # verify_ack only checks retained/durable evidence. It must not do
            # RPC or waits under the store mutex; no public caller selects it.
            verify_ack(durable_ack)
            released = {**held, "state": "released", "release_ack_digest": digest(durable_ack)}
            write_protected(self._local_claim_fence_path(), released)
            self._local_claim_fence = released
            return dict(released)

    def set_readiness_callback(self, callback) -> None:
        """Install the daemon-owned readiness revocation hook."""
        self._readiness_callback = callback

    def catalog_admission(self, instance_id):
        """Return an unforgeable-in-practice proof for this live owner."""
        return {
            "realm_id": self.realm["id"],
            "runtime_epoch": int(self.store._current_runtime_epoch()),
            "runtime_session_id": self.runtime_session_id,
            "runtime_instance_id": str(instance_id),
        }

    def validate_catalog_admission(self, proof) -> bool:
        if not self._verified or not isinstance(proof, dict) or self.store._lock_file is None:
            return False
        try:
            return (
                proof.get("realm_id") == self.realm["id"]
                and proof.get("runtime_session_id") == self.runtime_session_id
                and proof.get("runtime_instance_id")
                and int(proof.get("runtime_epoch")) == int(self.store._current_runtime_epoch())
            )
        except (KeyError, TypeError, ValueError):
            return False

    def backup(self, destination, *, binding=None, destination_identity=None):
        key_path = (self.support_root / "backup-auth.key") if self.support_root else (self.store.root / ".operator-backup-key")
        return create_backup(self.store, destination, binding=binding, key_path=key_path, destination_identity=destination_identity)

    def restore(self, backup_dir, destination, *, destination_identity=None, source_identity=None):
        # The backup's authenticated manifest owns the key identity.  Do not
        # force this service's current support key: a destination backup
        # may have been signed by the destination realm's key while the
        # active service is restoring it. ``restore_backup`` resolves the
        # manifest key through descriptor-pinned I/O and checks its key id.
        return restore_backup(backup_dir, destination, destination_identity=destination_identity, source_identity=source_identity)

    def export_structured(self, destination=None):
        value = structured_export(self.store)
        if destination is not None:
            atomic_json_write(Path(destination).expanduser().resolve(), value)
        return value

    def doctor(self):
        with self.store._mutex:
            report = self.store.doctor(catalog_path=(self.support_root / "catalog.json") if self.support_root else None)
            if not report.get("ok"):
                # Admission is monotonic for one service instance. Repair is
                # verified by a fresh startup; an unhealthy process never
                # silently resumes writes after observing damaged authority.
                self._verified = False
                self._admission_failure = report
                if self._readiness_callback is not None:
                    try:
                        self._readiness_callback(report)
                    except Exception:
                        pass
            return report

    @_verified_mutation
    def tombstone(self, body=None):
        body = body or {}
        return self.store.tombstone_realm(reason=body.get("reason"), expected_version=body.get("expected_version"))

    @_verified_mutation
    def recover_realm(self, body=None):
        body = body or {}
        # Recovery is a destructive lifecycle transition.  Require an
        # operator-scoped expectation before touching durable state, even when
        # the realm is already active (the no-op path must be fenced too).
        expected_realm_id = body.get("expected_realm_id")
        expected_version = body.get("expected_version")
        if not expected_realm_id or expected_version is None:
            raise ValidationError("recovery requires expected_realm_id and expected_version")
        if str(expected_realm_id) != str(self.realm["id"]):
            raise ConflictError("recovery realm identity mismatch", details={"expected": expected_realm_id, "actual": self.realm["id"]})
        noninteractive = body.get("noninteractive") is True
        confirmation = body.get("confirmation")
        required_confirmation = f"RECOVER {self.realm['id']}"
        if bool(noninteractive) == bool(confirmation):
            raise ValidationError(f"recovery requires exactly one of confirmation {required_confirmation!r} or noninteractive=true")
        if not noninteractive and confirmation != required_confirmation:
            raise ValidationError(f"recovery requires confirmation exactly {required_confirmation!r} or noninteractive=true")
        return self.store.restore_tombstone(expected_version=expected_version)

    def purge(self, body=None):
        """Return the explicit offline purge boundary; never purge online."""
        body = body or {}
        confirmation = body.get("confirmation")
        required = f"PURGE {self.realm['id']}"
        if confirmation != required:
            raise ValidationError(f"whole-realm purge requires confirmation exactly {required!r}")
        if self.store.realm_lifecycle()["state"] != "tombstoned":
            raise ConflictError("whole-realm purge requires a tombstoned realm")
        raise ConflictError("whole-realm purge is offline-only; stop the runtime and use the purge command", details={"next_action": "astrid-runtime-protocol purge --root <realm> --confirm 'PURGE <realm_id>'"})

    def health(self, *, identity_probe=False):
        # ``doctor`` performs the full quick-check, foreign-key, event-chain,
        # and CAS walk. Health is called frequently, so keep it to a cheap
        # liveness query while retaining the cached startup admission state.
        # Ordinary health retains the primary handle and mutation ordering;
        # boundary identity probes must observe a separate committed snapshot.
        if identity_probe:
            try:
                with self.store._read_snapshot() as connection:
                    row = connection.execute("SELECT id FROM realm LIMIT 1").fetchone()
                    live = row is not None and row[0] == self.realm["id"]
            except (sqlite3.DatabaseError, OSError, ValueError, TypeError):
                live = False
            if not live:
                # Admission loss remains serialized with whole mutations. A
                # successful identity probe must not wait on a fenced writer.
                with self.store._mutex:
                    self._verified = False
                    self._admission_failure = {"reason": "runtime_liveness_failed"}
        else:
            with self.store._mutex:
                try:
                    if self.store.conn is None:
                        raise sqlite3.ProgrammingError("realm store is closed")
                    row = self.store.conn.execute("SELECT 1").fetchone()
                    live = row is not None and int(row[0]) == 1
                except (sqlite3.DatabaseError, OSError, ValueError, TypeError):
                    live = False
                    self._verified = False
                    self._admission_failure = {"reason": "runtime_liveness_failed"}
        return {"status": "ok" if self._verified and live else "degraded", "protocol": PROTOCOL, "schema_digest": SCHEMA_DIGEST, "runtime_epoch": self._runtime_state["runtime_epoch"], "runtime_session_id": self.runtime_session_id}

    def _assert_mutation_admitted(self):
        if not getattr(self, "_registering_v33_provider", False):
            from .v33_lifecycle import require_ready, MARKER
            require_ready(self.store.root)
            if (self.store.root / MARKER).exists() and not self._v33_provider_registered:
                raise ConflictError("v33 provider registration is required for this process before requests and fresh pins")
        if not self._verified:
            raise RealmAdmissionError(
                "realm is not admitted for mutations",
                details=self._admission_failure or self.store.admission_report,
            )

    def runtime_lifecycle(self):
        """Return current boot/session and recovery facts for diagnostics."""
        value = dict(self._runtime_state)
        value["runtime_session_id"] = self.runtime_session_id
        return value

    def realm_resource(self, *, identity_probe=False):
        if identity_probe:
            with self.store._read_snapshot() as connection:
                row = connection.execute("SELECT * FROM realm LIMIT 1").fetchone()
                lifecycle = connection.execute("SELECT * FROM realm_lifecycle WHERE realm_id=?", (row["id"],)).fetchone()
                if lifecycle is None:
                    lifecycle = {"state": "active", "tombstoned_at": None, "version": 1}
        else:
            row = self.store.realm
            lifecycle = self.store.realm_lifecycle()
        return {"realm_id": row["id"], "display_name": row["display_name"], "version": 1, "created_at": row["created_at"], "state": lifecycle["state"], "tombstoned_at": lifecycle["tombstoned_at"], "lifecycle_version": lifecycle["version"]}

    def handshake(self, body):
        requested = list(body.get("requested_scopes") or [])
        actor = body.get("authenticated_actor")
        if not actor:
            raise ValidationError("authenticated actor is required")
        if any(not isinstance(scope, str) or not scope for scope in requested) or len(set(requested)) != len(requested):
            raise ValidationError("requested_scopes must contain unique non-empty strings")
        authenticated = set(body.get("authenticated_scopes") or [])
        # ``admin`` authorizes endpoint access but is not a wildcard grant for
        # handshake negotiation.  The session is the exact authenticated
        # scope intersection, and asking for anything outside it fails closed.
        negotiated = authenticated - {"admin"}
        excess = sorted(set(requested) - negotiated)
        if excess:
            raise AuthorizationError("credential cannot negotiate requested scopes", details={"scopes": excess})
        return {"protocol": PROTOCOL, "schema_digest": SCHEMA_DIGEST, "session_id": new_id(), "actor_id": actor, "realm_id": self.realm["id"], "scopes": requested, "capabilities": [TARGETED_EXECUTION_BINDING_CAPABILITY, "rendering.render.historical_revision.v1"]}

    @staticmethod
    def _assert_executor_identity(identity, executor_id):
        """Bind bearer worker credentials to the executor they operate.

        ``identity`` is supplied only by the HTTP boundary.  Direct service
        calls remain useful for in-process control-plane tests and have no
        bearer principal to bind.  HTTP worker credentials are accepted only
        when their actor is the executor itself or they carry the explicit
        administrator scope.
        """
        if identity is None:
            return
        if not executor_id:
            raise AuthorizationError("executor identity is required")
        actor = identity.get("actor")
        if actor == executor_id or "admin" in set(identity.get("scopes", [])):
            return
        raise AuthorizationError("worker credential is not bound to executor", details={"executor_id": executor_id, "actor_id": actor})

    @staticmethod
    def _trusted_execution_placement(identity):
        if identity is None or identity.get("execution_binding") is None:
            return None
        try:
            return normalize_verified_execution_placement(identity["execution_binding"])
        except ValidationError as exc:
            raise AuthorizationError("worker credential carries invalid execution placement") from exc

    def _placement_recovery_qualification_matches(self, task_id, placement):
        recovery = self.store.placement_recovery(task_id)
        if recovery is None:
            return True
        qualification = recovery.get("qualification")
        return bool(
            placement is not None
            and isinstance(qualification, dict)
            and placement.get("actual") == recovery.get("replacement_target")
            and placement.get("verification", {}).get("evidence_digest")
            == qualification.get("evidence_digest")
            and placement.get("executor_incarnation")
            == qualification.get("executor_incarnation")
        )

    def _remote_activation_history(self, task_id, activation_id=None):
        rows = self.store.conn.execute(
            "SELECT id, kind, payload_json FROM events WHERE task_id=? "
            "AND kind IN ('task.remote_activation_qualified', 'task.remote_activation_accepted', 'task.remote_activation_revoked') "
            "ORDER BY id", (str(task_id),),
        ).fetchall()
        history = []
        for row in rows:
            try:
                payload = json.loads(row["payload_json"])
            except (TypeError, json.JSONDecodeError):
                continue
            if not isinstance(payload, dict):
                continue
            if activation_id is None or payload.get("activation_id") == activation_id:
                history.append((row["kind"], payload))
        return history

    def _latest_remote_activation(self, task_id):
        row = self.store.conn.execute(
            "SELECT kind, payload_json FROM events WHERE task_id=? "
            "AND kind IN ('task.remote_activation_qualified', 'task.remote_activation_revoked') "
            "ORDER BY id DESC LIMIT 1", (str(task_id),),
        ).fetchone()
        if row is None or row["kind"] != "task.remote_activation_qualified":
            return None
        return json.loads(row["payload_json"])

    def _remote_drain(self, task_id, activation_id=None):
        rows = self.store.conn.execute(
            "SELECT payload_json FROM events WHERE task_id=? "
            "AND kind='task.remote_activation_draining' ORDER BY id DESC",
            (str(task_id),),
        ).fetchall()
        for row in rows:
            marker = json.loads(row["payload_json"])
            if activation_id is not None:
                if marker["qualification"]["activation_id"] == activation_id:
                    return marker
                continue
            latest = self._latest_remote_activation(task_id)
            return marker if latest is None or latest == marker["qualification"] else None
        return None

    def _task_drain(self, task_id):
        row = self.store.conn.execute("SELECT spec_digest FROM tasks WHERE id=?", (str(task_id),)).fetchone()
        lineage = self.store._spec(row).get("delegated_parent") if row else None
        owner_id = lineage.get("parent_task_id") if isinstance(lineage, dict) else task_id
        return self._remote_drain(owner_id)

    def _drain_continuation_matches(self, task_id, marker):
        cutoff = marker.get("parent_attempt")
        if cutoff is None or str(task_id) == marker["qualification"]["task_id"]:
            return False
        row = self.store.conn.execute("SELECT spec_digest FROM tasks WHERE id=?", (str(task_id),)).fetchone()
        if row is None:
            return False
        lineage = self.store._spec(row).get("delegated_parent")
        return isinstance(lineage, dict) and all(lineage.get(key) == value for key, value in cutoff.items())

    def _assert_exact_drain_generation(self, task_id, qualification, identity, *, allow_revoked=False):
        if self._require_placement_recovery_owner(identity) != "owner":
            raise AuthorizationError("remote drain requires the Runtime owner actor")
        if not isinstance(qualification, dict) or qualification.get("task_id") != str(task_id):
            raise ConflictError("remote drain generation is missing or foreign")
        latest = self._latest_remote_activation(task_id)
        marker = self._remote_drain(task_id, qualification.get("activation_id"))
        revoked = any(kind == "task.remote_activation_revoked" for kind, _ in
                      self._remote_activation_history(task_id, qualification.get("activation_id")))
        if latest != qualification and not (allow_revoked and revoked
                                             and marker is not None and marker["qualification"] == qualification):
            raise ConflictError("remote drain generation changed")
        from .remote_worker_deployment import deployment_binding_from_task
        binding = deployment_binding_from_task(self._task_resource(self.store.get_task(task_id)))
        stale_runtime = (qualification.get("runtime_session_id") != self.runtime_session_id
                         or qualification.get("runtime_epoch") != self.store._current_runtime_epoch())
        if ((stale_runtime and not (allow_revoked and marker is not None and marker["qualification"] == qualification))
                or qualification.get("binding_digest") != binding.digest()
                or qualification.get("effective_target") != binding.placement.effective_target):
            raise ConflictError("remote drain generation is stale or binding changed")
        return marker, revoked

    @_durable_mutation
    def begin_remote_drain(self, task_id, qualification, *, identity=None):
        marker, _ = self._assert_exact_drain_generation(task_id, qualification, identity)
        if marker is not None:
            return {"state": "pending", "activation_id": qualification["activation_id"]}
        parent = self.store.conn.execute("SELECT * FROM tasks WHERE id=?", (str(task_id),)).fetchone()
        cutoff = None
        if parent["status"] in {"running", "cancel_requested"}:
            attempt = self.store.conn.execute("SELECT * FROM attempts WHERE id=?", (parent["attempt_id"],)).fetchone()
            if (attempt is None or int(attempt["settled"] or 0)
                    or attempt["executor_id"] != qualification["credential_actor"]
                    or attempt["lease_id"] != parent["lease_token"]
                    or attempt["fence"] != parent["lease_fence"]
                    or attempt["runtime_epoch"] != qualification["runtime_epoch"]):
                raise ConflictError("running parent attempt cannot be captured for drain")
            cutoff = {"parent_task_id": str(task_id), "parent_attempt_id": attempt["id"],
                      "parent_lease_id": attempt["lease_id"], "parent_fence": attempt["fence"],
                      "executor_id": attempt["executor_id"], "runtime_epoch": attempt["runtime_epoch"]}
        marker = {"qualification": qualification, "parent_attempt": cutoff, "begun_at": now()}
        self.store._append_event(parent["run_id"], str(task_id), "task.remote_activation_draining", marker)
        return {"state": "pending", "activation_id": qualification["activation_id"]}

    @_durable_mutation
    def finish_remote_drain(self, task_id, qualification, *, identity=None):
        marker, revoked = self._assert_exact_drain_generation(task_id, qualification, identity, allow_revoked=True)
        if marker is None or marker["qualification"] != qualification:
            raise ConflictError("remote drain has not begun for this exact generation")
        task_ids = [str(task_id)] + [row["id"] for row, _ in self._delegated_children(str(task_id))]
        pending = []
        for current_id in task_ids:
            task = self.store.conn.execute("SELECT * FROM tasks WHERE id=?", (current_id,)).fetchone()
            binding = self.store.execution_binding(current_id)
            if (task["status"] not in {"completed", "failed", "cancelled"}
                    or task["waiting_reason"] == "provider_state_unknown"
                    or self.store.conn.execute("SELECT 1 FROM attempts WHERE task_id=? AND settled=0 LIMIT 1", (current_id,)).fetchone()
                    or self.store.conn.execute("SELECT 1 FROM reservations WHERE task_id=? AND released_at IS NULL LIMIT 1", (current_id,)).fetchone()
                    or (binding is not None and binding["status"] == "claimed")):
                pending.append(current_id)
        if pending:
            return {"state": "pending", "activation_id": qualification["activation_id"], "task_ids": pending}
        if not revoked:
            self.revoke_remote_activation(task_id, qualification["activation_id"], identity=identity)
        return {"state": "drained", "activation_id": qualification["activation_id"]}

    def _task_requires_remote_activation(self, task_id):
        if any(kind == "task.remote_activation_qualified"
               for kind, _ in self._remote_activation_history(task_id)):
            return True
        row = self.store.conn.execute(
            "SELECT capability, execution_request_json, spec_digest FROM tasks WHERE id=?",
            (str(task_id),),
        ).fetchone()
        if row is None:
            return False
        request = self.store._execution_request_from_row(row)
        target = self.store.effective_execution_target(task_id)
        if (isinstance(request, dict)
                and request.get("remote_activation_required") is True
                and isinstance(target, dict) and target.get("kind") == "runpod"):
            return True
        if (row["capability"] == QUALIFIED_REMOTE_CAPABILITY
                and isinstance(request, dict)
                and isinstance(request.get("target"), dict)
                and request["target"].get("kind") in {"runpod", "machine"}):
            return True
        try:
            spec = self.store._spec(row)
        except (TypeError, json.JSONDecodeError):
            return False
        lineage = spec.get("delegated_parent") if isinstance(spec, dict) else None
        parent_id = lineage.get("parent_task_id") if isinstance(lineage, dict) else None
        if not parent_id:
            return False
        return any(
            kind == "task.remote_activation_qualified"
            for kind, _payload in self._remote_activation_history(parent_id)
        )

    def _activation_scope_matches(self, task_id, activation, placement):
        task = self.store.conn.execute(
            "SELECT * FROM tasks WHERE id=?", (str(task_id),)
        ).fetchone()
        owner_id = str(activation.get("task_id") or "")
        if task is None or not owner_id or activation.get("run_id") is None:
            return False
        owner = self.store.conn.execute(
            "SELECT * FROM tasks WHERE id=?", (owner_id,)
        ).fetchone()
        if owner is None or owner["run_id"] != activation.get("run_id"):
            return False
        if str(task["id"]) == owner_id:
            return task["run_id"] == activation.get("run_id")
        try:
            spec = self.store._spec(task)
        except (TypeError, json.JSONDecodeError):
            return False
        lineage = spec.get("delegated_parent")
        authorized = activation.get("authorized_child_lineage")
        if not isinstance(lineage, dict) or not isinstance(authorized, dict):
            return False
        parent = self.store.conn.execute(
            "SELECT * FROM tasks WHERE id=?", (lineage.get("parent_task_id"),)
        ).fetchone()
        if (authorized.get("parent_task_id") != owner_id
                or authorized.get("parent_run_id") != activation.get("run_id")
                or authorized.get("max_depth") != 1
                or lineage.get("parent_task_id") != owner_id
                or parent is None
                or parent["run_id"] != activation.get("run_id")):
            return False
        try:
            from .remote_worker_deployment import deployment_binding_from_task
            parent_binding = deployment_binding_from_task(
                self._task_resource(self.store.get_task(owner_id))
            )
        except (TypeError, ValueError, KeyError):
            return False
        current_attempt = self.store.conn.execute(
            "SELECT * FROM attempts WHERE id=? AND task_id=?",
            (lineage.get("parent_attempt_id"), owner_id),
        ).fetchone()
        return bool(
            parent["status"] == "running"
            and parent["attempt_id"] == lineage.get("parent_attempt_id")
            and parent["lease_token"] == lineage.get("parent_lease_id")
            and int(parent["lease_fence"] or 0) == int(lineage.get("parent_fence") or 0)
            and int(parent["runtime_epoch"] or 0) == int(lineage.get("runtime_epoch") or 0)
            and parent["executor_id"] == lineage.get("executor_id")
            and current_attempt is not None
            and not int(current_attempt["settled"] or 0)
            and current_attempt["lease_id"] == lineage.get("parent_lease_id")
            and int(current_attempt["fence"] or 0) == int(lineage.get("parent_fence") or 0)
            and int(current_attempt["runtime_epoch"] or 0) == int(lineage.get("runtime_epoch") or 0)
            and current_attempt["executor_id"] == lineage.get("executor_id")
            and lineage.get("executor_id") == activation.get("credential_actor")
            and lineage.get("parent_placement") == placement
            and lineage.get("parent_effective_target") == activation.get("effective_target")
            and lineage.get("parent_effective_target") == parent_binding.placement.effective_target
            and lineage.get("parent_placement_version") == authorized.get("placement_version")
            and lineage.get("parent_placement_version") == parent_binding.placement.placement_version
            and authorized.get("effective_target") == placement.get("actual")
            and authorized.get("effective_target") == parent_binding.placement.effective_target
            and lineage.get("parent_task_id") == authorized.get("parent_task_id")
        )

    def _activation_allows_child(self, parent, activation, effective_target, placement_version):
        authorized = activation.get("authorized_child_lineage") if isinstance(activation, dict) else None
        return bool(
            isinstance(authorized, dict)
            and authorized.get("parent_task_id") == parent["id"]
            and authorized.get("parent_run_id") == parent["run_id"]
            and authorized.get("max_depth") == 1
            and authorized.get("placement_version") == placement_version
            and authorized.get("effective_target") == effective_target
        )

    def _remote_activation_matches(self, task_id, identity, placement, *, require_fresh=True):
        """Check current activation; freshness applies only before claim/admission."""
        if not isinstance(identity, dict) or not isinstance(placement, dict):
            return False
        supplied = identity.get("qualified_activation")
        owner_id = str(supplied.get("task_id") or "") if isinstance(supplied, dict) else ""
        recorded = self._latest_remote_activation(owner_id) if owner_id else None
        if not isinstance(supplied, dict) or not isinstance(recorded, dict):
            return False
        if supplied != recorded or identity.get("actor") != recorded.get("credential_actor"):
            return False
        if not any(kind == "task.remote_activation_accepted"
                   for kind, _ in self._remote_activation_history(owner_id, recorded.get("activation_id"))):
            return False
        if recorded.get("runtime_session_id") != self.runtime_session_id:
            return False
        if recorded.get("runtime_epoch") != self.store._current_runtime_epoch():
            return False
        try:
            expiry = datetime.fromisoformat(recorded["expires_at"].replace("Z", "+00:00"))
        except (KeyError, TypeError, ValueError):
            return False
        marker = self._remote_drain(owner_id, recorded.get("activation_id"))
        if marker is not None:
            if marker["qualification"] != recorded:
                return False
            if str(task_id) != owner_id and not self._drain_continuation_matches(task_id, marker):
                return False
        if require_fresh:
            if marker is not None:
                if not self._drain_continuation_matches(task_id, marker):
                    return False
            elif expiry.tzinfo is None or expiry <= datetime.now(timezone.utc):
                return False
        if (recorded.get("task_id") != owner_id
                or recorded.get("executor_incarnation") != placement.get("executor_incarnation")
                or recorded.get("evidence_digest") != placement.get("verification", {}).get("evidence_digest")
                or recorded.get("effective_target") != placement.get("actual")):
            return False
        if require_fresh:
            try:
                actor = self.prepared_child_executor(owner_id, require_live=True)
            except (AuthorizationError, ConflictError, LeaseError, ValidationError):
                return False
            if actor is not None and recorded.get("credential_actor") != actor:
                return False
        if not self._activation_scope_matches(task_id, recorded, placement):
            return False
        from .remote_worker_deployment import deployment_binding_from_task
        try:
            binding = deployment_binding_from_task(
                self._task_resource(self.store.get_task(owner_id))
            )
        except (TypeError, ValueError, KeyError):
            return False
        return recorded.get("binding_digest") == binding.digest()

    def assert_remote_activation_admissible(self, task_id, qualification):
        """Allow ordinary queued tasks or the exact quiescent recovery receipt."""
        from .remote_worker_deployment import deployment_binding_from_task
        task = self._task_resource(self.store.get_task(task_id))
        binding = deployment_binding_from_task(task)
        actor = self.prepared_child_executor(task_id, require_live=True)
        if actor is not None and qualification.get("credential_actor") != actor:
            raise ConflictError("prepared child executor differs from its admitted identity")
        if (qualification.get("task_id") != str(task_id)
                or qualification.get("run_id") != binding.admission_identity.run_id
                or qualification.get("binding_digest") != binding.digest()
                or qualification.get("effective_target") != binding.placement.effective_target):
            raise ConflictError("remote activation is foreign to the current binding")
        if task["state"] == "queued":
            return
        recovery = self.store.placement_recovery(task_id)
        replacement = recovery.get("qualification") if isinstance(recovery, dict) else None
        placement = {
            "actual": qualification.get("effective_target"),
            "verification": {"evidence_digest": qualification.get("evidence_digest")},
            "executor_incarnation": qualification.get("executor_incarnation"),
        }
        if (task["state"] not in {"failed", "cancelled"}
                or not isinstance(recovery, dict)
                or not isinstance(replacement, dict)
                or binding.placement.effective_target.get("kind") != "runpod"
                or binding.placement.placement_version <= 0
                or recovery.get("task_id") != str(task_id)
                or recovery.get("run_id") != task["run_id"]
                or recovery.get("task_version") != task["version"]
                or recovery.get("placement_version") != binding.placement.placement_version
                or recovery.get("decision_digest") != binding.placement.recovery_decision_digest
                or recovery.get("original_target") != binding.placement.original_target
                or recovery.get("replacement_target") != binding.placement.effective_target
                or replacement.get("verified") is not True
                or replacement.get("target") != binding.placement.effective_target
                or qualification.get("authorized_child_lineage", {}).get("placement_version")
                != binding.placement.placement_version
                or not self._placement_recovery_qualification_matches(task_id, placement)):
            raise ConflictError("remote activation requires a queued task or exact recovered placement")
        row = self.store.conn.execute("SELECT * FROM tasks WHERE id=?", (str(task_id),)).fetchone()
        current = self._assert_placement_recovery_quiescent(row, self._delegated_children(str(task_id)))
        if current["status"] != "prepared":
            raise ConflictError("recovered activation has no prepared replacement binding")

    def prepared_child_executor(self, task_id, *, require_live=False):
        """Derive child custody from the existing admitted staged lineage.

        This is owner composition, not worker authority. No caller-supplied
        actor or parent can select a credential generation. Terminal cleanup
        retains the same immutable child/parent identity without requiring a
        live parent; starting or claiming always requires its exact live lease.
        """
        child = self.store.conn.execute("SELECT * FROM tasks WHERE id=?", (str(task_id),)).fetchone()
        if child is None:
            raise NotFoundError("prepared child task is unavailable")
        spec = self.store._spec(child)
        lineage = spec.get("delegated_parent")
        if lineage is None:
            return None
        request = self.store._execution_request_from_row(child)
        if (child["capability"] != "vibecomfy.run" or not isinstance(request, dict)
                or request.get("remote_activation_required") is not True):
            return None
        if not isinstance(lineage, dict) or request.get("target", {}).get("kind") != "runpod":
            raise ConflictError("remote child is not an admitted prepared run stage")
        parent = self.store.conn.execute("SELECT * FROM tasks WHERE id=?", (lineage.get("parent_task_id"),)).fetchone()
        attempt = self.store.conn.execute("SELECT * FROM attempts WHERE id=?", (lineage.get("parent_attempt_id"),)).fetchone()
        if parent is None or attempt is None:
            raise ConflictError("prepared child parent binding is unavailable")
        project = self.store.conn.execute("SELECT project_id FROM runs WHERE id=?", (child["run_id"],)).fetchone()[0]
        parent_project = self.store.conn.execute("SELECT project_id FROM runs WHERE id=?", (parent["run_id"],)).fetchone()[0]
        policy = self._child_policy(self.store._spec(parent).get("child_delegation"))
        stage = next((item for item in policy.get("stages", []) if item["name"] == spec.get("delegated_stage")), None)
        if (stage is None or stage["capability_id"] != child["capability"]
                or stage["capability_digest"] != child["capability_digest"]
                or stage.get("execution_request") != {k: v for k, v in request.items() if k != "inputs"}
                or lineage.get("policy_digest") != sha256_bytes(canonical_json(policy).encode())
                or project != parent_project or lineage.get("project_id") != project
                or attempt["task_id"] != parent["id"]
                or any(lineage.get(key) != attempt[column] for key, column in (
                    ("parent_lease_id", "lease_id"), ("parent_fence", "fence"),
                    ("runtime_epoch", "runtime_epoch"), ("executor_id", "executor_id")))):
            raise ConflictError("prepared child differs from its admitted parent stage")
        if require_live:
            lease = {"lease_id": lineage["parent_lease_id"], "fence": lineage["parent_fence"], "runtime_epoch": lineage["runtime_epoch"]}
            self._live_delegating_parent(attempt["id"], lease, identity=None)
        return "astrid-prepared-" + hashlib.sha256(str(task_id).encode()).hexdigest()[:32]

    @_durable_mutation
    def record_remote_activation(self, task_id, qualification, *, identity=None):
        """Commit owner-observed acceptance before the private final ACK.

        The existing record RPC is the callback transport: qualification and its
        acceptance receipt are durable in one transaction, with no new wire
        fields or worker authority. Exact replay returns that same receipt.
        """
        actor = self._require_placement_recovery_owner(identity)
        if actor != "owner":
            raise AuthorizationError("remote activation requires the Runtime owner actor")
        if not isinstance(qualification, dict):
            raise ValidationError("remote activation qualification is required")
        required = {
            "activation_id", "task_id", "run_id", "credential_actor",
            "binding_digest", "deployment_digest", "evidence_digest",
            "effective_target", "executor_incarnation", "runtime_session_id",
            "runtime_epoch", "expires_at", "observation_digest",
            "authorized_child_lineage",
        }
        if set(qualification) != required or qualification.get("task_id") != str(task_id):
            raise ValidationError("remote activation qualification has an invalid shape")
        from .remote_worker_deployment import deployment_binding_from_task
        task = self._task_resource(self.store.get_task(task_id))
        binding = deployment_binding_from_task(task)
        prepared_actor = self.prepared_child_executor(task_id)
        if prepared_actor is not None and qualification["credential_actor"] != prepared_actor:
            raise ConflictError("prepared activation executor differs from its admitted child")
        if (qualification["run_id"] != binding.admission_identity.run_id
                or qualification["binding_digest"] != binding.digest()
                or qualification["effective_target"] != binding.placement.effective_target
                or qualification["runtime_session_id"] != self.runtime_session_id
                or qualification["runtime_epoch"] != self.store._current_runtime_epoch()):
            raise ConflictError("remote activation is stale or foreign to the admitted task")
        lineage = qualification["authorized_child_lineage"]
        expected_lineage = {
            "parent_task_id": binding.admission_identity.task_id,
            "parent_run_id": binding.admission_identity.run_id,
            "max_depth": 1,
            "placement_version": binding.placement.placement_version,
            "effective_target": binding.placement.effective_target,
        }
        if lineage != expected_lineage:
            raise ConflictError("remote activation child lineage is not explicitly authorized")
        for field in ("binding_digest", "deployment_digest", "evidence_digest", "observation_digest"):
            self._placement_evidence_digest(qualification[field], field)
        try:
            expiry = datetime.fromisoformat(qualification["expires_at"].replace("Z", "+00:00"))
        except (AttributeError, ValueError) as exc:
            raise ValidationError("remote activation expiry is invalid") from exc
        if expiry.tzinfo is None:
            raise ConflictError("remote activation has expired")
        if not all(isinstance(qualification[field], str) and qualification[field] for field in
                   ("activation_id", "credential_actor", "executor_incarnation")):
            raise ValidationError("remote activation identity is incomplete")
        latest = self._latest_remote_activation(task_id)
        history = self._remote_activation_history(task_id, qualification.get("activation_id"))
        if history:
            if any(kind == "task.remote_activation_revoked" for kind, _payload in history):
                raise ConflictError("remote activation generation is permanently revoked")
            if (any(kind == "task.remote_activation_qualified" and payload == qualification for kind, payload in history)
                    and any(kind == "task.remote_activation_accepted" for kind, _ in history)):
                # An exact accepted owner replay is only a receipt for the prior
                # commit. It can arrive after the activation TTL or a claim.
                return qualification
            raise ConflictError("remote activation generation was already used")
        if expiry <= datetime.now(timezone.utc):
            raise ConflictError("remote activation has expired")
        if latest is not None:
            raise ConflictError("another remote activation is already qualified")
        self.assert_remote_activation_admissible(task_id, qualification)
        self.store._append_event(
            task["run_id"], str(task_id), "task.remote_activation_qualified", qualification
        )
        self.store._append_event(
            task["run_id"], str(task_id), "task.remote_activation_accepted",
            {"activation_id": qualification["activation_id"]},
        )
        return qualification

    @_durable_mutation
    def revoke_remote_activation(self, task_id, activation_id, *, identity=None, qualification=None):
        actor = self._require_placement_recovery_owner(identity)
        if actor != "owner":
            raise AuthorizationError("remote activation revocation requires the Runtime owner actor")
        latest = self._latest_remote_activation(task_id)
        unaccepted = (
            latest is None and isinstance(qualification, dict)
            and qualification.get("task_id") == str(task_id)
            and qualification.get("activation_id") == activation_id
            and not self._remote_activation_history(task_id, activation_id)
        )
        if not unaccepted and (latest is None or latest.get("activation_id") != activation_id):
            raise ConflictError("remote activation is no longer current")
        task = self.store.get_task(task_id)
        self.store._append_event(
            task["run"]["id"], str(task_id), "task.remote_activation_revoked",
            {"activation_id": activation_id, "revoked_at": now()},
        )
        self.store.contain_delegated_children(task_id, reason="parent_authority_revoked")

    def _assert_attempt_identity(self, row, identity):
        if not row:
            return
        self._assert_executor_identity(identity, row["executor_id"])
        keys = row.keys()
        # Checkpoint rows name their attempt in attempt_id; attempt rows use id.
        # A row that names no attempt has no attempt authority to retire.
        attempt_key = "attempt_id" if "checkpoint_path" in keys else "id"
        self.store.assert_attempt_not_abandoned(row[attempt_key] if attempt_key in keys else None)
        if identity is None:
            return
        activation = identity.get("qualified_activation") if isinstance(identity, dict) else None
        if isinstance(activation, dict):
            marker = self._remote_drain(activation.get("task_id"), activation.get("activation_id"))
            cutoff = marker.get("parent_attempt") if marker else None
            # Checkpoint rows authorize an exact pre-existing resume replay;
            # their fresh resume path is gated separately before any mutation.
            if (cutoff is not None and str(row["task_id"]) == activation.get("task_id")
                    and "checkpoint_path" not in row.keys() and "id" in row.keys()
                    and not int(row["settled"] or 0)):
                expected = {"id": cutoff["parent_attempt_id"], "lease_id": cutoff["parent_lease_id"],
                            "fence": cutoff["parent_fence"], "executor_id": cutoff["executor_id"],
                            "runtime_epoch": cutoff["runtime_epoch"]}
                if any(row[field] != value for field, value in expected.items()):
                    raise AuthorizationError("attempt is outside remote drain cutoff")
        qualified_identity = (
            isinstance(identity, dict)
            and isinstance(identity.get("qualified_activation"), dict)
        )
        binding = self.store.execution_binding(row["task_id"])
        if not binding or not binding.get("actual_target"):
            if qualified_identity:
                raise AuthorizationError("qualified credential is not bound to this admitted task")
            return
        placement = self._trusted_execution_placement(identity)
        if placement is None:
            raise AuthorizationError("worker credential has no execution placement")
        if ((self._task_requires_remote_activation(row["task_id"])
             or qualified_identity)
                and not self._remote_activation_matches(
                    row["task_id"], identity, placement, require_fresh=False
                )):
            raise AuthorizationError("remote activation is missing, revoked, or stale")
        if (
            not execution_placement_matches(binding["resolved_target"], placement)
            or binding.get("actual_target") != placement["actual"]
            or binding.get("verification") != placement["verification"]
            or binding.get("executor_incarnation") != placement["executor_incarnation"]
            or not self._placement_recovery_qualification_matches(row["task_id"], placement)
        ):
            raise AuthorizationError("worker credential does not match the fenced execution binding")

    @_verified_mutation
    def create_project(self, body, *, idempotency_key=None):
        name = str(body.get("name") or "")
        slug = str(body.get("slug") or "-".join(name.lower().split()))
        slug = "".join(ch if ch.isalnum() or ch in "-_" else "-" for ch in slug).strip("-") or "project"
        return self.store.create_project(slug, name, body.get("metadata"), idempotency_key=idempotency_key)

    def get_project(self, selector):
        return self.store.get_project(selector)

    def list_projects(self, *, cursor=None, limit=PAGE_DEFAULT_LIMIT):
        rows = self.store.conn.execute("SELECT id, created_at FROM projects ORDER BY created_at, id").fetchall()
        return _page_rows(rows, scope="projects", cursor=cursor, limit=limit,
                          key_fn=lambda row: (str(row["created_at"]), str(row["id"])),
                          resource_fn=lambda row: self._project_resource(self.store.get_project(row["id"])))

    @_verified_mutation
    def select_project(self, actor_id, selector, *, scope="workspace", idempotency_key=None):
        value = self.store.select_project(actor_id, selector, scope, idempotency_key=idempotency_key)
        return {
            "actor_id": value["actor_id"],
            "scope": value["scope"],
            "project": self._project_resource(value["project"]),
            "updated_at": value["updated_at"],
        }

    def current_project(self, actor_id):
        value = self.store.current_project(actor_id)
        return {
            "actor_id": value["actor_id"],
            "scope": value["scope"],
            "project": self._project_resource(value["project"]),
            "updated_at": value["updated_at"],
        }

    @_verified_mutation
    def update_project(self, selector, body, *, idempotency_key=None):
        return self.store.update_project(selector, name=body.get("name"), metadata=body.get("metadata"), expected_version=body.get("expected_version"), idempotency_key=idempotency_key)

    def _project_resource(self, value):
        return {"project_id": value["id"], "realm_id": value["realm_id"], "slug": value["slug"], "name": value["name"], "metadata": value.get("metadata", {}), "version": value["version"], "created_at": value["created_at"], "updated_at": value["updated_at"], "archived": False}

    def _timeline_resource(self, timeline_id):
        from .timeline_catalog import timeline_resource
        return timeline_resource(self.store.conn, timeline_id)

    def _timeline_public_resource(self, timeline_id):
        """Expose timeline identity/head metadata without legacy document bytes."""
        resource = self._timeline_resource(timeline_id)
        for key in ("config", "registry", "config_version", "revision_id", "content_digest"):
            resource.pop(key, None)
        return resource

    def _legacy_timeline_payload(self, timeline_id):
        """Return the lossless canonical bytes for the legacy timeline projection."""
        resource = self._timeline_resource(timeline_id)
        payload = {key: copy.deepcopy(resource[key]) for key in ("shots", "references")}
        if "config" in resource:
            payload.update({"slug": resource.get("slug", timeline_id), "name": resource.get("name", timeline_id), "config": copy.deepcopy(resource["config"]), "registry": copy.deepcopy(resource.get("registry", {}))})
        return payload

    def _record_legacy_timeline_revision(self, timeline_id, resource=None):
        """Record the exact legacy timeline projection as an immutable revision."""
        resource = resource or self._timeline_resource(timeline_id)
        revision = self._record_internal_revision(
            resource["project_id"], timeline_id, self._legacy_timeline_payload(timeline_id)
        )
        resource.update({"revision_id": revision["revision_id"], "content_digest": revision["content_digest"]})
        return revision

    def _record_internal_revision(self, project_id, timeline_id, payload, *, revision_id=None):
        """Insert-or-resolve one immutable internal revision and verify its closure."""
        project = self.store.get_project(project_id)
        timeline = self.store.conn.execute("SELECT project_id FROM timelines WHERE id=?", (timeline_id,)).fetchone()
        scoped_shot = timeline_id.removeprefix("shot:") if timeline_id.startswith("shot:") else None
        scoped = scoped_shot and self.store.conn.execute("SELECT project_id FROM project_shots WHERE id=?", (scoped_shot,)).fetchone()
        if timeline is None and (not scoped or scoped["project_id"] != project["id"]):
            raise ValidationError("internal timeline revision has an invalid project/timeline identity", details={"project_id": project["id"], "timeline_id": timeline_id})
        if timeline is not None and timeline["project_id"] != project["id"]:
            raise ValidationError("internal timeline revision has an invalid project/timeline identity", details={"project_id": project["id"], "timeline_id": timeline_id})
        if not isinstance(payload, dict):
            raise ValidationError("internal timeline revision payload must be an object")
        revision_id = self._revision_id(revision_id or new_id(), "internal timeline revision_id")
        payload = copy.deepcopy(payload)
        encoded = canonical_json(payload)
        digest = "sha256:" + hashlib.sha256(encoded.encode("utf-8")).hexdigest()
        existing = self.store.conn.execute("SELECT * FROM internal_timeline_revisions WHERE id=?", (revision_id,)).fetchone()
        if existing:
            if (existing["project_id"], existing["timeline_id"], existing["content_digest"], existing["payload_json"]) != (project["id"], timeline_id, digest, encoded):
                raise ConflictError("internal timeline revision identity was reused with different bytes", details={"revision_id": revision_id})
        else:
            self.store.conn.execute("INSERT INTO internal_timeline_revisions(id, project_id, timeline_id, payload_json, content_digest, created_at) VALUES (?, ?, ?, ?, ?, ?)", (revision_id, project["id"], timeline_id, encoded, digest, now()))
        return {"revision_id": revision_id, "project_id": project["id"], "timeline_id": timeline_id, "content_digest": digest, "payload": payload}

    def _shot_revision_payload(self, row):
        return {
            "name": row["name"],
            "metadata": json.loads(row["metadata_json"]),
            "archived": bool(row["archived_at"]),
            "items": [self._shot_item_resource(item) for item in self.store.conn.execute("SELECT * FROM shot_items WHERE shot_id=? ORDER BY sort_key, id", (row["id"],))],
        }

    def _record_legacy_shot_revision(self, project_id, row):
        """Materialize the exact project-shot projection as child+internal revisions."""
        payload = self._complete_shot_payload(self._shot_revision_payload(row), new_id())
        internal_payload = {"shot_id": row["id"], "metadata": payload["metadata"], "items": payload["items"], "archived": payload["archived"]}
        # Legacy project shots have no separate timeline aggregate. The scoped
        # identity is explicit and cannot be confused with a parent timeline.
        internal_id = new_id()
        self._record_internal_revision(project_id, f"shot:{row['id']}", internal_payload, revision_id=internal_id)
        payload["internal_timeline_revision_id"] = internal_id
        encoded = canonical_json(payload)
        digest = "sha256:" + hashlib.sha256(encoded.encode("utf-8")).hexdigest()
        revision_id = new_id()
        timestamp = now()
        self.store.conn.execute("INSERT INTO shot_revisions(id, project_id, shot_id, internal_timeline_revision_id, payload_json, content_digest, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)", (revision_id, project_id, row["id"], internal_id, encoded, digest, timestamp))
        self.store.conn.execute("INSERT INTO shot_revision_heads(shot_id, project_id, revision_id, updated_at) VALUES (?, ?, ?, ?) ON CONFLICT(shot_id) DO UPDATE SET project_id=excluded.project_id, revision_id=excluded.revision_id, updated_at=excluded.updated_at", (row["id"], project_id, revision_id, timestamp))
        return {"revision_id": revision_id, "internal_timeline_revision_id": internal_id, "content_digest": digest, "payload": payload}

    @staticmethod
    def _validate_published_shot_payload(value):
        payload = value.get("payload") or {}
        if not isinstance(payload.get("metadata", {}), dict) or not isinstance(payload.get("items", []), list):
            raise ValidationError("shot revision payload cannot be projected losslessly")
        for item in payload.get("items", []):
            if not isinstance(item, dict) or not isinstance(item.get("item_id", item.get("id")), str) or not item.get("media_id"):
                raise ValidationError("shot revision items cannot be projected losslessly")

    def _validate_published_text_bindings(self, project_id, shot_id, payload, *, require_current):
        """Verify immutable shot text pins against the registered text authority."""
        bindings = payload.get("text_bindings", [])
        if not isinstance(bindings, list):
            raise ValidationError("shot text_bindings must be a list")
        scripts = []
        seen_binding_ids = set()
        seen_slots = set()
        for descriptor in bindings:
            if not isinstance(descriptor, dict):
                raise ValidationError("shot text binding must be an object")
            binding_id = descriptor.get("binding_id")
            if not isinstance(binding_id, str) or not binding_id:
                raise ValidationError(
                    "embedded shot text is not authoritative; register it with the shot text binding service, then publish its binding_id and head",
                    details={"shot_id": shot_id, "action": "register_text_binding"},
                )
            if binding_id in seen_binding_ids:
                raise ValidationError("shot text_bindings contain a duplicate binding_id", details={"binding_id": binding_id})
            seen_binding_ids.add(binding_id)
            row = self.store.conn.execute(
                "SELECT * FROM shot_text_bindings WHERE id=? AND project_id=?",
                (binding_id, project_id),
            ).fetchone()
            if row is None:
                raise ConflictError(
                    "shot text binding is not registered in this project; register it before publishing",
                    details={"shot_id": shot_id, "binding_id": binding_id, "action": "register_text_binding"},
                )
            if str(row["shot_id"]) != shot_id:
                raise ConflictError("shot text binding belongs to a different shot", details={"binding_id": binding_id})
            head = descriptor.get("head")
            if isinstance(head, bool) or not isinstance(head, int) or head < 1:
                raise ValidationError("shot text binding descriptor requires its positive pinned head", details={"binding_id": binding_id})
            if require_current and head != int(row["head_seq"]):
                raise ConflictError(
                    "shot text binding head is stale; read the current binding and republish the shot",
                    details={"binding_id": binding_id, "expected_head": head, "actual_head": int(row["head_seq"]), "action": "refresh_text_binding_pin"},
                )
            # Verify the complete registered event chain and current authority
            # object before accepting any historical pin from that stream.
            resource = self._text_binding_resource(row, include_absent=True)
            for field in ("project_id", "shot_id", "kind", "slot", "event_stream_id"):
                if field in descriptor and descriptor[field] != resource[field]:
                    raise ConflictError("shot text binding descriptor identity does not match its registered binding", details={"binding_id": binding_id, "field": field})
            slot_key = (resource["kind"], resource["slot"])
            if slot_key in seen_slots:
                raise ValidationError("shot text_bindings contain duplicate kind/slot descriptors", details={"kind": resource["kind"], "slot": resource["slot"]})
            seen_slots.add(slot_key)
            event = self.store.conn.execute(
                "SELECT kind, payload_json, created_at FROM shot_text_binding_events WHERE binding_id=? AND seq=?",
                (binding_id, head),
            ).fetchone()
            if event is None:
                raise ConflictError("pinned shot text binding event is missing", details={"binding_id": binding_id, "head": head})
            event_payload = json.loads(event["payload_json"])
            if event_payload.get("state", "present") != "present":
                raise ConflictError("pinned shot text binding is absent", details={"binding_id": binding_id, "head": head})
            media_id = event_payload.get("media_id")
            content_hash = event_payload.get("content_hash")
            if not isinstance(media_id, str) or not media_id.startswith("sha256:") or content_hash != media_id:
                raise ConflictError("pinned shot text binding event has invalid content provenance", details={"binding_id": binding_id, "head": head})
            for field, expected in (("media_id", media_id), ("content_hash", content_hash)):
                if descriptor.get(field) != expected:
                    raise ConflictError("shot text binding descriptor does not match its pinned event", details={"binding_id": binding_id, "head": head, "field": field})
            media = self._verify_text_object(project_id, media_id)
            if descriptor.get("byte_size") != int(media["size"]):
                raise ConflictError("shot text binding byte_size does not match its pinned media", details={"binding_id": binding_id, "head": head})
            if descriptor.get("mime_type") != str(media["media_type"]):
                raise ConflictError("shot text binding mime_type does not match its pinned media", details={"binding_id": binding_id, "head": head})
            if "created_at" in descriptor and descriptor["created_at"] != resource["created_at"]:
                raise ConflictError("shot text binding created_at does not match its registered identity", details={"binding_id": binding_id})
            if "updated_at" in descriptor and descriptor["updated_at"] != event["created_at"]:
                raise ConflictError("shot text binding updated_at does not match its pinned event", details={"binding_id": binding_id, "head": head})
            text_path = self.cas.path_for(media["digest"])
            text_bytes = text_path.read_bytes()
            try:
                text = text_bytes.decode("utf-8", errors="strict")
            except UnicodeDecodeError as exc:
                raise ConflictError("pinned shot text binding bytes are not valid UTF-8", details={"binding_id": binding_id, "head": head}) from exc
            if "text" in descriptor and descriptor["text"] != text:
                raise ConflictError("embedded text does not match its registered shot text binding", details={"binding_id": binding_id, "head": head, "field": "text"})
            if resource["kind"] == "voiceover_script":
                scripts.append((binding_id, text))
        metadata = payload.get("metadata", {})
        if isinstance(metadata, dict) and "voiceover_script" in metadata:
            script = metadata["voiceover_script"]
            if not scripts:
                raise ValidationError(
                    "metadata.voiceover_script has no registered voiceover_script binding; register the script and publish its text binding descriptor",
                    details={"shot_id": shot_id, "action": "register_text_binding"},
                )
            if not isinstance(script, str) or all(script != value for _, value in scripts):
                raise ConflictError("metadata.voiceover_script does not match the registered voiceover_script binding", details={"shot_id": shot_id})

    def _apply_published_shot_projection(self, project_id, value, timestamp):
        """Keep the mutable shot projection semantically equal to a new child revision."""
        self._validate_published_shot_payload(value)
        payload = value["payload"]
        row = self.store.conn.execute("SELECT * FROM project_shots WHERE id=? AND project_id=?", (value["shot_id"], project_id)).fetchone()
        name = str(payload.get("name") or value["shot_id"])
        archived_at = timestamp if payload.get("archived") is True else None
        metadata = canonical_json(payload.get("metadata", {}))
        if row is None:
            self.store.conn.execute("INSERT INTO project_shots(id, project_id, name, metadata_json, version, created_at, updated_at, archived_at) VALUES (?, ?, ?, ?, 1, ?, ?, ?)", (value["shot_id"], project_id, name, metadata, timestamp, timestamp, archived_at))
        else:
            self.store.conn.execute("UPDATE project_shots SET name=?, metadata_json=?, version=version+1, updated_at=?, archived_at=? WHERE id=? AND project_id=?", (name, metadata, timestamp, archived_at, value["shot_id"], project_id))
            self.store.conn.execute("DELETE FROM shot_items WHERE shot_id=?", (value["shot_id"],))
        for index, item in enumerate(payload.get("items", [])):
            media_id = str(item["media_id"]).removeprefix("sha256:")
            self.store.conn.execute("INSERT INTO shot_items(id, shot_id, media_id, sort_key, source_frame, metadata_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)", (str(item.get("item_id", item.get("id"))), value["shot_id"], media_id, f"{index:08d}", item.get("source_frame"), canonical_json(item.get("metadata", {})), timestamp))

    def _shot_projection_matches_revision(self, project_id, value):
        """Check the mutable shot projection against an immutable child payload."""
        row = self.store.conn.execute(
            "SELECT * FROM project_shots WHERE id=? AND project_id=?", (value["shot_id"], project_id)
        ).fetchone()
        if row is None:
            return False
        payload = value.get("payload") or {}
        if str(row["name"]) != str(payload.get("name") or value["shot_id"]):
            return False
        if json.loads(row["metadata_json"]) != payload.get("metadata", {}):
            return False
        if bool(row["archived_at"]) != bool(payload.get("archived", False)):
            return False
        actual = []
        for item in self.store.conn.execute(
            "SELECT * FROM shot_items WHERE shot_id=? ORDER BY sort_key, id", (value["shot_id"],)
        ):
            actual.append({
                "item_id": str(item["id"]),
                "media_id": str(item["media_id"]).removeprefix("sha256:"),
                "source_frame": item["source_frame"],
                "metadata": json.loads(item["metadata_json"]),
            })
        expected = []
        for item in payload.get("items", []):
            expected.append({
                "item_id": str(item.get("item_id", item.get("id"))),
                "media_id": str(item.get("media_id", "")).removeprefix("sha256:"),
                "source_frame": item.get("source_frame"),
                "metadata": item.get("metadata", {}),
            })
        return actual == expected

    def _verify_shot_head_projection(self, project_id, shot_id, revision_id):
        """Verify the current shot head and projection are mutually consistent."""
        row = self.store.conn.execute(
            "SELECT * FROM shot_revisions WHERE id=? AND project_id=? AND shot_id=?",
            (revision_id, project_id, shot_id),
        ).fetchone()
        if row is None:
            raise ConflictError("shot head points to a missing revision", details={"shot_id": shot_id, "revision_id": revision_id})
        payload = json.loads(row["payload_json"])
        value = {"shot_id": shot_id, "revision_id": revision_id, "payload": payload}
        if self._revision_digest(payload) != row["content_digest"] or not self._shot_projection_matches_revision(project_id, value):
            raise ConflictError(
                "shot head and mutable projection do not match",
                details={"shot_id": shot_id, "revision_id": revision_id},
            )

    def _record_timeline_revision(self, timeline_id, resource=None):
        resource = resource or self._timeline_resource(timeline_id)
        self.store.conn.execute(
            "INSERT OR IGNORE INTO timeline_revisions(timeline_id, version, shots_json, references_json, created_at) VALUES (?, ?, ?, ?, ?)",
            (timeline_id, resource["version"], canonical_json(resource["shots"]), canonical_json(resource["references"]), now()),
        )

    def _timeline_revision(self, timeline_id, version):
        row = self.store.conn.execute("SELECT * FROM timeline_revisions WHERE timeline_id=? AND version=?", (timeline_id, version)).fetchone()
        if row:
            return {"timeline_id": timeline_id, "version": int(row["version"]), "shots": json.loads(row["shots_json"]), "references": json.loads(row["references_json"]), "created_at": row["created_at"]}
        current = self._timeline_resource(timeline_id)
        if int(current["version"]) == int(version):
            return {"timeline_id": timeline_id, "version": current["version"], "shots": current["shots"], "references": current["references"], "created_at": now()}
        raise NotFoundError("timeline revision not found", details={"timeline_id": timeline_id, "version": version})

    @staticmethod
    def _expected_version(body):
        value = (body or {}).get("expected_version")
        if isinstance(value, bool) or not isinstance(value, int) or value < 1:
            raise ValidationError("expected_version must be a positive integer")
        return value

    @staticmethod
    def _require_timeline_command():
        reject_retired_timeline_writer()

    def update_timeline(self, timeline_id, body, *, idempotency_key=None):
        self._require_timeline_command()

    def replace_timeline_clip(self, timeline_id, body, *, idempotency_key=None):
        self._require_timeline_command()

    def _timeline_name(self, name):
        if not isinstance(name, str):
            raise ValidationError("timeline name must be a string")
        name = name.strip()
        if not 1 <= len(name) <= 120:
            raise ValidationError("timeline name must be 1–120 characters after trimming")
        return name

    @_durable_mutation
    def rename_timeline(self, project_id, timeline_id, body, *, idempotency_key=None):
        if not isinstance(body, dict) or set(body) != {"name"}:
            raise ValidationError("rename requires only name")
        name = self._timeline_name(body["name"])
        project = self.store.get_project(project_id)
        request_hash = hashlib.sha256(canonical_json({"project_id": project["id"], "timeline_id": timeline_id, "name": name}).encode()).hexdigest()
        replay = self._command_replay("timeline.rename", timeline_id, idempotency_key, request_hash, project_id=project["id"])
        if replay is not None:
            return replay
        row = self.store.conn.execute("SELECT 1 FROM timelines WHERE id=? AND project_id=?", (timeline_id, project["id"])).fetchone()
        if row is None:
            raise NotFoundError("timeline not found", details={"timeline_id": timeline_id, "project_id": project["id"]})
        self.store.conn.execute("UPDATE timelines SET name=? WHERE id=?", (name, timeline_id))
        resource = self._timeline_public_resource(timeline_id)
        event_id = self.store._append_timeline_event(timeline_id, "timeline.renamed", {"project_id": project["id"], "name": name})
        event_seq = self.store.conn.execute("SELECT COUNT(*) FROM timeline_events WHERE timeline_id=?", (timeline_id,)).fetchone()[0]
        return self._command_record("timeline.rename", timeline_id, idempotency_key, request_hash, resource,
                                    project_id=project["id"], event_ids=(event_id,), primary_stream_id=timeline_id,
                                    resulting_stream_seq=event_seq)

    @_durable_mutation
    def create_timeline(self, project_id, timeline_id, *, name=None, idempotency_key=None, _bootstrap=True):
        if not isinstance(timeline_id, str) or not timeline_id:
            raise ValidationError("timeline_id is required")
        if name is not None:
            name = self._timeline_name(name)
        project = self.store.get_project(project_id)
        request_hash = hashlib.sha256(canonical_json({
            "project_id": project["id"], "timeline_id": timeline_id, "name": name,
        }).encode()).hexdigest()
        # A create request has no pre-existing aggregate, so keep its key in
        # one operation namespace and bind project/timeline identity in the
        # request hash. Reusing a key for any changed request is a conflict;
        # a retry gets the exact committed resource and receipt.
        replay = self._command_replay("timeline.create", "timelines", idempotency_key, request_hash, project_id=project["id"])
        if replay is not None:
            return replay
        if self.store.conn.execute("SELECT 1 FROM timelines WHERE id=?", (timeline_id,)).fetchone():
            return self._adopt_empty_shell_create(project["id"], timeline_id, name, idempotency_key, request_hash)
        if self._timeline_commit_provider is not None and not timeline_scope_is_empty(self.store.conn, timeline_id, project_id=project["id"]):
            raise ConflictError(f"headless timeline holds authored content (timeline:{timeline_id})", details={"status": "refused", "reason": "headless_content_not_empty"})
        timestamp = now()
        self.store.conn.execute("INSERT INTO timelines(id, project_id, version, name, created_at, archived_at) VALUES (?, ?, 1, ?, ?, NULL)", (timeline_id, project["id"], name, timestamp))
        resource = self._timeline_resource(timeline_id)
        if _bootstrap:
            self._record_timeline_revision(timeline_id, resource)
            self._record_legacy_timeline_revision(timeline_id, resource)
        event_id = self.store._append_timeline_event(timeline_id, "timeline.created", {"project_id": project["id"]})
        event_seq = self.store.conn.execute("SELECT COUNT(*) FROM timeline_events WHERE timeline_id=?", (timeline_id,)).fetchone()[0]
        result = self._command_record(
            "timeline.create", "timelines", idempotency_key, request_hash,
            resource, project_id=project["id"], event_ids=(event_id,),
            primary_stream_id=timeline_id, resulting_stream_seq=event_seq,
        )
        if self._timeline_commit_provider is not None and _bootstrap:
            # Allocate creation's receipt before the separate publication.
            # Finalize its editable head inside this same outer transaction.
            commits, _ = self._timeline_commits()
            commits.bootstrap(project["id"], timeline_id, authorize=self._assert_mutation_admitted)
            resource = self._timeline_resource(timeline_id)
            if idempotency_key is not None:
                self.store.conn.execute(
                    "UPDATE command_idempotency SET result_json=? WHERE txn_id=?",
                    (compact_result("timeline.create", resource), result["receipt"]["receipt_id"]),
                )
                return self._command_replay("timeline.create", "timelines", idempotency_key, request_hash, project_id=project["id"])
            return resource
        return result

    def _adopt_empty_shell_create(self, project_id, timeline_id, name, idempotency_key, request_hash):
        """Repair an exact same-ID empty headless shell inside this create's transaction.

        Anything else (headed, non-empty, archived, another project, or another
        name) keeps the original conflict and writes nothing.
        """
        from .timeline_commit import CommitRejected
        row = self.store.conn.execute("SELECT project_id, name, archived_at FROM timelines WHERE id=?", (timeline_id,)).fetchone()
        commits = self._timeline_commits()[0] if self._timeline_commit_provider is not None else None
        if commits is None or row["project_id"] != project_id or row["archived_at"] is not None or (name is not None and name != row["name"]):
            raise ConflictError("timeline already exists", details={"timeline_id": timeline_id})
        try:
            publication_event_id = commits.adopt_empty_shell(project_id, timeline_id, authorize=self._assert_mutation_admitted)
        except CommitRejected as exc:
            from .timeline_commit_execution import (
                _emit_redacted_diagnostic,
                _history_diagnostic_reason,
                _new_request_id,
            )
            reason = _history_diagnostic_reason(
                exc.failure, source_reason=getattr(exc, "_diagnostic_reason", None)
            )
            if reason is not None:
                _emit_redacted_diagnostic(_new_request_id(), reason=reason)
            raise ConflictError("timeline already exists", details={"timeline_id": timeline_id}) from exc
        except ConflictError as exc:
            if isinstance(exc.details, dict):
                from .timeline_commit_execution import (
                    _emit_redacted_diagnostic,
                    _history_diagnostic_reason,
                    _new_request_id,
                )
                reason = _history_diagnostic_reason({"details": exc.details})
                if reason is not None:
                    _emit_redacted_diagnostic(_new_request_id(), reason=reason)
            raise ConflictError("timeline already exists", details={"timeline_id": timeline_id}) from exc
        resource = self._timeline_resource(timeline_id)
        self._command_record("timeline.create", "timelines", idempotency_key, request_hash, resource,
                             project_id=project_id, event_ids=(publication_event_id,))
        if idempotency_key is not None:
            return self._command_replay("timeline.create", "timelines", idempotency_key, request_hash, project_id=project_id)
        return resource

    @staticmethod
    def _import_key(key, operation, identity=""):
        """A bounded, collision-resistant child key for one import command."""
        digest = hashlib.sha256(canonical_json([key, operation, identity]).encode()).hexdigest()
        return f"import-{digest}"

    def _load_prepared_import(self, project_id, body):
        inline = "prepared_object_id" not in body
        if inline:
            return {key: copy.deepcopy(value) for key, value in body.items() if key != "source"}
        if set(body) - {"prepared_object_id", "source"}:
            raise ValidationError("prepared_object_id cannot be combined with inline import fields")
        object_id = body.get("prepared_object_id")
        if not isinstance(object_id, str) or not re.fullmatch(r"sha256:[0-9a-f]{64}", object_id):
            raise ValidationError("prepared_object_id must be a SHA-256 object id")
        digest = object_id.removeprefix("sha256:")
        row = self.store.conn.execute(
            "SELECT o.size FROM objects o JOIN project_objects po ON po.digest=o.digest "
            "WHERE o.digest=? AND po.project_id=? AND po.relation='managed'",
            (digest, project_id),
        ).fetchone()
        if row is None:
            raise NotFoundError("prepared import object is not managed by the target project", details={"object_id": object_id})
        if int(row["size"]) > 64 * 1024 * 1024:
            raise ValidationError("prepared import metadata exceeds 64 MiB", details={"object_id": object_id, "size": int(row["size"])})
        data = self.cas.read(digest)
        if len(data) != int(row["size"]) or sha256_bytes(data) != digest:
            raise ConflictError("prepared import object failed integrity verification", details={"object_id": object_id})
        try:
            value = json.loads(data.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValidationError("prepared import object must contain UTF-8 JSON") from exc
        if not isinstance(value, dict):
            raise ValidationError("prepared import object must contain a JSON object")
        return value

    @staticmethod
    def _import_transcript_refs(value):
        """Read only the document IDs in transcriptReferences association records."""
        found = set()
        if isinstance(value, dict):
            if "transcriptReferences" in value:
                references = value["transcriptReferences"]
                if not isinstance(references, dict) or not isinstance(references.get("associations"), list):
                    raise ValidationError("transcriptReferences must contain an associations list")
                for item in references["associations"]:
                    if not isinstance(item, dict) or not isinstance(item.get("documentId"), str) or not item["documentId"]:
                        raise ValidationError("every transcript association requires a documentId")
                    found.add(item["documentId"])
            for child in value.values():
                found.update(RuntimeService._import_transcript_refs(child))
        elif isinstance(value, list):
            for child in value:
                found.update(RuntimeService._import_transcript_refs(child))
        return found

    @_durable_mutation
    def import_timeline(self, project_id, body, *, idempotency_key=None):
        """Create, populate and receipt one imported timeline in one SQL transaction."""
        idempotency_key = require_idempotency_key(idempotency_key)
        self._require_object_body(body)
        project = self.store.get_project(project_id)
        source = body.get("source")
        if source is not None and (
            not isinstance(source, dict)
            or set(source) - {"via", "detail"}
            or source.get("via") not in {"cli", "python", "app", "script", "sheet"}
            or ("detail" in source and not isinstance(source["detail"], str))
        ):
            raise ValidationError("source must be a supported timeline provenance object")
        prepared = self._load_prepared_import(project["id"], body)
        allowed = {"timeline_id", "name", "publication", "transcripts", "text_bindings", "differences"}
        if set(prepared) != allowed:
            raise ValidationError("import requires timeline_id, name, publication, transcripts, text_bindings, and differences")
        timeline_id, name = prepared["timeline_id"], prepared["name"]
        if not isinstance(timeline_id, str) or not timeline_id or len(timeline_id) > 256:
            raise ValidationError("timeline_id must be a non-empty identity")
        name = self._timeline_name(name)
        publication = prepared["publication"]
        if not isinstance(publication, dict) or publication.get("project_id") != project["id"] or publication.get("timeline_id") != timeline_id or publication.get("expected_head", object()) is not None:
            raise ValidationError("import publication must target this project and timeline with expected_head null")
        differences = prepared["differences"]
        if (not isinstance(differences, dict)
                or set(differences) != {"missing_effects", "different_effects"}
                or not isinstance(differences["missing_effects"], list)
                or not isinstance(differences["different_effects"], list)
                or any(not _valid_import_effect_difference(value, allow_unresolved_unpinned=True)
                       for value in differences["missing_effects"])
                or any(not _valid_import_effect_difference(value)
                       for value in differences["different_effects"])):
            raise ValidationError("differences must contain missing_effects and different_effects lists")
        transcripts, text_bindings = prepared["transcripts"], prepared["text_bindings"]
        if not isinstance(transcripts, list) or not isinstance(text_bindings, list):
            raise ValidationError("transcripts and text_bindings must be lists")
        request_identity = {"project_id": project["id"], "prepared": prepared}
        if source is not None:
            request_identity["source"] = source
        request_hash = hashlib.sha256(canonical_json(request_identity).encode()).hexdigest()
        replay = self._command_replay("timeline.import", project["id"], idempotency_key, request_hash, project_id=project["id"])
        if replay is not None:
            return replay
        prior_key = self.store.conn.execute("SELECT request_hash FROM command_idempotency WHERE command_kind='timeline.import' AND idempotency_key=? LIMIT 1", (idempotency_key,)).fetchone()
        if prior_key:
            raise ConflictError("idempotency key was already used with different input")
        internal_key_source = project["id"] + ":" + idempotency_key
        if self.store.conn.execute("SELECT 1 FROM timelines WHERE id=?", (timeline_id,)).fetchone():
            raise ConflictError("timeline already exists", details={"timeline_id": timeline_id})
        if publication.get("expected_head") is not None:
            raise ValidationError("import publication expected_head must be null")
        internal = publication.get("internal_timeline_revisions")
        shots = publication.get("shot_revisions")
        parent = publication.get("parent_composition")
        if not isinstance(internal, list) or not isinstance(shots, list) or not isinstance(parent, dict):
            raise ValidationError("publication requires internal_timeline_revisions, shot_revisions, and parent_composition")
        if any(not isinstance(item, dict) or not isinstance(item.get("timeline_id"), str)
               or item.get("timeline_id") != timeline_id for item in internal):
            raise ValidationError("all imported internal timeline revisions must belong to the new timeline")
        occurrences = parent.get("occurrences")
        if not isinstance(occurrences, list):
            raise ValidationError("parent composition occurrences must be a list")
        shot_by_id = {}
        shot_revision_ids = set()
        for item in shots:
            if (not isinstance(item, dict)
                    or not isinstance(item.get("shot_id"), str) or not item.get("shot_id")
                    or not isinstance(item.get("revision_id"), str) or not item.get("revision_id")
                    or not isinstance(item.get("internal_timeline_revision_id"), str)
                    or not item.get("internal_timeline_revision_id")
                    or not isinstance(item.get("content_digest"), str) or not item.get("content_digest")):
                raise ValidationError("every imported shot revision needs shot_id and revision_id")
            if item["shot_id"] in shot_by_id:
                raise ValidationError("import contains duplicate shot revisions for one fresh shot")
            if item["revision_id"] in shot_revision_ids:
                raise ValidationError("import contains duplicate shot revision identities")
            shot_revision_ids.add(item["revision_id"])
            shot_by_id[item["shot_id"]] = item
            if self.store.conn.execute("SELECT 1 FROM project_shots WHERE id=?", (item["shot_id"],)).fetchone():
                raise ConflictError("imported shot identity is already in use", details={"shot_id": item["shot_id"]})
            if self.store.conn.execute("SELECT 1 FROM shot_revisions WHERE id=?", (item["revision_id"],)).fetchone():
                raise ConflictError("imported shot revision identity is already in use", details={"revision_id": item["revision_id"]})
        if any(not isinstance(item, dict) for item in internal):
            raise ValidationError("every imported internal revision needs a unique revision_id")
        if any(not isinstance(item.get("revision_id"), str) or not item.get("revision_id") for item in internal):
            raise ValidationError("every imported internal revision needs a unique revision_id")
        if any(not isinstance(item.get("content_digest"), str) or not item.get("content_digest") for item in internal):
            raise ValidationError("every imported internal revision needs a non-empty content_digest")
        internal_by_id = {item["revision_id"]: item for item in internal}
        if len(internal_by_id) != len(internal):
            raise ValidationError("every imported internal revision needs a unique revision_id")
        referenced_shots = set()
        occurrence_ids = set()
        for occurrence in occurrences:
            if not isinstance(occurrence, dict):
                raise ValidationError("every imported occurrence must reference a copied shot revision")
            occurrence_shot_id = occurrence.get("shot_id")
            if not isinstance(occurrence_shot_id, str) or not occurrence_shot_id:
                raise ValidationError("import occurrence shot_id must be a non-empty identity")
            if occurrence_shot_id not in shot_by_id:
                raise ValidationError("every imported occurrence must reference a copied shot revision")
            occurrence_id = occurrence.get("occurrence_id")
            if not isinstance(occurrence_id, str) or not occurrence_id or occurrence_id in occurrence_ids:
                raise ValidationError("import contains a missing or duplicate occurrence identity")
            occurrence_ids.add(occurrence_id)
            shot_id = occurrence["shot_id"]
            shot = shot_by_id[shot_id]
            occurrence_revision_id = occurrence.get("shot_revision_id")
            if not isinstance(occurrence_revision_id, str) or not occurrence_revision_id:
                raise ValidationError("import occurrence shot_revision_id must be a non-empty identity")
            if occurrence_revision_id != shot["revision_id"]:
                raise ValidationError("import occurrence shot revision does not match its copied shot")
            if shot.get("internal_timeline_revision_id") not in internal_by_id:
                raise ValidationError("every imported shot must include its copied internal timeline revision")
            referenced_shots.add(shot_id)
        if referenced_shots != set(shot_by_id):
            raise ValidationError("import publication contains unreferenced copied shots")
        for item in internal:
            revision_id = item["revision_id"]
            if self.store.conn.execute("SELECT 1 FROM internal_timeline_revisions WHERE id=?", (revision_id,)).fetchone():
                raise ConflictError("imported internal revision identity is already in use", details={"revision_id": revision_id})
        for item in shots:
            if item.get("internal_timeline_revision_id") not in internal_by_id:
                raise ValidationError("imported shot references a missing copied internal revision")

        # Validate transcript identities and references before any write. The normal document validator
        # repeats schema, UTF-8, media ownership and bounds checks inside create_document.
        transcript_map = {}
        for item in transcripts:
            if not isinstance(item, dict) or set(item) != {"document_id", "kind", "content"} or item.get("kind") != TRANSCRIPT_DOCUMENT_KIND:
                raise ValidationError("imported transcript documents must have document_id, kind, and content")
            content = item["content"]
            if not isinstance(content, dict) or content.get("schema") != TRANSCRIPT_DOCUMENT_SCHEMA:
                raise ValidationError("imported transcript has an unsupported schema")
            wanted = self._transcript_document_id(project["id"], content.get("media_id"), content.get("source_id"))
            if item["document_id"] != wanted or wanted in transcript_map:
                raise ValidationError("imported transcript document identity is invalid or duplicated", details={"document_id": item["document_id"]})
            transcript_map[wanted] = item
        # A transcript reference may live in a parent config bundle, an envelope,
        # or a copied child payload. Resolve the whole immutable publication
        # closure so no source-project document ID can survive in a nested config.
        refs = self._import_transcript_refs({
            "parent": parent,
            "shots": [item.get("payload", {}) for item in shots],
            "internal_timelines": [item.get("payload", {}) for item in internal],
        })
        if not refs.issubset(transcript_map):
            raise ValidationError("transcript references must resolve to a carried transcript", details={"document_ids": sorted(refs - set(transcript_map))})

        # The publication manifest must be exactly the copied parent/shot/internal media closure.
        expected_media = set(self._collect_digest_media(parent))
        expected_media.update(self._collect_digest_media([item.get("payload", {}) for item in shots]))
        expected_media.update(self._collect_digest_media([item.get("payload", {}) for item in internal]))
        manifest = publication.get("dependency_manifest")
        if not isinstance(manifest, dict) or not isinstance(manifest.get("media"), list):
            raise ValidationError("publication dependency_manifest.media must be a list")
        checked_media = self._validate_media_dependencies(project["id"], {"media": manifest["media"]})
        if len(checked_media) != len(manifest["media"]):
            raise ValidationError("publication media manifest contains duplicate media identities")
        supplied_media = {item["media_id"] for item in checked_media}
        if len(supplied_media) != len(checked_media) or supplied_media != expected_media:
            raise ValidationError("publication media manifest does not match the copied payload closure", details={"missing": sorted(expected_media - supplied_media), "extra": sorted(supplied_media - expected_media)})
        expected_shot_manifest = {(item["shot_id"], item["revision_id"], item["internal_timeline_revision_id"], item.get("content_digest")) for item in shots}
        manifest_shots = manifest.get("shots")
        manifest_internal = manifest.get("internal_timelines")
        if not isinstance(manifest_shots, list) or not isinstance(manifest_internal, list):
            raise ValidationError("publication dependency manifest requires shots and internal_timelines lists")
        shot_manifest_fields = ("shot_id", "revision_id", "internal_timeline_revision_id", "content_digest")
        if any(not isinstance(item, dict) or any(not isinstance(item.get(field), str) or not item[field] for field in shot_manifest_fields)
               for item in manifest_shots):
            raise ValidationError("publication dependency manifest shot identities must be non-empty strings")
        supplied_shot_manifest = {tuple(item[field] for field in shot_manifest_fields) for item in manifest_shots}
        expected_internal_manifest = {(item["timeline_id"], item["revision_id"], item.get("content_digest")) for item in internal}
        internal_manifest_fields = ("timeline_id", "revision_id", "content_digest")
        if any(not isinstance(item, dict) or any(not isinstance(item.get(field), str) or not item[field] for field in internal_manifest_fields)
               for item in manifest_internal):
            raise ValidationError("publication dependency manifest internal timeline identities must be non-empty strings")
        supplied_internal_manifest = {tuple(item[field] for field in internal_manifest_fields) for item in manifest_internal}
        if (len(supplied_shot_manifest) != len(manifest_shots) or len(supplied_internal_manifest) != len(manifest_internal)
                or supplied_shot_manifest != expected_shot_manifest or supplied_internal_manifest != expected_internal_manifest):
            raise ValidationError("publication dependency manifest does not match the copied child revisions")

        declared_bindings = set()
        declared_natural = set()
        for item in text_bindings:
            if not isinstance(item, dict) or set(item) - {"shot_id", "kind", "slot", "media_id"} or not {"shot_id", "kind", "media_id"}.issubset(item):
                raise ValidationError("text bindings require shot_id, kind, and media_id")
            if not isinstance(item["shot_id"], str) or not item["shot_id"]:
                raise ValidationError("text binding shot_id must be a non-empty identity")
            if not isinstance(item["kind"], str) or not item["kind"]:
                raise ValidationError("text binding kind must be a non-empty identity")
            if item["shot_id"] not in shot_by_id or item["kind"] not in TEXT_BINDING_KINDS:
                raise ValidationError("text binding must target an imported shot and supported kind")
            if item.get("slot") is not None and (not isinstance(item["slot"], str) or not item["slot"]):
                raise ValidationError("text binding slot must be a non-empty string or null")
            if not isinstance(item["media_id"], str) or not re.fullmatch(r"sha256:[0-9a-f]{64}", item["media_id"]):
                raise ValidationError("text binding media_id must be a canonical SHA-256 object id")
            key = (item["shot_id"], item["kind"], item.get("slot"), item["media_id"])
            natural = key[:3]
            if natural in declared_natural:
                raise ValidationError("import contains duplicate text binding declarations", details={"shot_id": item["shot_id"], "kind": item["kind"], "slot": item.get("slot")})
            declared_bindings.add(key)
            declared_natural.add(natural)
            digest = item["media_id"].removeprefix("sha256:")
            self._verify_text_object(project["id"], digest, candidate=True)
        payload_bindings = set()
        payload_natural = set()
        for shot_id, item in shot_by_id.items():
            payload = item.get("payload")
            if not isinstance(payload, dict) or not isinstance(payload.get("text_bindings", []), list):
                raise ValidationError("copied shot text_bindings must be a list", details={"shot_id": shot_id})
            for descriptor in payload.get("text_bindings", []):
                if not isinstance(descriptor, dict):
                    raise ValidationError("copied text binding descriptor must be an object", details={"shot_id": shot_id})
                if (not isinstance(descriptor.get("kind"), str) or not descriptor.get("kind")
                        or descriptor.get("kind") not in TEXT_BINDING_KINDS
                        or (descriptor.get("slot") is not None and (not isinstance(descriptor.get("slot"), str) or not descriptor.get("slot")))
                        or not isinstance(descriptor.get("media_id"), str)
                        or not re.fullmatch(r"sha256:[0-9a-f]{64}", descriptor["media_id"])):
                    raise ValidationError("copied text binding descriptor has invalid identity or media", details={"shot_id": shot_id})
                key = (shot_id, descriptor.get("kind"), descriptor.get("slot"), descriptor.get("media_id"))
                natural = key[:3]
                if natural in payload_natural:
                    raise ValidationError("copied shot contains duplicate text binding descriptors", details={"shot_id": shot_id})
                payload_bindings.add(key)
                payload_natural.add(natural)
        if payload_bindings != declared_bindings:
            raise ValidationError("text binding declarations do not match the copied shot pins", details={"missing_declarations": [list(x) for x in sorted(payload_bindings - declared_bindings, key=str)], "extra_declarations": [list(x) for x in sorted(declared_bindings - payload_bindings, key=str)]})
        referenced_internal = {item.get("internal_timeline_revision_id") for item in shots}
        if referenced_internal != set(internal_by_id):
            raise ValidationError("publication internal timelines must exactly match the copied shot closure")

        # Validate every transcript even when it will be reused or reported as a conflict.
        for item in transcript_map.values():
            self._validate_project_document(project["id"], item["document_id"], item["kind"], item["content"])

        create = self.create_timeline(project["id"], timeline_id, name=name,
                                      idempotency_key=self._import_key(internal_key_source, "create", timeline_id),
                                      _bootstrap=False)
        if isinstance(create, dict) and create.get("error"):
            raise ConflictError("could not create imported timeline", details=create["error"])
        canonical_document = {
            "schema_version": 1,
            "project_id": project["id"],
            "timeline_id": timeline_id,
            "parent_revision": {
                "revision_id": publication["parent_revision_id"],
                "content_digest": publication["content_digest"],
                "payload": parent,
            },
            "shot_revisions": shots,
            "internal_timeline_revisions": internal,
            "dependency_manifest": {**manifest, "documents": []},
        }

        # Conflicting target transcript content is preserved and reported; identical content is reused.
        transcript_conflicts = []
        transcript_events = []
        for document_id, item in transcript_map.items():
            existing = self.store.conn.execute("SELECT kind, content_json FROM project_documents WHERE project_id=? AND id=?", (project["id"], document_id)).fetchone()
            if existing:
                if existing["kind"] == item["kind"] and json.loads(existing["content_json"]) == item["content"]:
                    continue
                content = item["content"]
                transcript_conflicts.append({"document_id": document_id, "media_id": content.get("media_id"), "source_id": content.get("source_id"), "message": "target project already has different transcript content"})
                continue
            created_doc = self.create_document(project["id"], item, idempotency_key=self._import_key(internal_key_source, "transcript", document_id))
            transcript_events.extend(created_doc.get("receipt", {}).get("event_ids", []) if isinstance(created_doc, dict) else [])

        media_bytes = sum(int(self.store.conn.execute(
            "SELECT size FROM objects WHERE digest=?", (item["media_id"].removeprefix("sha256:"),)
        ).fetchone()["size"]) for item in checked_media)
        receipt = {
            "timeline_id": timeline_id,
            "name": name,
            "new_head": publication["parent_revision_id"],
            "media": {"count": len(checked_media), "bytes": media_bytes},
            "missing_effects": prepared["differences"]["missing_effects"],
            "different_effects": prepared["differences"]["different_effects"],
            "transcript_conflicts": transcript_conflicts,
            **({"source": source} if source is not None else {}),
        }
        # The import receipt is a project mutation receipt, while the imported
        # film itself is published once by the v2.1 commit store below.
        result = self._command_record(
            "timeline.import", project["id"], idempotency_key, request_hash, receipt,
            project_id=project["id"],
        )
        commits, _ = self._timeline_commits()
        head = commits.bootstrap(
            project["id"], timeline_id, authorize=self._assert_mutation_admitted,
            document=canonical_document, source=source,
            idempotency_key=self._import_key(internal_key_source, "publish", timeline_id),
            request_hash=request_hash,
        )
        receipt["new_publication_id"] = head["publication_id"]
        receipt["accepted_revision_id"] = head["revision_id"]
        result["data"] = receipt
        result["receipt"]["result"] = receipt
        self.store.conn.execute(
            "UPDATE command_idempotency SET result_json=? WHERE command_kind='timeline.import' AND aggregate_id=? AND idempotency_key=?",
            (compact_result("timeline.import", receipt), project["id"], idempotency_key),
        )
        return result

    def create_timeline_document(self, project_id, body, *, idempotency_key=None):
        self._require_timeline_command()

    def list_timelines(self, project_id, *, cursor=None, limit=PAGE_DEFAULT_LIMIT):
        project = self.store.get_project(project_id)
        rows = self.store.conn.execute("SELECT id, created_at FROM timelines WHERE project_id=? ORDER BY created_at, id", (project["id"],)).fetchall()
        return _page_rows(rows, scope=f"timelines:{project['id']}", cursor=cursor, limit=limit,
                          key_fn=lambda row: (str(row["created_at"]), str(row["id"])),
                          resource_fn=lambda row: self._timeline_public_resource(row["id"]))

    def _shot_resource(self, row):
        state = self.store.conn.execute("SELECT version, archived_at FROM timeline_shot_state WHERE id=?", (row["id"],)).fetchone()
        timeline = self.store.conn.execute("SELECT project_id FROM timelines WHERE id=?", (row["timeline_id"],)).fetchone()
        return {"shot_id": row["id"], "timeline_id": row["timeline_id"], "project_id": timeline["project_id"], "start_ms": int(row["start_ms"]), "duration_ms": int(row["duration_ms"]), "reference_ids": json.loads(row["reference_ids_json"]), "version": int(state["version"] if state else 1), "archived": bool(state and state["archived_at"])}

    def _reference_resource(self, row):
        state = self.store.conn.execute("SELECT version, archived_at FROM timeline_reference_state WHERE id=?", (row["id"],)).fetchone()
        timeline = self.store.conn.execute("SELECT project_id FROM timelines WHERE id=?", (row["timeline_id"],)).fetchone()
        return {"reference_id": row["id"], "timeline_id": row["timeline_id"], "project_id": timeline["project_id"], "object_id": row["object_id"], **({"role": row["role"]} if row["role"] else {}), "version": int(state["version"] if state else 1), "archived": bool(state and state["archived_at"])}

    def _root_generation_cursor(self, scope, *, key=None, cursor=None):
        """Purpose/project/query-scoped cursor using the existing session signer."""
        if key is not None:
            encoded = _page_cursor(scope, key, numeric=True)
            signature = hmac.new(self._child_authority_key, encoded.encode(), hashlib.sha256).hexdigest()
            return encoded + "." + signature
        if cursor in (None, ""):
            return None
        if not isinstance(cursor, str) or cursor.count(".") != 1:
            raise InvalidRequestError("cursor is invalid")
        encoded, signature = cursor.split(".")
        expected = hmac.new(self._child_authority_key, encoded.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(signature, expected):
            raise InvalidRequestError("cursor is invalid or expired")
        _, decoded = _page_args(encoded, PAGE_DEFAULT_LIMIT)
        if decoded["s"] != scope:
            raise InvalidRequestError("cursor does not belong to this collection")
        key = decoded["k"]
        if (len(key) != 2 or type(key[0]) is not int or key[0] < 1
                or not isinstance(key[1], str) or not key[1]):
            raise InvalidRequestError("cursor is invalid")
        return tuple(key)

    def _root_generation_task_page(self, project_id, *, cursor, limit):
        limit, _ = _page_args(None, limit)
        scope = f"tasks:{project_id}:root_generation:admitted_desc"
        after = self._root_generation_cursor(scope, cursor=cursor)
        rows = self.store.conn.execute(
            "SELECT t.id, t.spec_digest, t.expected_effect_json, s.body_json, "
            "e.id AS admission_sequence, e.payload_json, "
            "(SELECT c.payload_json FROM events c WHERE c.task_id=t.id "
            "AND c.kind='task.parent_contained' ORDER BY c.id DESC LIMIT 1) AS containment_json FROM tasks t "
            "JOIN runs r ON r.id=t.run_id LEFT JOIN task_specs s ON s.digest=t.spec_digest "
            "LEFT JOIN events e ON e.id=(SELECT MIN(a.id) FROM events a "
            "WHERE a.task_id=t.id AND a.kind='task.admitted') "
            "WHERE r.project_id=? ORDER BY e.id DESC, t.id DESC", (project_id,),
        ).fetchall()

        def classification(row):
            try:
                contained = json.loads(row["containment_json"]) if row["containment_json"] else None
            except (TypeError, ValueError):
                contained = None
            if (isinstance(contained, dict) and isinstance(contained.get("parent_task_id"), str)
                    and contained["parent_task_id"] and contained["parent_task_id"] != row["id"]):
                # Runtime emits this on the child under its delegated parent
                # authority. It can prove non-root after legacy spec retirement;
                # its absence cannot prove root.
                return False
            try:
                payload = json.loads(row["payload_json"]) if row["payload_json"] else {}
            except (TypeError, ValueError):
                payload = {}
            facts = payload.get("classification") if isinstance(payload, dict) else None
            if isinstance(facts, dict) and type(facts.get("version")) is int and facts["version"] == 1:
                if facts.get("is_root") is False or facts.get("is_generation") is False:
                    return False
                if facts.get("is_root") is True and facts.get("is_generation") is True:
                    return True
            if row["body_json"] is None:
                return None
            try:
                retained = self.store._task_admission_facts(
                    json.loads(row["body_json"]),
                    json.loads(row["expected_effect_json"]) if row["expected_effect_json"] else None,
                    project_id,
                )
            except (TypeError, ValueError):
                return None
            if retained.get("is_root") is False or retained.get("is_generation") is False:
                return False
            if retained.get("is_root") is True and retained.get("is_generation") is True:
                return True
            return None

        def barrier(row, reason):
            raise ConflictError(
                "latest root generation cannot be proven from retained admission evidence",
                details={"reason": "root_generation_selection_barrier", "project_id": project_id,
                         "task_id": row["id"], "admission_sequence": row["admission_sequence"],
                         "missing": reason},
            )

        # An unanchored possible root cannot safely be placed before or after
        # any known root. Never substitute a mutable task timestamp.
        for row in rows:
            if row["admission_sequence"] is None and classification(row) is not False:
                barrier(row, "original_admission_sequence")
        selected = []
        has_more = False
        for row in rows:
            if row["admission_sequence"] is None:
                continue
            key = (int(row["admission_sequence"]), str(row["id"]))
            if after is not None and key >= after:
                continue
            known_root = classification(row)
            if known_root is None:
                if not selected:
                    barrier(row, "validated_root_generation_classification")
                # Return the proven newer prefix. The next page reaches this
                # barrier; it must never silently skip to older known roots.
                has_more = True
                break
            if known_root:
                if len(selected) == limit:
                    has_more = True
                    break
                selected.append((key, row["id"]))
        return {"items": [task_id for _, task_id in selected],
                "next_cursor": self._root_generation_cursor(scope, key=selected[-1][0]) if has_more else None}

    def list_project_tasks(self, project_id, *, cursor=None, limit=PAGE_DEFAULT_LIMIT, kind=None, order=None):
        if (kind, order) not in ((None, None), ("root_generation", "admitted_desc")):
            raise InvalidRequestError("task kind/order must be root_generation/admitted_desc together")
        self.store.reap_overdue_leases()
        project = self.store.get_project(project_id)
        if kind is not None:
            page = self._root_generation_task_page(project["id"], cursor=cursor, limit=limit)
        else:
            rows = self.store.conn.execute("SELECT id, created_at FROM tasks WHERE run_id IN (SELECT id FROM runs WHERE project_id=?) ORDER BY created_at, id", (project["id"],)).fetchall()
            page = _page_rows(rows, scope=f"tasks:{project['id']}", cursor=cursor, limit=limit,
                              key_fn=lambda row: (str(row["created_at"]), str(row["id"])),
                              resource_fn=lambda row: row["id"])
        tasks, progress = self.store._task_page(tuple(page["items"]))
        page["items"] = [self._task_resource(tasks[task_id], progress=progress.get(task_id), related_loaded=True)
                         for task_id in page["items"]]
        return page

    def list_project_runs(self, project_id, *, cursor=None, limit=PAGE_DEFAULT_LIMIT):
        self.store.reap_overdue_leases()
        project = self.store.get_project(project_id)
        rows = self.store.conn.execute("SELECT id, created_at FROM runs WHERE project_id=? ORDER BY created_at, id", (project["id"],)).fetchall()
        return _page_rows(rows, scope=f"runs:{project['id']}", cursor=cursor, limit=limit,
                          key_fn=lambda row: (str(row["created_at"]), str(row["id"])),
                          resource_fn=lambda row: self.run(row["id"]))

    def list_project_shots(self, project_id, *, cursor=None, include_archived=False, limit=PAGE_DEFAULT_LIMIT):
        project = self.store.get_project(project_id)
        query = "SELECT * FROM project_shots WHERE project_id=?"
        if not include_archived: query += " AND archived_at IS NULL"
        rows = self.store.conn.execute(query + " ORDER BY created_at, id", (project["id"],)).fetchall()
        return _page_rows(rows, scope=f"project-shots:{project['id']}:{int(include_archived)}", cursor=cursor, limit=limit,
                          key_fn=lambda row: (str(row["created_at"]), str(row["id"])),
                          resource_fn=self._project_shot_resource)

    def list_project_references(self, project_id, *, cursor=None, include_archived=False, limit=PAGE_DEFAULT_LIMIT):
        project = self.store.get_project(project_id)
        query = "SELECT * FROM project_references WHERE project_id=?"
        if not include_archived: query += " AND archived_at IS NULL"
        rows = self.store.conn.execute(query + " ORDER BY created_at, id", (project["id"],)).fetchall()
        return _page_rows(rows, scope=f"project-references:{project['id']}:{int(include_archived)}", cursor=cursor, limit=limit,
                          key_fn=lambda row: (str(row["created_at"]), str(row["id"])),
                          resource_fn=self._project_reference_resource)

    @staticmethod
    def _require_object_body(body):
        if not isinstance(body, dict):
            raise InvalidRequestError("request body must be a JSON object")

    def _receipt_payload(self, row, *, project_id):
        """Expose the canonical receipt facts committed with the mutation."""
        if row is None or row["txn_id"] is None:
            return None
        active = self._active_task_admission_result(row)
        if active is not None:
            result = active
        else:
            result = self._publication_replay_result(row) if row["command_kind"] == "parent_composition.publish" else command_result(
                row["result_json"], kind=row["command_kind"], connection=self.store.conn,
                created_at=None if row["command_kind"] in {"object.ingest", "media.import", "timeline.commit"} else row["created_at"],
            )
        return {
            "receipt_id": row["txn_id"],
            "command_kind": row["command_kind"],
            "idempotency_key": row["idempotency_key"],
            "request_hash": row["request_hash"],
            "project_id": project_id,
            "project_seq": [int(row["first_project_seq"]), int(row["last_project_seq"])],
            "event_ids": json.loads(row["event_ids_json"]),
            "result": result,
            "created_at": row["created_at"],
        }

    def _active_task_admission_result(self, row):
        if row["command_kind"] != "task.create" or "primary_stream_id" not in row.keys() or not row["primary_stream_id"]:
            return None
        with self.store._mutex:
            run = self.store.conn.execute("SELECT * FROM runs WHERE id=?", (row["primary_stream_id"],)).fetchone()
            task = self.store.conn.execute("SELECT * FROM tasks WHERE run_id=?", (row["primary_stream_id"],)).fetchone()
            if run is None or task is None or task["status"] not in {"queued", "running", "cancel_requested"}:
                return None
            return self.store._task_result(run, task)

    def _publication_replay_result(self, row):
        """Rebuild the exact old response from immutable revision/event evidence."""
        stored = json.loads(row["result_json"])
        if IDEMPOTENCY_RESULT_MARKER not in stored:
            return stored
        project_id = stored["project_id"]
        timeline_id = stored["timeline_id"]
        revision_id = stored["parent_revision_id"]
        parent_row = self.store.conn.execute(
            "SELECT * FROM parent_composition_revisions WHERE id=? AND project_id=? AND timeline_id=?",
            (revision_id, project_id, timeline_id),
        ).fetchone()
        if parent_row is None:
            raise NotFoundError("compacted publication revision is missing")
        parent, shots, internal = load_closure(self.store.conn, project_id, timeline_id, parent_row)
        event_row = self.store.conn.execute(
            "SELECT * FROM timeline_events WHERE id=? AND timeline_id=? AND kind='parent.composition.published'",
            (stored["event_id"], timeline_id),
        ).fetchone()
        if event_row is None:
            raise ConflictError("compacted publication event is missing")
        event = json.loads(event_row["payload_json"])
        manifest = event["dependency_manifest"]
        if (event["project_id"] != project_id or event["new_head"] != revision_id
                or event["content_digest"] != parent_row["content_digest"]
                or hashlib.sha256(canonical_json(manifest).encode()).hexdigest() != stored["dependency_manifest_sha256"]):
            raise ConflictError("compacted publication evidence disagrees with revision")
        seam_report, _ = evaluate_closure(parent, shots, internal, timeline_id=timeline_id)
        digest = parent_row["content_digest"]
        result = {
            "project_id": project_id, "timeline_id": timeline_id,
            "revision_id": revision_id, "parent_revision_id": revision_id,
            "content_digest": digest, "payload": parent,
            "old_head": event["old_head"], "new_head": revision_id,
            "dependency_manifest": manifest,
            "content_digests": {"parent": digest,
                **{item["revision_id"]: item["content_digest"] for item in manifest["shots"] + manifest["internal_timelines"]},
                **{item["media_id"]: item["content_digest"] for item in manifest["media"]}},
            "event_id": stored["event_id"], "created_at": stored["created_at"],
            "visual_seam_report": seam_report,
        }
        if "source" in event:
            result["source"] = event["source"]
        if hashlib.sha256(canonical_json(result).encode()).hexdigest() != stored[IDEMPOTENCY_RESULT_MARKER]:
            raise ConflictError("compacted publication replay does not match original response")
        return result

    def committed_receipt(self, command_kind, aggregate_id, idempotency_key, *, project_id):
        """Return the receipt persisted with a successful mutation.

        This reads the command ledger; it never derives a receipt from client
        state or caches one in the service process.
        """
        if not idempotency_key:
            return None
        # HTTP handlers share the owner's SQLite connection. Serialize this
        # post-mutation read with the writer lock so another handler cannot
        # interleave a transaction on the same connection between the
        # mutation and receipt lookup, yielding a spurious null receipt.
        with self.store._mutex:
            row = self.store.conn.execute(
                "SELECT txn_id, command_kind, idempotency_key, request_hash, result_json, "
                "first_project_seq, last_project_seq, event_ids_json, created_at, primary_stream_id "
                "FROM command_idempotency WHERE command_kind=? AND aggregate_id=? AND idempotency_key=?",
                (command_kind, aggregate_id, idempotency_key),
            ).fetchone()
        return self._receipt_payload(row, project_id=project_id) if row else None

    def _command_replay_state(self, kind, aggregate_id, idempotency_key, request_hash, *, project_id=None, with_receipt=True):
        """Return ``(found, value)`` so a committed null result is replayable."""
        if idempotency_key is None:
            return False, None
        validate_idempotency_key(idempotency_key)
        if kind in {"task.claim", "task.claim_delegated_child", "executor.register"}:
            query = (
                "SELECT NULL AS txn_id, command_kind, idempotency_key, request_hash, result_json, "
                "NULL AS first_project_seq, NULL AS last_project_seq, NULL AS event_ids_json, created_at "
                "FROM session_command_replay WHERE command_kind=? AND aggregate_id=? AND idempotency_key=?"
            )
        else:
            query = (
                "SELECT txn_id, command_kind, idempotency_key, request_hash, result_json, "
                "first_project_seq, last_project_seq, event_ids_json, created_at "
                "FROM command_idempotency WHERE command_kind=? AND aggregate_id=? AND idempotency_key=?"
            )
        prior = self.store.conn.execute(query, (kind, aggregate_id, idempotency_key)).fetchone()
        if not prior:
            return False, None
        if prior["request_hash"] != request_hash:
            raise ConflictError("idempotency key was already used with different input")
        result = self._publication_replay_result(prior) if kind == "parent_composition.publish" else command_result(
            prior["result_json"], kind=kind, connection=self.store.conn,
            created_at=None if kind in {"object.ingest", "media.import", "timeline.commit"} else prior["created_at"],
            window_seconds=SESSION_IDEMPOTENCY_WINDOW_SECONDS if kind in {"task.claim", "task.claim_delegated_child", "executor.register"} else IDEMPOTENCY_RESULT_WINDOW_SECONDS,
        )
        if project_id is not None and with_receipt:
            result = {"data": result, "receipt": self._receipt_payload(prior, project_id=project_id)}
        return True, result

    def _command_replay(self, kind, aggregate_id, idempotency_key, request_hash, *, project_id=None, with_receipt=True):
        found, result = self._command_replay_state(
            kind, aggregate_id, idempotency_key, request_hash,
            project_id=project_id, with_receipt=with_receipt,
        )
        return result if found else None

    def _command_record(self, kind, aggregate_id, idempotency_key, request_hash, result, *, project_id=None, event_ids=(), primary_stream_id=None, resulting_stream_seq=None, with_receipt=True, created_at=None):
        if idempotency_key is not None:
            validate_idempotency_key(idempotency_key)
            if kind in {"task.claim", "task.claim_delegated_child", "executor.register"}:
                self.store.conn.execute(
                    "INSERT INTO session_command_replay(command_kind,aggregate_id,idempotency_key,request_hash,result_json,created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (kind, aggregate_id, idempotency_key, request_hash, canonical_json(result), now()),
                )
                cutoff = (datetime.now(timezone.utc) - timedelta(seconds=SESSION_IDEMPOTENCY_WINDOW_SECONDS)).isoformat(timespec="milliseconds")
                rows = self.store.conn.execute(
                    "SELECT command_kind, aggregate_id, idempotency_key, result_json "
                    "FROM session_command_replay WHERE is_expired=0 AND created_at < ? LIMIT 100",
                    (cutoff,),
                ).fetchall()
                for old in rows:
                    self.store.conn.execute(
                        "UPDATE session_command_replay SET result_json=?, is_expired=1 "
                        "WHERE command_kind=? AND aggregate_id=? AND idempotency_key=?",
                        (expired_command_result(old["result_json"]), old["command_kind"], old["aggregate_id"], old["idempotency_key"]),
                    )
                return result
            if project_id is not None:
                self.store._record_command_receipt(
                    kind, aggregate_id, idempotency_key, request_hash, result,
                    project_id=project_id, event_ids=event_ids,
                    primary_stream_id=primary_stream_id,
                    resulting_stream_seq=resulting_stream_seq,
                    created_at=created_at,
                )
                row = self.store.conn.execute(
                    "SELECT txn_id, command_kind, idempotency_key, request_hash, result_json, "
                    "first_project_seq, last_project_seq, event_ids_json, created_at "
                    "FROM command_idempotency WHERE command_kind=? AND aggregate_id=? AND idempotency_key=?",
                    (kind, aggregate_id, idempotency_key),
                ).fetchone()
                if with_receipt:
                    return {"data": result, "receipt": self._receipt_payload(row, project_id=project_id)}
                return result
            self.store.conn.execute(
                "INSERT INTO command_idempotency(command_kind, aggregate_id, idempotency_key, request_hash, result_json, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                (kind, aggregate_id, idempotency_key, request_hash, compact_result(kind, result), now()),
            )
        return result

    def _open_publication_directory(self, *, create):
        """Open the publication journal directory below pinned staging fds."""
        staging_fd = _open_directory_chain(self.store.staging_root)
        try:
            if create:
                publication_fd = _mkdir_chain_at(staging_fd, "publications")
            else:
                publication_fd = os.open(
                    "publications",
                    os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0),
                    dir_fd=staging_fd,
                )
            try:
                if not stat.S_ISDIR(os.fstat(publication_fd).st_mode):
                    raise ConflictError("publication journal directory is invalid")
            except Exception:
                os.close(publication_fd)
                raise
            return staging_fd, publication_fd
        except Exception:
            os.close(staging_fd)
            raise


    def _begin_cas_publication_journal(self, kind, entries, *, project_id=None, task_id=None):
        """Durably describe CAS destinations before making them reachable.

        The journal is intentionally outside SQLite: a process crash can occur
        after ``rename`` and before the SQLite commit.  Startup then keeps a
        destination only when the durable metadata proves that this operation
        committed; otherwise it removes the exact content-addressed path.
        """
        if not entries:
            return None
        payload = {
            "version": 1,
            "kind": kind,
            "project_id": project_id,
            "task_id": task_id,
            "entries": [{"digest": str(entry["digest"])} for entry in entries],
        }
        journal_name = f"{new_id()}.json"
        staging_fd = publication_fd = -1
        try:
            staging_fd, publication_fd = self._open_publication_directory(create=True)
            _write_bytes_at(publication_fd, journal_name, durable_json_bytes(payload))
            os.fsync(staging_fd)
        finally:
            if publication_fd >= 0:
                os.close(publication_fd)
            if staging_fd >= 0:
                os.close(staging_fd)
        return self.store.staging_root / "publications" / journal_name

    @staticmethod
    def _remove_publication_journal_at(directory_fd, name):
        try:
            os.unlink(name, dir_fd=directory_fd)
        except FileNotFoundError:
            return True
        except OSError:
            return False
        try:
            os.fsync(directory_fd)
        except OSError:
            return False
        return True


    def _publication_committed(self, journal):
        entries = journal.get("entries")
        if not isinstance(entries, list) or not entries:
            return False
        digests = []
        for entry in entries:
            if not isinstance(entry, dict) or not isinstance(entry.get("digest"), str):
                return False
            digest = entry["digest"]
            if len(digest) != 64 or any(char not in "0123456789abcdef" for char in digest):
                return False
            digests.append(digest)
            if not self.store.conn.execute("SELECT 1 FROM objects WHERE digest=?", (digest,)).fetchone():
                return False
        project_id = journal.get("project_id")
        if project_id and project_id != "unscoped":
            for digest in digests:
                if not self.store.conn.execute("SELECT 1 FROM project_objects WHERE project_id=? AND digest=?", (project_id, digest)).fetchone():
                    return False
        if journal.get("kind") == "settlement":
            task_id = journal.get("task_id")
            task = self.store.conn.execute("SELECT status, result_json FROM tasks WHERE id=?", (task_id,)).fetchone()
            if not task or task["status"] != "completed":
                return False
            try:
                result_digests = {
                    str(item.get("digest", "")).removeprefix("sha256:")
                    for item in (json.loads(task["result_json"] or "{}").get("outputs") or [])
                    if isinstance(item, dict)
                }
            except (TypeError, ValueError, json.JSONDecodeError):
                return False
            if not set(digests).issubset(result_digests):
                return False
        return True

    def _recover_cas_publication_journals(self):
        """Finish or roll back CAS publications left by a crashed mutation."""
        staging_fd = publication_fd = -1
        try:
            try:
                staging_fd, publication_fd = self._open_publication_directory(create=False)
            except FileNotFoundError:
                return
            try:
                names = sorted(
                    entry.name
                    for entry in os.scandir(publication_fd)
                    if entry.name.endswith(".json")
                    and not entry.is_symlink()
                    and stat.S_ISREG(entry.stat(follow_symlinks=False).st_mode)
                )
            except OSError:
                return
            for name in names:
                journal_fd = -1
                try:
                    journal_fd = os.open(
                        name,
                        os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0),
                        dir_fd=publication_fd,
                    )
                    chunks = []
                    while True:
                        chunk = os.read(journal_fd, 1024 * 1024)
                        if not chunk:
                            break
                        chunks.append(chunk)
                    journal = json.loads(b"".join(chunks).decode("utf-8"))
                except (OSError, UnicodeDecodeError, json.JSONDecodeError):
                    # Leave malformed evidence for doctor/operator inspection;
                    # do not guess at a path and risk deleting unrelated data.
                    continue
                finally:
                    if journal_fd >= 0:
                        os.close(journal_fd)
                if not isinstance(journal, dict) or journal.get("version") != 1:
                    continue
                try:
                    committed = self._publication_committed(journal)
                except (OSError, sqlite3.DatabaseError, TypeError, ValueError):
                    continue
                if not committed:
                    cleanup_failed = False
                    for entry in journal.get("entries", []):
                        digest = entry.get("digest") if isinstance(entry, dict) else None
                        if not isinstance(digest, str) or len(digest) != 64 or any(char not in "0123456789abcdef" for char in digest):
                            continue
                        # If another operation has since durable-metadata-claimed
                        # this object, it owns the file and it must be retained.
                        if self.store.conn.execute("SELECT 1 FROM objects WHERE digest=?", (digest,)).fetchone():
                            continue
                        try:
                            self._unlink_cas_destination(digest)
                        except (OSError, ConflictError):
                            # Keep durable evidence when the CAS prefix cannot
                            # be opened or its pinned entry cannot be removed.
                            cleanup_failed = True
                            continue
                    if cleanup_failed:
                        continue
                if not self._remove_publication_journal_at(publication_fd, name):
                    continue
        finally:
            if publication_fd >= 0:
                os.close(publication_fd)
            if staging_fd >= 0:
                os.close(staging_fd)

    @staticmethod
    def _revision_digest(payload):
        """Digest the exact canonical JSON bytes persisted for a revision."""
        return "sha256:" + hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()

    @staticmethod
    def _revision_id(value, field):
        if not isinstance(value, str) or not value or len(value) > 256:
            raise ValidationError(f"{field} must be a non-empty revision identity")
        return value

    @staticmethod
    def _revision_payload(entry, *, excluded):
        if not isinstance(entry, dict):
            raise ValidationError("revision entries must be objects")
        payload = entry.get("payload", entry.get("content"))
        if payload is None:
            payload = {key: value for key, value in entry.items() if key not in excluded}
        if not isinstance(payload, dict):
            raise ValidationError("revision payload must be an object")
        return copy.deepcopy(payload)

    @staticmethod
    def _complete_internal_timeline_payload(payload):
        if not isinstance(payload, dict):
            raise ValidationError("internal timeline payload must be an object")
        def contains_nested_composition(value):
            if isinstance(value, dict):
                if set(value) & {"occurrences", "occurrence_records", "shot_revision_id", "parent_revision_id", "composition_revision_id", "nested_composition"}:
                    return True
                return any(contains_nested_composition(item) for item in value.values())
            if isinstance(value, list):
                return any(contains_nested_composition(item) for item in value)
            return False
        if contains_nested_composition(payload):
            raise ValidationError("internal timeline cannot contain a nested composition")
        result = copy.deepcopy(payload)
        aliases = {"local_tracks": "tracks", "local_clips": "clips", "local_effects": "effects", "local_audio": "audio", "local_layout": "layout", "scoped_registry": "registry", "scoped_assets": "assets"}
        for source, target in aliases.items():
            if source in result and target not in result:
                result[target] = result.pop(source)
        defaults = {"tracks": [], "clips": [], "effects": [], "audio": [], "layout": {}, "registry": {}, "assets": []}
        for key, default in defaults.items():
            result.setdefault(key, default)
        RuntimeService._validate_timeline_track_roles(result)
        effects = result["effects"]
        if not isinstance(effects, list):
            raise ValidationError("internal timeline effects must be a list")
        for effect in effects:
            if not isinstance(effect, dict) or effect.get("type") not in SUPPORTED_COMPOSITION_EFFECTS:
                raise ValidationError("unsupported composition effect", details={"effect": effect})
        return result

    @staticmethod
    def _validate_timeline_track_roles(config):
        tracks = config.get("tracks", []) if isinstance(config, dict) else []
        if not isinstance(tracks, list):
            return
        for track in tracks:
            if not isinstance(track, dict) or "role" not in track:
                continue
            if track["role"] not in ("output", "source"):
                raise ValidationError(
                    "timeline track role must be 'output' or 'source'",
                    details={"track_id": track.get("id"), "role": track["role"]},
                )

    @staticmethod
    def _complete_shot_payload(payload, internal_revision_id):
        if not isinstance(payload, dict):
            raise ValidationError("shot revision payload must be an object")
        if any(key in payload for key in ("occurrences", "occurrence_records", "parent_composition", "parent_revision_id", "composition_revision_id")):
            raise ValidationError("shot revision cannot contain a nested composition")
        result = copy.deepcopy(payload)
        aliases = {"item_membership": "items", "item_pool": "pools", "variants": "selected_variants", "generation": "generation_inputs", "audio": "audio_bindings", "text": "text_bindings"}
        for source, target in aliases.items():
            if source in result and target not in result:
                result[target] = result.pop(source)
        defaults = {"metadata": {}, "items": [], "pools": [], "selected_variants": {}, "provenance": {}, "generation_inputs": {}, "audio_bindings": [], "text_bindings": []}
        for key, default in defaults.items():
            result.setdefault(key, default)
        result["internal_timeline_revision_id"] = internal_revision_id
        return result

    @staticmethod
    def _complete_parent_payload(payload):
        if not isinstance(payload, dict):
            raise ValidationError("parent composition payload must be an object")
        result = copy.deepcopy(payload)
        aliases = {"authored_config": "config", "authored_registry": "registry", "ordinary_clips": "clips", "occurrence_records": "occurrences"}
        for source, target in aliases.items():
            if source in result and target not in result:
                result[target] = result.pop(source)
        defaults = {"config": {}, "registry": {}, "clips": [], "occurrences": []}
        for key, default in defaults.items():
            result.setdefault(key, default)
        if not isinstance(result["config"], dict) or not isinstance(result["registry"], dict):
            raise ValidationError("parent composition config and registry must be objects")
        RuntimeService._validate_timeline_track_roles(result["config"])
        if not isinstance(result["clips"], list) or not isinstance(result["occurrences"], list):
            raise ValidationError("parent composition clips and occurrences must be lists")
        for clip in result["clips"]:
            if not isinstance(clip, dict):
                raise ValidationError("ordinary clips must be objects")
            if any(key in clip for key in ("occurrence_id", "shot_revision_id", "parent_revision_id", "composition_revision_id")):
                raise ValidationError("ordinary clips cannot contain nested shot compositions")
            effects = clip.get("effects", [])
            if not isinstance(effects, list):
                raise ValidationError("clip effects must be a list")
            for effect in effects:
                if not isinstance(effect, dict) or effect.get("type") not in SUPPORTED_COMPOSITION_EFFECTS:
                    raise ValidationError("unsupported composition effect", details={"effect": effect})
        return result

    def get_project_shot_revision(self, project_id, shot_id, revision):
        project = self.store.get_project(project_id)
        row = self.store.conn.execute("SELECT * FROM shot_revisions WHERE id=? AND project_id=? AND shot_id=?", (revision, project["id"], shot_id)).fetchone()
        if not row:
            raise NotFoundError("shot revision not found", details={"shot_id": shot_id, "revision": revision})
        return {"revision_id": row["id"], "project_id": row["project_id"], "shot_id": row["shot_id"], "internal_timeline_revision_id": row["internal_timeline_revision_id"], "content_digest": row["content_digest"], "payload": json.loads(row["payload_json"]), "created_at": row["created_at"]}

    def get_project_timeline_revision(self, project_id, timeline_id, revision):
        project = self.store.get_project(project_id)
        row = self.store.conn.execute("SELECT * FROM internal_timeline_revisions WHERE id=? AND project_id=? AND timeline_id=?", (revision, project["id"], timeline_id)).fetchone()
        if not row:
            raise NotFoundError("internal timeline revision not found", details={"timeline_id": timeline_id, "revision": revision})
        return {"revision_id": row["id"], "project_id": row["project_id"], "timeline_id": row["timeline_id"], "content_digest": row["content_digest"], "payload": json.loads(row["payload_json"]), "created_at": row["created_at"]}

    def get_project_timeline(self, project_id, timeline_id):
        """Read one timeline only through its project-scoped identity."""
        project = self.store.get_project(project_id)
        row = self.store.conn.execute(
            "SELECT project_id FROM timelines WHERE id=? AND project_id=?",
            (timeline_id, project["id"]),
        ).fetchone()
        if row is None:
            raise NotFoundError("timeline not found")
        # Same projection as create/rename/list: retired timeline-document bytes (config/registry) stay unserved.
        return self._timeline_public_resource(timeline_id)

    def get_project_parent_composition_revision(self, project_id, timeline_id, revision):
        project = self.store.get_project(project_id)
        row = self.store.conn.execute("SELECT * FROM parent_composition_revisions WHERE id=? AND project_id=? AND timeline_id=?", (revision, project["id"], timeline_id)).fetchone()
        if not row:
            raise NotFoundError("parent composition revision not found", details={"timeline_id": timeline_id, "revision": revision})
        result = {"revision_id": row["id"], "project_id": row["project_id"], "timeline_id": row["timeline_id"], "content_digest": row["content_digest"], "payload": json.loads(row["payload_json"]), "created_at": row["created_at"]}
        # A non-null manifest is the acceptance layer's proof that this
        # immutable revision has a verified closure.  Legacy rows either do
        # not have the column or leave it NULL, so keep their historical read
        # shape instead of guessing pins from mutable payloads.
        if "commit_manifest_json" in row.keys() and row["commit_manifest_json"] is not None:
            result["dependency_manifest"] = json.loads(row["commit_manifest_json"])
        return result

    def list_project_parent_composition_revisions(self, project_id, timeline_id, *, cursor=None, limit=PAGE_DEFAULT_LIMIT):
        """List immutable canonical history for one project timeline."""
        project = self.store.get_project(project_id)
        timeline = self.store.conn.execute(
            "SELECT 1 FROM timelines WHERE id=? AND project_id=?", (timeline_id, project["id"])
        ).fetchone()
        if timeline is None:
            raise NotFoundError("timeline not found", details={"timeline_id": timeline_id, "project_id": project["id"]})
        head = self.store.conn.execute(
            "SELECT revision_id FROM parent_composition_heads WHERE timeline_id=? AND project_id=?",
            (timeline_id, project["id"]),
        ).fetchone()
        current_head = head["revision_id"] if head else None
        rows = self.store.conn.execute(
            "SELECT * FROM parent_composition_revisions WHERE project_id=? AND timeline_id=? ORDER BY created_at DESC, id DESC",
            (project["id"], timeline_id),
        ).fetchall()
        return _page_rows(
            rows,
            scope=f"parent-composition-history:{project['id']}:{timeline_id}",
            cursor=cursor,
            limit=limit,
            key_fn=lambda row: (row["created_at"], row["id"]),
            resource_fn=lambda row: {
                "revision_id": row["id"],
                "project_id": row["project_id"],
                "timeline_id": row["timeline_id"],
                "content_digest": row["content_digest"],
                "created_at": row["created_at"],
                "is_current_head": row["id"] == current_head,
            },
            skip_after=lambda key, after: key >= after,
        )

    def register_timeline_commit_provider(self, provider):
        from .timeline_commit_port import validate_provider
        validate_provider(provider)
        from .timeline_commit import CommitRejected
        with self.store._mutex:
            if self._timeline_commit_started or self._timeline_commit_provider is not None:
                raise ValidationError("timeline provider registration is startup-only")
            commits, _ = self._timeline_commits()
            # Install verified legacy facts before serving requests. Preview
            # and rejected edits must never persist baseline/history rows.
            heads = self.store.conn.execute(
                "SELECT project_id, timeline_id, publication_id FROM parent_composition_heads "
                "WHERE revision_id IS NOT NULL",
            ).fetchall()
            inventory = []
            self._registering_v33_provider = True
            try:
                for head in heads:
                    try:
                        if head["publication_id"] is None:
                            commits.install_verified_baseline(head["project_id"], head["timeline_id"],
                                                              authorize=self._assert_mutation_admitted,
                                                              verify_inputs=self._verify_legacy_media_selections)
                        else:
                            verified_head = commits.head(head["project_id"], head["timeline_id"])
                            self._verify_legacy_media_selections(commits.revision_closure(head["project_id"], head["timeline_id"], verified_head["revision_id"]))
                        inventory.append({**dict(head), "access": "verified"})
                    except (CommitRejected, ConflictError, ValidationError) as exc:
                        inventory.append({**dict(head), "access": "read_only", "reason": str(exc), "details": getattr(exc, "details", None)})
                from .v33_lifecycle import provider_ready
                provider_ready(self.store.root, inventory)
                self._timeline_commit_provider = provider
                self._v33_provider_registered = True
            finally:
                self._registering_v33_provider = False

    def _verify_legacy_media_selections(self, document):
        """Recheck explicit retained five-field pins without rewriting them."""
        from .timeline_commit_port import MediaReads
        def verify(value):
            if isinstance(value, dict):
                if set(value) == {"asset", "generation_id", "variant_id", "object_id", "catalog_digest"}:
                    try:
                        MediaReads(self).selected(document["project_id"], value)
                    except (ConflictError, ValidationError, NotFoundError) as exc:
                        raise ConflictError("Timeline is read-only because a retained media selection changed. Inspect/export the original or restore the matching backup.",
                            details={"reason": "history_unavailable", "integrity_reason": "retained_media_selection_changed", "input": value}) from exc
                for child in value.values():
                    verify(child)
            elif isinstance(value, list):
                for child in value:
                    verify(child)
        verify(document)

    def timeline_recovery_inventory(self, project_id, timeline_id, *, authorize):
        """Authenticated per-timeline D4 reason and original inspect/export facts."""
        from .timeline_recovery import inventory
        from .timeline_commit import CommitRejected
        from .v33_lifecycle import activation
        check = self._timeline_authorize(project_id, timeline_id, authorize, mutation=False)
        with self.store._mutex:
            check()
            commits, _ = self._timeline_commits()
            try:
                head = commits.head(project_id, timeline_id)
                self._verify_legacy_media_selections(commits.revision_closure(project_id, timeline_id, head["revision_id"]))
                reason = {"code": "provider_unavailable", "message": "Register the selected Timeline provider before editing."} if self._timeline_commit_provider is None else None
            except (CommitRejected, ConflictError) as exc:
                head = None
                reason = {"code": "history_unavailable", "message": str(exc), "details": getattr(exc, "details", None)}
            state = activation(self.store.root)
            if reason and state:
                retained = next((item for item in state[1].get("baseline_inventory", [])
                                 if item.get("project_id") == project_id and item.get("timeline_id") == timeline_id
                                 and item.get("access") == "read_only"), None)
                if retained:
                    reason = {"code": "history_unavailable", "message": retained["reason"], "details": retained.get("details")}
            recovery = inventory(self.store.conn, self.store.root, project_id, timeline_id,
                                 reason=reason, backup={"id": state[1]["backup_id"], "location": str(state[0])} if state else None)
            recovery.update(access="read_only" if reason else "verified", last_verified_head=head)
            return recovery

    def _timeline_commits(self):
        from .timeline_commit_validation import validate_commit_value
        from .timeline_commit_execution import CommitExecutionCoordinator
        from .timeline_commit_store import TimelineCommitStore
        with self.store._mutex:
            if self._timeline_commit_store is None:
                self._timeline_commit_store = TimelineCommitStore(
                    self.store, validate_prepared=lambda value: validate_commit_value(value, "PreparedCommit"),
                )
                self._timeline_commit_coordinator = CommitExecutionCoordinator(self._timeline_commit_store)
            return self._timeline_commit_store, self._timeline_commit_coordinator

    def _timeline_authorize(self, project_id, timeline_id, authorize, *, mutation=True,
                            allow_archived=False):
        if not callable(authorize):
            raise AuthorizationError("authenticated timeline authority callback is required")
        def check():
            authorize()
            if mutation:
                self._assert_mutation_admitted()
            project = self.store.get_project(project_id)
            if project["id"] != project_id or project["realm_id"] != self.realm["id"]:
                raise AuthorizationError("canonical project identity is required")
            if timeline_id is not None:
                query = "SELECT 1 FROM timelines WHERE id=? AND project_id=?"
                if not allow_archived:
                    query += " AND archived_at IS NULL"
                row = self.store.conn.execute(query, (timeline_id, project_id)).fetchone()
                if row is None:
                    raise NotFoundError("timeline not found")
        with self.store._mutex:
            check()
        return check

    @_clear_replay_on_refusal
    @timed_timeline_commit
    def commit_timeline(self, project_id, timeline_id, body, *, idempotency_key,
                        publisher, invocation_path, authorize, public_request_id=None):
        from .timeline_commit_port import detached, route_path, validate_request
        body = detached(body)
        validate_request(body)
        if (body["project_id"], body["timeline_id"]) != (project_id, timeline_id):
            raise ValidationError("commit path and body identities must agree")
        if invocation_path != route_path(project_id, timeline_id):
            raise ValidationError("commit invocation must use its canonical Runtime path")
        return self._execute_timeline_commit(
            project_id, timeline_id, body, body, operation="commitTimeline",
            idempotency_key=idempotency_key, publisher=publisher,
            invocation_path=invocation_path, authorize=authorize,
            public_request_id=public_request_id,
        )

    @_clear_replay_on_refusal
    def _execute_timeline_commit(self, project_id, timeline_id, request, original_body, *,
                                 operation, idempotency_key, publisher, invocation_path, authorize,
                                 public_request_id=None):
        from .timeline_commit import CommitRejected
        from .timeline_commit_execution import (
            _emit_redacted_diagnostic,
            _history_diagnostic_reason,
            _is_history_failure,
            _new_request_id,
            current_public_request_id,
            current_commit_timing,
        )
        from .timeline_commit_port import (
            CommitUnavailable,
            RequestCommitPort,
            detached,
            public_failure,
        )
        from .timeline_commit_reference_projection import ReferenceProjectionError
        if public_request_id is None:
            public_request_id = current_public_request_id()
        if not isinstance(publisher, str) or not publisher:
            raise AuthorizationError("authenticated publisher is required")
        idempotency_key = require_idempotency_key(idempotency_key)
        # A retry must authenticate against the current bearer and canonical
        # project before it can inspect the durable idempotency row.  Archived
        # liveness is deferred until the lookup misses, so an exact replay can
        # still be returned without reopening the mutable producer scope.
        check = self._timeline_authorize(project_id, timeline_id, authorize, allow_archived=True)

        def require_active():
            check()
            with self.store._mutex:
                connection = self.store.conn
                if connection is None:
                    raise RuntimeError("runtime store is not open")
                row = connection.execute(
                    "SELECT 1 FROM timelines WHERE id=? AND project_id=? AND archived_at IS NULL",
                    (timeline_id, project_id),
                ).fetchone()
                if row is None:
                    raise NotFoundError("timeline not found")

        invocation = {"operation": operation, "path": invocation_path, "body": detached(original_body)}
        request_hash = hashlib.sha256(canonical_json({
            "operation": operation, "path": invocation_path,
            "publisher": publisher, "request": invocation["body"],
        }).encode()).hexdigest()
        context = {"request": detached(request), "invocation": invocation,
                   "request_hash": request_hash, "idempotency_key": idempotency_key,
                   "publisher": publisher, "realm_id": self.realm["id"]}
        request_id = _new_request_id()
        timing = current_commit_timing()
        if timing is not None:
            timing.set_request_id(request_id)
            timing.begin("service_admission")
        commits, coordinator = self._timeline_commits()
        with self.store._mutex:
            self._timeline_commit_started = True
            provider = self._timeline_commit_provider
        def port_factory(bound_context):
            require_active()
            self._ensure_timeline_commit_baseline(commits, project_id, timeline_id, require_active)
            current_head = commits.head(project_id, timeline_id)
            self._verify_legacy_media_selections(commits.revision_closure(project_id, timeline_id, current_head["revision_id"]))
            return RequestCommitPort(self, commits, bound_context, require_active)
        if timing is not None:
            timing.end("service_admission")
        try:
            if provider is None:
                replay = commits.lookup(context, authorize=check)
                if replay is not None:
                    return replay
                require_active()
                _emit_redacted_diagnostic(
                    request_id, reason="provider_none", public_request_id=public_request_id,
                    idempotency_key=idempotency_key,
                )
                raise CommitUnavailable()
            outcome = coordinator.execute(context, provider, port_factory, authorize=check,
                                          diagnostic_request_id=request_id,
                                          public_request_id=public_request_id,
                                          idempotency_key=idempotency_key)
            if "http_status" in outcome:
                failure = public_failure(outcome)
                if _is_history_failure(outcome):
                    failure.__dict__["_diagnostic_reason"] = "provider_history_guard"
                raise failure
            return outcome
        except CommitRejected as exc:
            from .timeline_commit_execution import (
                _emit_redacted_diagnostic,
                _history_diagnostic_reason,
            )
            reason = _history_diagnostic_reason(
                exc.failure, source_reason=getattr(exc, "_diagnostic_reason", None)
            )
            if reason is not None:
                _emit_redacted_diagnostic(
                    request_id, reason=reason, public_request_id=public_request_id,
                    idempotency_key=idempotency_key,
                )
            raise public_failure(exc.failure) from exc
        except (AuthorizationError, ForbiddenError, NotFoundError, ValidationError, ConflictError) as exc:
            if isinstance(exc, ConflictError) and isinstance(exc.details, dict):
                from .timeline_commit_execution import (
                    _emit_redacted_diagnostic,
                    _history_diagnostic_reason,
                )
                reason = _history_diagnostic_reason(
                    {"details": exc.details}, source_reason=getattr(exc, "_diagnostic_reason", None)
                )
                if reason is not None:
                    _emit_redacted_diagnostic(
                        request_id, reason=reason, public_request_id=public_request_id,
                        idempotency_key=idempotency_key,
                    )
            raise
        except ReferenceProjectionError as exc:
            if exc.reason == "history_unavailable":
                _emit_redacted_diagnostic(
                    request_id, reason="store_reference_projection_apply_history",
                    public_request_id=public_request_id, idempotency_key=idempotency_key,
                )
            else:
                _emit_redacted_diagnostic(
                    request_id, exc, public_request_id=public_request_id,
                    idempotency_key=idempotency_key,
                )
            raise CommitUnavailable() from exc
        except RuntimeErrorBase as exc:
            reason = _history_diagnostic_reason(
                {"details": exc.details}, source_reason=getattr(exc, "_diagnostic_reason", None)
            )
            if reason is not None:
                _emit_redacted_diagnostic(
                    request_id, reason=reason, public_request_id=public_request_id,
                    idempotency_key=idempotency_key,
                )
            raise
        except Exception as exc:
            _emit_redacted_diagnostic(
                request_id, exc, public_request_id=public_request_id,
                idempotency_key=idempotency_key,
            )
            raise CommitUnavailable() from exc

    def _ensure_timeline_commit_baseline(self, commits, project_id, timeline_id, authorize):
        with self.store._mutex:
            authorize()
            row = self.store.conn.execute(
                "SELECT publication_id FROM parent_composition_heads WHERE project_id=? AND timeline_id=?",
                (project_id, timeline_id),
            ).fetchone()
            if row is None or row["publication_id"] is None:
                commits.head(project_id, timeline_id)

    @_clear_replay_on_refusal
    def list_timeline_commits(self, project_id, timeline_id, *, cursor=None,
                              limit=PAGE_DEFAULT_LIMIT, authorize):
        from .timeline_commit import CommitRejected
        from .timeline_commit_port import public_failure
        # The public HTTP query is text, while the commit store deliberately
        # accepts only an already-validated integer.  Keep cursor validation
        # and fixed-head binding in the commit store; this call only normalizes
        # the independent public limit argument.
        limit, _ = _page_args(None, limit)
        check = self._timeline_authorize(project_id, timeline_id, authorize, mutation=False)
        commits, _ = self._timeline_commits()
        try:
            with commits.verification_scope(), self.store._mutex:
                check()
                self._ensure_timeline_commit_baseline(commits, project_id, timeline_id, check)
                return commits._read_history(project_id, timeline_id, cursor=cursor, limit=limit)
        except CommitRejected as exc:
            from .timeline_commit_execution import (
                _emit_redacted_diagnostic,
                _history_diagnostic_reason,
                _new_request_id,
            )
            reason = _history_diagnostic_reason(
                exc.failure, source_reason=getattr(exc, "_diagnostic_reason", None)
            )
            if reason is not None:
                _emit_redacted_diagnostic(_new_request_id(), reason=reason)
            raise public_failure(exc.failure) from exc
        except ConflictError as exc:
            if isinstance(exc.details, dict):
                from .timeline_commit_execution import (
                    _emit_redacted_diagnostic,
                    _history_diagnostic_reason,
                    _new_request_id,
                )
                reason = _history_diagnostic_reason({"details": exc.details})
                if reason is not None:
                    _emit_redacted_diagnostic(_new_request_id(), reason=reason)
            raise

    @_clear_replay_on_refusal
    def _verified_read(self, project_id, authorize, read):
        from .timeline_commit import CommitRejected
        from .timeline_commit_port import public_failure
        check = self._timeline_authorize(project_id, None, authorize, mutation=False)
        try:
            with self.store._mutex:
                check()
                return read()
        except CommitRejected as exc:
            from .timeline_commit_execution import (
                _emit_redacted_diagnostic,
                _history_diagnostic_reason,
                _new_request_id,
            )
            reason = _history_diagnostic_reason(
                exc.failure, source_reason=getattr(exc, "_diagnostic_reason", None)
            )
            if reason is not None:
                _emit_redacted_diagnostic(_new_request_id(), reason=reason)
            raise public_failure(exc.failure) from exc
        except ConflictError as exc:
            if isinstance(exc.details, dict):
                from .timeline_commit_execution import (
                    _emit_redacted_diagnostic,
                    _history_diagnostic_reason,
                    _new_request_id,
                )
                reason = _history_diagnostic_reason({"details": exc.details})
                if reason is not None:
                    _emit_redacted_diagnostic(_new_request_id(), reason=reason)
            raise

    def get_project_media_selection(self, project_id, selectors, *, authorize):
        self._assert_mutation_admitted()
        from .timeline_commit_port import MediaReads, detached
        selectors = detached(selectors)
        if not isinstance(selectors, dict) or set(selectors) not in (
                {"asset", "generation_id", "variant_id"}, {"association_id", "object_id", "version"}):
            raise ValidationError("exactly one complete media selector form is required")
        return self._verified_read(project_id, authorize, lambda: MediaReads(self).selection(project_id, **selectors))

    def get_project_verified_media(self, project_id, selection, *, authorize):
        from .timeline_commit_port import MediaReads, detached
        selection = detached(selection)
        return self._verified_read(project_id, authorize, lambda: MediaReads(self).selected(project_id, selection))

    def get_project_verified_document_object(self, project_id, pin, object_id, *, authorize):
        from .timeline_commit_port import detached, read_project_pack_object
        pin = detached(pin)
        return self._verified_read(project_id, authorize, lambda: read_project_pack_object(self, project_id, pin, object_id))

    def get_project_verified_document(self, project_id, pin, *, authorize):
        from .timeline_commit_port import detached, read_project_source_document
        pin = detached(pin)
        return self._verified_read(project_id, authorize, lambda: read_project_source_document(self, project_id, pin))

    def restore_project_parent_composition_revision(self, project_id, timeline_id, revision, body, *,
                                                    idempotency_key=None, publisher=None,
                                                    invocation_path=None, authorize=None,
                                                    public_request_id=None):
        from .timeline_commit_port import detached, route_path
        body = detached(body)
        if not isinstance(body, dict) or set(body) != {"expected_head", "expected_publication_id"}:
            raise ValidationError("restore requires expected_head and expected_publication_id only")
        if any(not isinstance(value, str) or not value for value in body.values()):
            raise ValidationError("restore requires both nonempty head guards")
        expected_path = route_path(project_id, timeline_id,
                                   "composition-revisions/" + quote(revision, safe="") + "/restore")
        if invocation_path != expected_path:
            raise ValidationError("restore invocation must use its canonical Runtime path")
        request = {"api_version": 1, "project_id": project_id, "timeline_id": timeline_id,
                   "base_revision_id": body["expected_head"],
                   "base_publication_id": body["expected_publication_id"], "dry_run": False,
                   "commands": [{"schema_version": 1, "op": "timeline.restore", "version": "1",
                                 "select": None, "args": {"revision_id": revision}}]}
        return self._execute_timeline_commit(
            project_id, timeline_id, request, body, operation="restoreProjectParentCompositionRevision",
            idempotency_key=idempotency_key, publisher=publisher,
            invocation_path=invocation_path, authorize=authorize,
            public_request_id=public_request_id,
        )

    def inspect_timeline(self, project, timeline_id, options=None):
        """Inspect one immutable timeline closure without reading source media."""
        project_row = self.store.get_project(project)
        with self.store._mutex:
            return inspect_timeline_closure(self.store.conn, project_row["id"], timeline_id, options)

    @_durable_mutation
    def create_timeline_view(self, project, timeline_id, options=None, *, idempotency_key=None):
        """Persist deterministic declared-input views as project-owned objects."""
        idempotency_key = require_idempotency_key(idempotency_key)
        project_row = self.store.get_project(project)
        request_hash = hashlib.sha256(canonical_json({
            "project_id": project_row["id"], "timeline_id": timeline_id, "options": options or {},
        }).encode()).hexdigest()
        replay = self._command_replay("timeline.view", timeline_id, idempotency_key, request_hash, with_receipt=False)
        if replay is not None:
            return replay
        inspection = self.inspect_timeline(project_row["id"], timeline_id, options)
        formats = inspection["selectors"].get("formats") or ["md"]
        artifacts = {}
        for kind in formats:
            if kind == "md":
                data, media_type, suffix = render_timeline_markdown(inspection), "text/markdown", "md"
            elif kind == "png":
                data, media_type, suffix = render_timeline_png(inspection), "image/png", "png"
            else:
                raise ValidationError("unsupported timeline view format")
            artifact_key = "timeline-view-" + hashlib.sha256(canonical_json({
                "project_id": project_row["id"], "timeline_id": timeline_id,
                "snapshot_digest": inspection["snapshot_digest"],
                "selectors": inspection["selectors"], "format": kind,
            }).encode()).hexdigest()
            stored = self.ingest(
                project_row["id"], data, media_type=media_type,
                original_name=f"timeline-{timeline_id}-{suffix}.{suffix}",
                idempotency_key=artifact_key,
            )
            resource = stored["data"]
            artifacts[kind] = {
                "status": "available", "object_id": resource["object_id"],
                "digest": resource["digest"], "size": resource["size"],
                "media_type": resource["media_type"], "filename": resource.get("filename"),
            }
        result = {
            "inspection": inspection,
            "evidence_kind": "declared_inputs",
            "render_requested": False,
            "formats": {kind: {"status": value["status"], "object_id": value["object_id"]} for kind, value in artifacts.items()},
            "artifacts": artifacts,
        }
        return self._command_record("timeline.view", timeline_id, idempotency_key, request_hash, result, with_receipt=False)

    def replace_parent_composition_media(self, project_id, timeline_id, body, *, idempotency_key=None):
        self._require_timeline_command()

    @staticmethod
    def _finite_number(value, field, *, positive=False):
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(float(value)) or (positive and value <= 0):
            raise ValidationError(f"{field} must be a finite number" + (" greater than zero" if positive else ""))
        return value

    def _normalize_occurrence(self, occurrence, *, shot_lookup):
        if not isinstance(occurrence, dict):
            raise ValidationError("occurrences must be objects")
        # Occurrences are authored records, not a transport DTO.  Start from
        # the submitted object so forward-compatible/opaque placement fields
        # survive immutable publication.  The known fields below are then
        # validated and written back in their canonical spellings.
        result = copy.deepcopy(occurrence)
        occurrence_id = occurrence.get("occurrence_id")
        if not isinstance(occurrence_id, str) or not occurrence_id:
            raise ValidationError("occurrence_id is required")
        shot_id = occurrence.get("shot_id")
        shot_revision_id = occurrence.get("shot_revision_id")
        if not isinstance(shot_id, str) or not shot_id or not isinstance(shot_revision_id, str) or not shot_revision_id:
            raise ValidationError("occurrences require shot_id and shot_revision_id")
        shot = shot_lookup.get((shot_id, shot_revision_id))
        if shot is None:
            raise NotFoundError("occurrence shot revision dependency is missing", details={"shot_id": shot_id, "revision_id": shot_revision_id})
        placement = occurrence.get("placement")
        if placement is None:
            placement = {key: occurrence[key] for key in ("start_ms", "track") if key in occurrence}
        if not isinstance(placement, dict) or not placement:
            raise ValidationError("occurrences require placement")
        source_offset = occurrence.get("source_offset", occurrence.get("source_offset_ms", 0))
        if isinstance(source_offset, dict):
            if set(source_offset) & {"start", "end"}:
                for key in ("start", "end"):
                    self._finite_number(source_offset.get(key), f"source_offset.{key}")
        else:
            self._finite_number(source_offset, "source_offset")
        duration = occurrence.get("duration_ms", occurrence.get("duration"))
        if isinstance(duration, bool) or not isinstance(duration, (int, float)) or not math.isfinite(float(duration)) or duration <= 0 or int(duration) != duration:
            raise ValidationError("occurrence duration must be a finite positive integer")
        speed = occurrence.get("speed", 1)
        if isinstance(speed, dict):
            if set(speed) != {"numerator", "denominator"} or isinstance(speed.get("numerator"), bool) or not isinstance(speed.get("numerator"), int) or speed["numerator"] <= 0 or isinstance(speed.get("denominator"), bool) or not isinstance(speed.get("denominator"), int) or speed["denominator"] <= 0:
                raise ValidationError("occurrence speed must be one constant positive rational")
        else:
            self._finite_number(speed, "speed", positive=True)
        track = occurrence.get("track", placement.get("track"))
        if not isinstance(track, str) or not track:
            raise ValidationError("occurrence track is required")
        transform = occurrence.get("transform", {})
        if not isinstance(transform, dict):
            raise ValidationError("occurrence transform must be an object")
        gain = self._finite_number(occurrence.get("gain", 1), "gain")
        muted = occurrence.get("mute", occurrence.get("muted", False))
        if not isinstance(muted, bool):
            raise ValidationError("occurrence mute must be boolean")
        provenance = occurrence.get("provenance", {})
        if not isinstance(provenance, dict):
            raise ValidationError("occurrence provenance must be an object")
        result.update({
            "occurrence_id": occurrence_id,
            "shot_id": shot_id,
            "shot_revision_id": shot_revision_id,
            "placement": copy.deepcopy(placement),
            "source_offset": copy.deepcopy(source_offset),
            "duration_ms": int(duration),
            "speed": copy.deepcopy(speed),
            "track": track,
            "transform": copy.deepcopy(transform),
            "gain": gain,
            "muted": muted,
            "provenance": copy.deepcopy(provenance),
        })
        # These accepted aliases are known/derived rather than opaque fields.
        result.pop("duration", None)
        result.pop("source_offset_ms", None)
        result.pop("mute", None)
        return result

    def _validate_media_dependencies(self, project_id, manifest):
        media = manifest.get("media", []) if isinstance(manifest, dict) else []
        if not isinstance(media, list):
            raise ValidationError("dependency_manifest.media must be a list")
        normalized = []
        seen = set()
        for item in media:
            if isinstance(item, str):
                item = {"media_id": item}
            if not isinstance(item, dict):
                raise ValidationError("media dependencies must be objects")
            media_id = item.get("media_id", item.get("object_id", item.get("digest")))
            if not isinstance(media_id, str):
                raise ValidationError("media dependency requires media_id")
            bare = media_id.removeprefix("sha256:")
            if not re.fullmatch(r"[0-9a-f]{64}", bare):
                raise ValidationError("media dependency identity must be a SHA-256 digest")
            row = self.store.conn.execute("SELECT size FROM objects WHERE digest=?", (bare,)).fetchone()
            owned = self.store.conn.execute("SELECT 1 FROM project_objects WHERE project_id=? AND digest=?", (project_id, bare)).fetchone()
            if not row or not owned:
                raise NotFoundError("media dependency is missing or not owned by project", details={"media_id": "sha256:" + bare})
            data = self.cas.read(bare)
            actual = "sha256:" + hashlib.sha256(data).hexdigest()
            if actual != "sha256:" + bare or len(data) != int(row["size"]):
                raise ConflictError("media dependency bytes do not match identity", details={"media_id": "sha256:" + bare})
            if item.get("size") is not None and (isinstance(item.get("size"), bool) or not isinstance(item.get("size"), int) or int(item["size"]) != int(row["size"])):
                raise ConflictError("media dependency size mismatch", details={"media_id": "sha256:" + bare, "expected_size": int(row["size"]), "actual_size": item.get("size")})
            supplied = item.get("content_digest", actual)
            if supplied != actual:
                raise ConflictError("media dependency content digest mismatch", details={"media_id": "sha256:" + bare, "expected": actual, "actual": supplied})
            if actual not in seen:
                normalized.append({"media_id": actual, "content_digest": actual})
                seen.add(actual)
        return normalized

    def _collect_digest_media(self, value):
        found = set()
        if isinstance(value, dict):
            for key, item in value.items():
                # Only authoritative object identities participate in the
                # media closure.  Canonical shot records also carry record
                # digests and source/content hashes that describe metadata or
                # lineage, not Runtime-owned CAS objects.
                if key in {"media_id", "object_id"} and isinstance(item, str):
                    bare = item.removeprefix("sha256:")
                    if re.fullmatch(r"[0-9a-f]{64}", bare):
                        found.add("sha256:" + bare)
                found.update(self._collect_digest_media(item))
        elif isinstance(value, list):
            for item in value:
                found.update(self._collect_digest_media(item))
        return found

    def publish_parent_composition(self, project_id, timeline_id, body, *, idempotency_key=None):
        RuntimeService._require_timeline_command()

    def _project_shot_resource(self, row):
        value = dict(row)
        value["shot_id"] = value.pop("id")
        value["metadata"] = json.loads(value.pop("metadata_json"))
        value["archived"] = bool(value.pop("archived_at"))
        value["items"] = [self._shot_item_resource(item) for item in self.store.conn.execute("SELECT * FROM shot_items WHERE shot_id=? ORDER BY sort_key, id", (value["shot_id"],))]
        return value

    @staticmethod
    def _shot_item_resource(row):
        value = dict(row)
        value["item_id"] = value.pop("id")
        value["metadata"] = json.loads(value.pop("metadata_json"))
        return value

    @_durable_mutation
    def create_project_shot(self, project_id, body, *, idempotency_key=None):
        """Create an unplaced shot in the project catalog."""
        self._require_object_body(body)
        project = self.store.get_project(project_id)
        name = str(body.get("name") or "")
        if not name.strip():
            raise ValidationError("name is required")
        metadata = body.get("metadata", {})
        if not isinstance(metadata, dict):
            raise ValidationError("metadata must be an object")
        shot_id = str(body.get("shot_id") or new_id())
        existing = self.store.conn.execute("SELECT * FROM project_shots WHERE id=?", (shot_id,)).fetchone()
        if existing is not None and existing["project_id"] != project["id"]:
            raise NotFoundError("shot not found")
        request_hash = hashlib.sha256(canonical_json(body).encode()).hexdigest()
        replay = self._command_replay("shot.create", project["id"], idempotency_key, request_hash, project_id=project["id"])
        if replay is not None:
            return replay
        if existing is not None:
            self._require_unplaced_project_shot(project["id"], shot_id, operation="direct shot catalog mutation")
        if existing is not None:
            raise ConflictError("shot already exists", details={"shot_id": shot_id})
        timestamp = now()
        self.store.conn.execute(
            "INSERT INTO project_shots(id, project_id, name, metadata_json, version, created_at, updated_at, archived_at) "
            "VALUES (?, ?, ?, ?, 1, ?, ?, NULL)",
            (shot_id, project["id"], name, canonical_json(metadata), timestamp, timestamp),
        )
        result = self._project_shot_resource(self.store.conn.execute("SELECT * FROM project_shots WHERE id=?", (shot_id,)).fetchone())
        return self._command_record("shot.create", project["id"], idempotency_key, request_hash, result, project_id=project["id"])

    @_durable_mutation
    def update_project_shot(self, project_id, shot_id, body, *, idempotency_key=None, archived=None):
        """Update catalog metadata, or archive/recover an unplaced shot."""
        require_idempotency_key(idempotency_key)
        self._require_object_body(body)
        project = self.store.get_project(project_id)
        expected = self._expected_version(body)
        action = "update" if archived is None else "archive" if archived else "recover"
        request_hash = hashlib.sha256(canonical_json(body).encode()).hexdigest()
        self._require_project_shot_scope(project["id"], shot_id)
        replay = self._command_replay(f"shot.{action}", str(shot_id), idempotency_key, request_hash, project_id=project["id"])
        if replay is not None:
            return replay
        self._require_unplaced_project_shot(project["id"], shot_id, operation="direct shot catalog mutation")
        row = self.store.conn.execute(
            "SELECT * FROM project_shots WHERE id=? AND project_id=?", (shot_id, project["id"])
        ).fetchone()
        if row is None:
            raise NotFoundError("shot not found")
        if int(row["version"]) != expected:
            raise ConflictError("shot version conflict", details={"expected": expected, "actual": int(row["version"])})
        timestamp = now()
        name = str(body.get("name", row["name"]))
        metadata = body.get("metadata", json.loads(row["metadata_json"]))
        if not name.strip() or not isinstance(metadata, dict):
            raise ValidationError("invalid shot name or metadata")
        archived_at = timestamp if archived is True else None if archived is False else row["archived_at"]
        self.store.conn.execute(
            "UPDATE project_shots SET name=?, metadata_json=?, version=?, updated_at=?, archived_at=? "
            "WHERE id=? AND project_id=? AND version=?",
            (name, canonical_json(metadata), expected + 1, timestamp, archived_at, shot_id, project["id"], expected),
        )
        result = self._project_shot_resource(self.store.conn.execute("SELECT * FROM project_shots WHERE id=?", (shot_id,)).fetchone())
        return self._command_record(f"shot.{action}", str(shot_id), idempotency_key, request_hash, result, project_id=project["id"])

    @_durable_mutation
    def add_shot_item(self, project_id, shot_id, body, *, idempotency_key=None):
        self._require_object_body(body)
        project = self.store.get_project(project_id)
        media_id = str(body.get("media_id") or "").removeprefix("sha256:")
        if not media_id:
            raise ValidationError("media_id is required")
        metadata = body.get("metadata", {})
        if not isinstance(metadata, dict):
            raise ValidationError("metadata must be an object")
        self._require_project_shot_scope(project["id"], shot_id)
        request_hash = hashlib.sha256(canonical_json(body).encode()).hexdigest()
        replay = self._command_replay("shot.item.add", str(shot_id), idempotency_key, request_hash, project_id=project["id"])
        if replay is not None:
            return replay
        self._require_unplaced_project_shot(project["id"], shot_id, operation="direct shot catalog mutation")
        if not self.store.conn.execute(
            "SELECT 1 FROM project_objects WHERE project_id=? AND digest=?", (project["id"], media_id)
        ).fetchone():
            raise NotFoundError("media is not owned by project")
        position = body.get("position")
        rows = self.store.conn.execute(
            "SELECT * FROM shot_items WHERE shot_id=? ORDER BY sort_key, id", (shot_id,)
        ).fetchall()
        if position is None:
            position = len(rows)
        if isinstance(position, bool) or not isinstance(position, int) or position < 0 or position > len(rows):
            raise ValidationError("position is out of range")
        item_id = str(body.get("item_id") or new_id())
        stamp = now()
        self.store.conn.execute(
            "INSERT INTO shot_items(id, shot_id, media_id, sort_key, source_frame, metadata_json, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (item_id, shot_id, media_id, f"~{item_id}", body.get("source_frame"), canonical_json(metadata), stamp),
        )
        ordered_ids = [row["id"] for row in rows]
        ordered_ids.insert(position, item_id)
        for index, ordered_id in enumerate(ordered_ids):
            self.store.conn.execute("UPDATE shot_items SET sort_key=? WHERE id=?", (f"tmp-{index:08d}-{item_id}", ordered_id))
        for index, ordered_id in enumerate(ordered_ids):
            self.store.conn.execute("UPDATE shot_items SET sort_key=? WHERE id=?", (f"{index:08d}", ordered_id))
        self.store.conn.execute(
            "UPDATE project_shots SET version=version+1, updated_at=? WHERE id=? AND project_id=?",
            (stamp, shot_id, project["id"]),
        )
        result = self._project_shot_resource(self.store.conn.execute("SELECT * FROM project_shots WHERE id=?", (shot_id,)).fetchone())
        return self._command_record("shot.item.add", str(shot_id), idempotency_key, request_hash, result, project_id=project["id"])

    def _renumber_shot_items(self, shot_id):
        rows = self.store.conn.execute("SELECT id FROM shot_items WHERE shot_id=? ORDER BY sort_key, id", (shot_id,)).fetchall()
        for index, row in enumerate(rows):
            self.store.conn.execute("UPDATE shot_items SET sort_key=? WHERE id=?", (f"{index:08d}", row["id"]))

    @_durable_mutation
    def remove_shot_item(self, project_id, shot_id, item_id, body, *, idempotency_key=None):
        self._require_object_body(body)
        project = self.store.get_project(project_id)
        expected = self._expected_version(body)
        request_hash = hashlib.sha256(canonical_json({"item_id": item_id, **body}).encode()).hexdigest()
        self._require_project_shot_scope(project["id"], shot_id)
        replay = self._command_replay("shot.item.remove", str(shot_id), idempotency_key, request_hash, project_id=project["id"])
        if replay is not None:
            return replay
        self._require_unplaced_project_shot(project["id"], shot_id, operation="direct shot catalog mutation")
        row = self.store.conn.execute(
            "SELECT * FROM project_shots WHERE id=? AND project_id=?", (shot_id, project["id"])
        ).fetchone()
        if row is None:
            raise NotFoundError("shot not found")
        if int(row["version"]) != expected:
            raise ConflictError("shot version conflict", details={"expected": expected, "actual": int(row["version"])})
        if not self.store.conn.execute("SELECT 1 FROM shot_items WHERE id=? AND shot_id=?", (item_id, shot_id)).fetchone():
            raise NotFoundError("shot item not found")
        self.store.conn.execute("DELETE FROM shot_items WHERE id=?", (item_id,))
        self._renumber_shot_items(shot_id)
        self.store.conn.execute(
            "UPDATE project_shots SET version=version+1, updated_at=? WHERE id=? AND project_id=?",
            (now(), shot_id, project["id"]),
        )
        result = self._project_shot_resource(self.store.conn.execute("SELECT * FROM project_shots WHERE id=?", (shot_id,)).fetchone())
        return self._command_record("shot.item.remove", str(shot_id), idempotency_key, request_hash, result, project_id=project["id"])

    @_durable_mutation
    def reorder_shot_items(self, project_id, shot_id, body, *, idempotency_key=None):
        self._require_object_body(body)
        project = self.store.get_project(project_id)
        expected = self._expected_version(body)
        item_ids = body.get("item_ids") or body.get("items")
        if not isinstance(item_ids, list) or any(not isinstance(item_id, str) for item_id in item_ids) or len(item_ids) != len(set(item_ids)):
            raise ValidationError("items must be a unique complete permutation")
        request_hash = hashlib.sha256(canonical_json(body).encode()).hexdigest()
        self._require_project_shot_scope(project["id"], shot_id)
        replay = self._command_replay("shot.item.reorder", str(shot_id), idempotency_key, request_hash, project_id=project["id"])
        if replay is not None:
            return replay
        self._require_unplaced_project_shot(project["id"], shot_id, operation="direct shot catalog mutation")
        row = self.store.conn.execute(
            "SELECT * FROM project_shots WHERE id=? AND project_id=?", (shot_id, project["id"])
        ).fetchone()
        if row is None:
            raise NotFoundError("shot not found")
        current = [x["id"] for x in self.store.conn.execute("SELECT id FROM shot_items WHERE shot_id=?", (shot_id,))]
        if int(row["version"]) != expected:
            raise ConflictError("shot version conflict", details={"expected": expected, "actual": int(row["version"])})
        if set(map(str, item_ids)) != set(current):
            raise ValidationError("items must name the complete shot permutation")
        for index, item_id in enumerate(item_ids):
            self.store.conn.execute("UPDATE shot_items SET sort_key=? WHERE id=?", (f"tmp-{index:08d}-{shot_id}", item_id))
        for index, item_id in enumerate(item_ids):
            self.store.conn.execute("UPDATE shot_items SET sort_key=? WHERE id=?", (f"{index:08d}", item_id))
        self.store.conn.execute(
            "UPDATE project_shots SET version=version+1, updated_at=? WHERE id=? AND project_id=?",
            (now(), shot_id, project["id"]),
        )
        result = self._project_shot_resource(self.store.conn.execute("SELECT * FROM project_shots WHERE id=?", (shot_id,)).fetchone())
        return self._command_record("shot.item.reorder", str(shot_id), idempotency_key, request_hash, result, project_id=project["id"])

    create_shot = _durable_mutation(_refuse_direct_shot_write)

    _update_shot_state = _verified_mutation(_refuse_direct_shot_write)

    @_durable_mutation
    def promote_project_shot_candidate(self, project_id, shot_id, body, *, idempotency_key=None):
        """Atomically promote a shot candidate and persist its invalidation report.

        The receipt lookup is deliberately the first database read.  A retry
        therefore returns the exact stored result without inspecting the
        mutable shot, candidate, or media projections.
        """
        self._require_object_body(body)
        key = require_idempotency_key(idempotency_key)
        candidate_id = body.get("candidate_item_id")
        expected = body.get("expected_head_seq")
        if not isinstance(candidate_id, str) or not candidate_id:
            raise ValidationError("candidate_item_id is required")
        if isinstance(expected, bool) or not isinstance(expected, int) or expected < 1:
            raise ValidationError("expected_head_seq must be a positive integer")
        timeline_assets = body.get("timeline_assets", [])
        if isinstance(timeline_assets, Mapping):
            timeline_assets = list(timeline_assets.values())
        if not isinstance(timeline_assets, list) or any(not isinstance(item, Mapping) for item in timeline_assets):
            raise ValidationError("timeline_assets must be a list of objects")
        request = {"project_id": str(project_id), "shot_id": str(shot_id), "candidate_item_id": candidate_id, "expected_head_seq": expected, "timeline_assets": timeline_assets}
        request_hash = hashlib.sha256(canonical_json(request).encode()).hexdigest()
        # Receipt-first is important: do not resolve the project or read the
        # shot before proving this is not an idempotent replay.
        replay = self._command_replay("shot.promote_candidate", str(shot_id), key, request_hash, project_id=str(project_id))
        if replay is not None:
            return replay
        project = self.store.get_project(project_id)
        shot_row = self.store.conn.execute("SELECT * FROM project_shots WHERE id=? AND project_id=?", (str(shot_id), project["id"])).fetchone()
        if shot_row is None:
            raise NotFoundError("shot not found")
        actual = int(shot_row["version"])
        if actual != expected:
            raise ConflictError("shot head conflict", details={"expected": expected, "actual": actual})
        item_rows = self.store.conn.execute("SELECT * FROM shot_items WHERE shot_id=? ORDER BY sort_key, id", (str(shot_id),)).fetchall()
        candidate_row = next((row for row in item_rows if str(row["id"]) == candidate_id), None)
        if candidate_row is None:
            raise NotFoundError("shot candidate not found")
        try:
            candidate_metadata = json.loads(candidate_row["metadata_json"])
        except (TypeError, json.JSONDecodeError) as exc:
            raise ValidationError("candidate metadata is invalid") from exc
        if not isinstance(candidate_metadata, dict) or candidate_metadata.get("role") != "primary_visual" or candidate_metadata.get("status") != "candidate":
            raise ValidationError("candidate item must have role='primary_visual' and status='candidate'")
        # Product provenance is carried in metadata, but the authority check
        # is neutral: only verify fields that a producer supplied.
        provenance = candidate_metadata.get("provenance")
        recipe = candidate_metadata.get("recipe")
        for label, value in (("candidate metadata", candidate_metadata), ("candidate provenance", provenance), ("candidate recipe", recipe)):
            if not isinstance(value, Mapping):
                continue
            if value.get("project_id") is not None and str(value["project_id"]) != str(project["id"]):
                raise ValidationError(f"{label} project_id does not match target project")
            if value.get("shot_id") is not None and str(value["shot_id"]) != str(shot_id):
                raise ValidationError(f"{label} shot_id does not match target shot")
            if value.get("target_role") is not None and value["target_role"] != "primary_visual":
                raise ValidationError(f"{label} target_role must be primary_visual")
            supplied_media = value.get("media_id") or value.get("output_media_id")
            if supplied_media is not None and str(supplied_media).removeprefix("sha256:") != str(candidate_row["media_id"]).removeprefix("sha256:"):
                raise ValidationError(f"{label} media_id does not match candidate media")
        media_digest = str(candidate_row["media_id"]).removeprefix("sha256:")
        owned = self.store.conn.execute("SELECT o.* FROM objects o JOIN project_objects po ON po.digest=o.digest WHERE po.project_id=? AND o.digest=?", (project["id"], media_digest)).fetchone()
        if owned is None:
            raise NotFoundError("candidate media is not owned by project")
        # Verify both the durable object identity and the bytes behind it.  A
        # database row alone is not provenance evidence after a damaged CAS.
        try:
            actual_digest = sha256_bytes(self.cas.read(media_digest))
        except Exception as exc:  # pragma: no cover - CAS backend-specific
            raise ValidationError("candidate media is unavailable") from exc
        if actual_digest != media_digest:
            raise ValidationError("candidate media digest does not match stored bytes")
        primaries = []
        for row in item_rows:
            metadata = json.loads(row["metadata_json"])
            if isinstance(metadata, dict) and metadata.get("role") == "primary_visual" and metadata.get("status") == "primary":
                primaries.append((row, metadata))
        if len(primaries) > 1:
            raise ValidationError("shot must contain at most one primary_visual item")
        if primaries and str(primaries[0][0]["id"]) == candidate_id:
            raise ValidationError("candidate item is already the primary")
        updates = []
        superseded_id = None
        if primaries:
            old_row, old_metadata = primaries[0]
            superseded_id = str(old_row["id"])
            old_metadata = dict(old_metadata); old_metadata["status"] = "superseded"
            updates.append((superseded_id, old_metadata))
        candidate_metadata = dict(candidate_metadata); candidate_metadata["status"] = "primary"
        updates.append((candidate_id, candidate_metadata))
        stamp = now()
        resulting_head = self.store.promote_shot_items(shot_id, expected, updates, timestamp=stamp)
        changed_shot = self.store.conn.execute("SELECT * FROM project_shots WHERE id=? AND project_id=?", (str(shot_id), project["id"])).fetchone()
        revision = self._record_legacy_shot_revision(project["id"], changed_shot)
        promoted = {"shot_id": str(shot_id), "project_id": str(project["id"]), "candidate_item_id": candidate_id, "primary_item_id": candidate_id, "superseded_item_id": superseded_id, "item_ids": [str(row["id"]) for row in item_rows], "event_head_seq": resulting_head}
        item_resources = []
        for row in self.store.conn.execute("SELECT * FROM shot_items WHERE shot_id=? ORDER BY sort_key, id", (shot_id,)).fetchall():
            value = self._shot_item_resource(row)
            value["media_id"] = "sha256:" + str(value["media_id"]).removeprefix("sha256:")
            item_resources.append(value)
        media_records = []
        for row in self.store.conn.execute("SELECT o.* FROM objects o JOIN project_objects po ON po.digest=o.digest WHERE po.project_id=? ORDER BY o.digest", (project["id"],)).fetchall():
            media_records.append({"id": "sha256:" + str(row["digest"]), "media_id": "sha256:" + str(row["digest"]), "content_hash": "sha256:" + str(row["digest"]), "digest": "sha256:" + str(row["digest"])})
        relation_rows = self.store.conn.execute("SELECT * FROM media_relations WHERE project_id=? ORDER BY from_digest, to_digest, kind, ordinal", (project["id"],)).fetchall()
        relations = [{"from_media_id": "sha256:" + str(row["from_digest"]), "to_media_id": "sha256:" + str(row["to_digest"]), "kind": row["kind"], "ordinal": int(row["ordinal"]), "metadata": json.loads(row["metadata_json"])} for row in relation_rows]
        invalidation = analyze_invalidation(item_resources, media_records, timeline_assets, media_relations=relations)
        result = {"promotion": promoted, "invalidation": invalidation, "revision_id": revision["revision_id"], "internal_timeline_revision_id": revision["internal_timeline_revision_id"], "content_digest": revision["content_digest"]}
        return self._command_record("shot.promote_candidate", str(shot_id), key, request_hash, result, project_id=project["id"])

    @_durable_mutation
    def create_project_reference(self, project_id, body, *, idempotency_key=None):
        self._require_object_body(body)
        project = self.store.get_project(project_id)
        kind, name = str(body.get("kind") or ""), str(body.get("name") or "")
        if kind not in {"character", "place", "object", "clothing", "other"}:
            raise ValidationError("invalid reference kind")
        if not name.strip():
            raise ValidationError("name is required")
        if "object_id" in body:
            raise ValidationError("object_id is not supported; use media_id")
        media_id = str(body.get("media_id") or "").removeprefix("sha256:")
        reference_id = str(body.get("reference_id") or "")
        if not media_id:
            raise ValidationError("media_id is required")
        if not reference_id:
            reference_id = new_id()
        metadata = body.get("metadata", {})
        if not isinstance(metadata, dict):
            raise ValidationError("metadata must be an object")
        request_hash = hashlib.sha256(canonical_json(body).encode()).hexdigest()
        with self.store._mutex:
            replay = self._command_replay("reference.create", project["id"], idempotency_key, request_hash, project_id=project["id"])
            if replay is not None:
                return replay
            if self.store.conn.execute("SELECT 1 FROM project_references WHERE id=?", (reference_id,)).fetchone():
                raise ConflictError("reference already exists", details={"reference_id": reference_id})
            if not self.store.conn.execute("SELECT 1 FROM project_objects WHERE project_id=? AND digest=?", (project["id"], media_id)).fetchone():
                raise NotFoundError("media is not owned by project")
            timestamp = now()
            self.store.conn.execute("INSERT INTO project_references(id, project_id, kind, name, description, metadata_json, version, created_at, updated_at, archived_at) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, NULL)", (reference_id, project["id"], kind, name, str(body.get("description") or ""), canonical_json(metadata), timestamp, timestamp))
            self.store.conn.execute("INSERT INTO media_references(id, reference_id, media_id, role, ordinal, is_primary, metadata_json, created_at) VALUES (?, ?, ?, 'canonical', 0, 1, '{}', ?)", (new_id(), reference_id, media_id, timestamp))
            result = self._project_reference_resource(self.store.conn.execute("SELECT * FROM project_references WHERE id=?", (reference_id,)).fetchone())
            return self._command_record("reference.create", project["id"], idempotency_key, request_hash, result, project_id=project["id"])

    def get_project_shot(self, project_id, shot_id):
        project = self.store.get_project(project_id)
        row = self.store.conn.execute("SELECT * FROM project_shots WHERE id=? AND project_id=?", (shot_id, project["id"])).fetchone()
        if not row: raise NotFoundError("shot not found")
        return self._project_shot_resource(row)

    # -- immutable shot text bindings -----------------------------------

    @staticmethod
    def _text_binding_id(project_id, shot_id, kind, slot):
        if not isinstance(kind, str) or kind not in TEXT_BINDING_KINDS:
            raise ValidationError("kind must be prompt, voiceover_script, or transcript", details={"reason": "kind"})
        if slot is not None and (kind != "prompt" or not isinstance(slot, str) or not TEXT_BINDING_SLOT_RE.fullmatch(slot)):
            raise ValidationError("slot is allowed only for prompt bindings and must be a lowercase slug", details={"reason": "slot"})
        identity = {"schema": TEXT_BINDING_IDENTITY_SCHEMA, "project_id": str(project_id), "shot_id": str(shot_id), "kind": kind, "slot": slot}
        return str(uuid.uuid5(uuid.NAMESPACE_URL, canonical_json(identity)))

    def _require_project_shot_scope(self, project_id, shot_id):
        """Reject a foreign catalog row without disclosing its existence."""
        row = self.store.conn.execute("SELECT project_id FROM project_shots WHERE id=?", (shot_id,)).fetchone()
        if row is not None and row["project_id"] != project_id:
            raise NotFoundError("shot not found")
        return row

    def _require_unplaced_project_shot(self, project_id, shot_id, *, operation="direct text binding"):
        """Return a project-library shot that is absent from accepted film history."""
        shot = self.store.conn.execute(
            "SELECT id FROM project_shots WHERE id=? AND project_id=?", (shot_id, project_id)
        ).fetchone()
        if shot is None:
            raise NotFoundError("shot not found")
        placed = self.store.conn.execute(
            "SELECT 1 FROM composition_revision_occurrences occurrence "
            "JOIN parent_composition_revisions parent ON parent.id=occurrence.parent_revision_id "
            "WHERE occurrence.project_id=? AND occurrence.shot_id=? AND parent.project_id=? LIMIT 1",
            (project_id, shot_id, project_id),
        ).fetchone()
        legacy = self.store.conn.execute(
            "SELECT 1 FROM timeline_shots shot "
            "JOIN timelines timeline ON timeline.id=shot.timeline_id "
            "WHERE shot.id=? AND timeline.project_id=? "
            "UNION ALL "
            "SELECT 1 FROM timeline_revisions revision "
            "JOIN timelines timeline ON timeline.id=revision.timeline_id "
            "JOIN json_each(revision.shots_json) snapshot "
            "WHERE timeline.project_id=? "
            "AND (json_extract(snapshot.value, '$.id')=? OR json_extract(snapshot.value, '$.shot_id')=?) "
            "LIMIT 1",
            (shot_id, project_id, project_id, shot_id, shot_id),
        ).fetchone()
        if legacy is not None:
            placed = legacy
        if placed is not None:
            details = {
                "reason": "shot_in_film_history",
                "shot_id": str(shot_id),
                "replacement": "timeline.commit",
            }
            if operation == "direct shot catalog mutation":
                raise RetiredRouteError(
                    "direct shot writes are retired for film-owned shots; use timeline commands",
                    details=details,
                )
            raise ConflictError(
                f"{operation} is limited to unplaced project shots",
                details=details,
            )
        return shot

    @staticmethod
    def _freeze_text(value):
        if isinstance(value, str):
            value = value.encode("utf-8")
        if not isinstance(value, (bytes, bytearray, memoryview)):
            raise ValidationError("text must be UTF-8 text or bytes", details={"reason": "text"})
        data = bytes(value)
        if len(data) > TEXT_BINDING_MAX_BYTES:
            raise ValidationError("text exceeds 1 MiB", details={"reason": "too_large"})
        try:
            data.decode("utf-8", errors="strict")
        except UnicodeDecodeError as exc:
            raise ValidationError("text is not valid UTF-8", details={"reason": "invalid_utf8"}) from exc
        return data, sha256_bytes(data)

    def _verify_text_object(self, project_id, digest, *, candidate=False):
        digest = str(digest).removeprefix("sha256:")
        if not re.fullmatch(r"[0-9a-f]{64}", digest):
            details = {"reason": "malformed_hash", "media_id": "sha256:" + digest}
            if candidate:
                raise ValidationError("text media candidate failed integrity", details=details)
            raise ConflictError("bound text media failed integrity", details=details)
        row = self.store.conn.execute(
            "SELECT o.* FROM objects o JOIN project_objects po ON po.digest=o.digest "
            "WHERE o.digest=? AND po.project_id=? AND po.relation='managed'", (digest, project_id)
        ).fetchone()
        reason = None
        if row is None:
            reason = "media_not_owned"
        elif not str(row["media_type"]).startswith("text/"):
            reason = "media_type_not_text"
        elif int(row["size"]) > TEXT_BINDING_MAX_BYTES:
            reason = "text_too_large"
        else:
            path = self.cas.path_for(digest)
            try:
                if path.is_symlink() or not path.is_file():
                    reason = "managed_file_not_regular"
                else:
                    data = path.read_bytes()
                    if len(data) != int(row["size"]): reason = "managed_size_mismatch"
                    elif sha256_bytes(data) != digest: reason = "managed_hash_mismatch"
                    else:
                        data.decode("utf-8", errors="strict")
            except UnicodeDecodeError:
                reason = "managed_bytes_invalid_utf8"
            except (OSError, ValidationError):
                reason = "managed_file_missing"
        if reason:
            details = {"reason": reason, "media_id": "sha256:" + digest}
            if candidate:
                raise ValidationError("text media candidate failed integrity", details=details)
            raise ConflictError("bound text media failed integrity", details=details)
        return row

    @staticmethod
    def _text_binding_events(connection, row):
        events = connection.execute(
            "SELECT event_id, project_id, seq, kind, payload_json, previous_hash, event_hash "
            "FROM shot_text_binding_events WHERE binding_id=? ORDER BY seq", (row["id"],)
        ).fetchall()
        if int(row["head_seq"]) != len(events) or any(int(event["seq"]) != index for index, event in enumerate(events, 1)):
            raise ConflictError("text binding replay ordering is corrupt", details={"reason": "binding_event_order"})
        previous_hash = ""
        for event in events:
            try:
                payload = json.loads(event["payload_json"])
            except (TypeError, json.JSONDecodeError):
                raise ConflictError("text binding event payload is corrupt", details={"reason": "binding_event_payload"})
            if not isinstance(payload, dict) or payload.get("state", "present") not in ("present", "absent"):
                raise ConflictError("text binding event state is corrupt", details={"reason": "binding_event_state"})
            if str(event["project_id"]) != str(row["project_id"]) or str(event["previous_hash"]) != previous_hash:
                raise ConflictError("text binding event chain is corrupt", details={"reason": "binding_event_chain"})
            expected_hash = hashlib.sha256(canonical_json({
                "event_id": event["event_id"], "binding_id": row["id"], "seq": int(event["seq"]),
                "kind": event["kind"], "payload": payload, "previous_hash": previous_hash,
            }).encode()).hexdigest()
            if str(event["event_hash"]) != expected_hash:
                raise ConflictError("text binding event hash is corrupt", details={"reason": "binding_event_hash"})
            previous_hash = expected_hash
        if not events or payload.get("media_id") != "sha256:" + row["media_digest"]:
            raise ConflictError("text binding head differs from its anchor", details={"reason": "binding_head_mismatch"})
        return events

    def _text_binding_resource(self, row, *, verify=True, include_absent=False):
        project_id = str(row["project_id"])
        shot = self.store.conn.execute("SELECT project_id FROM project_shots WHERE id=?", (row["shot_id"],)).fetchone()
        if shot is None or str(shot["project_id"]) != project_id:
            raise ConflictError("text binding shot is outside its project", details={"reason": "binding_shot_project_mismatch"})
        expected_id = self._text_binding_id(project_id, row["shot_id"], row["kind"], row["slot"])
        if str(row["id"]) != expected_id:
            raise ConflictError("text binding identity is corrupt", details={"reason": "binding_natural_tuple_mismatch"})
        expected_stream = expected_id + ":shot.text_binding"
        if str(row["event_stream_id"]) != expected_stream:
            raise ConflictError("text binding stream identity is corrupt", details={"reason": "binding_stream_id_mismatch"})
        events = self._text_binding_events(self.store.conn, row)
        present = json.loads(events[-1]["payload_json"]).get("state", "present") == "present"
        if verify:
            media = self._verify_text_object(project_id, row["media_digest"])
        else:
            media = self.store.conn.execute("SELECT * FROM objects WHERE digest=?", (row["media_digest"],)).fetchone()
        if media is None:
            raise ConflictError("bound text media is missing", details={"reason": "bound_media_missing"})
        if not present and not include_absent:
            return None
        return {
            "binding_id": str(row["id"]), "project_id": project_id, "shot_id": str(row["shot_id"]),
            "kind": str(row["kind"]), "slot": row["slot"], "media_id": "sha256:" + str(media["digest"]),
            "event_stream_id": str(row["event_stream_id"]), "head": int(row["head_seq"]),
            "content_hash": "sha256:" + str(media["digest"]), "mime_type": str(media["media_type"]),
            "byte_size": int(media["size"]), "created_at": str(row["created_at"]), "updated_at": str(row["updated_at"]),
        }

    def _resolve_text_binding(self, project_id, body):
        binding_id = body.get("binding_id")
        if binding_id is not None:
            if any(body.get(key) is not None for key in ("shot_id", "shot_ref", "kind", "slot")):
                raise ValidationError("binding_id cannot be combined with friendly selectors")
            row = self.store.conn.execute(
                "SELECT * FROM shot_text_bindings WHERE id=? AND project_id=?", (str(binding_id), project_id)
            ).fetchone()
            if row is None:
                raise NotFoundError("text binding not found")
            return row
        shot_id = body.get("shot_id") or body.get("shot_ref")
        kind = body.get("kind")
        if not shot_id or not kind:
            raise ValidationError("shot_id and kind are required")
        slot = body.get("slot")
        self._text_binding_id(project_id, shot_id, kind, slot)
        params = [project_id, shot_id, kind]
        query = "SELECT * FROM shot_text_bindings WHERE project_id=? AND shot_id=? AND kind=?"
        if "slot" in body:
            query += " AND slot IS ?"
            params.append(slot)
        rows = self.store.conn.execute(
            query + " ORDER BY slot IS NOT NULL ASC, slot ASC, id ASC", tuple(params)
        ).fetchall()
        if not rows:
            raise NotFoundError("text binding not found")
        if len(rows) > 1:
            raise ConflictError(
                "text binding selector is ambiguous",
                details={"reason": "ambiguous_selector", "candidates": [str(value["id"]) for value in rows]},
            )
        return rows[0]

    def _text_binding_identity(self, project_id, body, expected):
        if expected == 0:
            if body.get("binding_id") is not None:
                raise ValidationError("head 0 requires a friendly shot selector", details={"reason": "expected_head"})
        elif body.get("binding_id") is not None:
            if any(body.get(key) is not None for key in ("shot_id", "shot_ref", "kind", "slot")):
                raise ValidationError("binding_id cannot be combined with friendly selectors")
        shot_id = body.get("shot_id") or body.get("shot_ref")
        if expected == 0 and not shot_id:
            raise ValidationError("shot_id is required")
        if body.get("binding_id") is not None:
            binding_id = str(body["binding_id"])
        else:
            binding_id = self._text_binding_id(project_id, shot_id, body.get("kind"), body.get("slot"))
        return binding_id, binding_id + ":shot.text_binding"

    def _record_text_binding_event(self, row, event_kind, payload, *, timestamp):
        prior = self.store.conn.execute(
            "SELECT event_hash FROM shot_text_binding_events WHERE binding_id=? ORDER BY seq DESC LIMIT 1",
            (row["id"],),
        ).fetchone()
        previous_hash = str(prior[0]) if prior else ""
        seq = int(row["head_seq"]) + 1
        event_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"{row['id']}:shot.text_binding:{seq}"))
        event_hash = hashlib.sha256(canonical_json({
            "event_id": event_id, "binding_id": row["id"], "seq": seq,
            "kind": event_kind, "payload": payload, "previous_hash": previous_hash,
        }).encode()).hexdigest()
        self.store.conn.execute(
            "INSERT INTO shot_text_binding_events(event_id,binding_id,project_id,seq,kind,payload_json,previous_hash,event_hash,created_at) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (event_id, row["id"], row["project_id"], seq, event_kind, canonical_json(payload), previous_hash, event_hash, timestamp),
        )
        return event_id, seq

    def _materialize_text_object(self, project_id, data, digest):
        existing = self.store.conn.execute("SELECT * FROM objects WHERE digest=?", (digest,)).fetchone()
        if existing is not None:
            if not str(existing["media_type"]).startswith("text/") or int(existing["size"]) > TEXT_BINDING_MAX_BYTES:
                raise ValidationError(
                    "text media candidate failed integrity",
                    details={"reason": "media_type_not_text", "media_id": "sha256:" + digest},
                )
            try:
                path = self.cas.path_for(digest)
                if path.is_symlink() or not path.is_file() or path.read_bytes() != data:
                    raise ValidationError(
                        "text media candidate failed integrity",
                        details={"reason": "managed_hash_mismatch", "media_id": "sha256:" + digest},
                    )
            except OSError as exc:
                raise ValidationError(
                    "text media candidate failed integrity",
                    details={"reason": "managed_file_missing", "media_id": "sha256:" + digest},
                ) from exc
            relation = self.store.conn.execute(
                "SELECT 1 FROM project_objects WHERE project_id=? AND digest=? AND relation='managed'",
                (project_id, digest),
            ).fetchone()
            if relation is None:
                self.store.conn.execute(
                    "INSERT INTO project_objects(project_id,digest,relation,created_at) VALUES (?,?, 'managed', ?)",
                    (project_id, digest, now()),
                )
            return existing
        path = self.cas.path_for(digest)
        if not path.exists():
            self._begin_cas_publication_journal("shot-text-binding", [{"digest": digest}], project_id=project_id)
            self.cas.put(data, expected_digest=digest)
        stamp = now()
        self.store.conn.execute(
            "INSERT INTO objects(digest,size,media_type,original_name,created_at) VALUES (?,?,?,?,?)",
            (digest, len(data), "text/plain", digest + ".txt", stamp),
        )
        self.store.conn.execute(
            "INSERT INTO project_objects(project_id,digest,relation,created_at) VALUES (?,?, 'managed', ?)",
            (project_id, digest, stamp),
        )
        return self.store.conn.execute("SELECT * FROM objects WHERE digest=?", (digest,)).fetchone()

    def _text_binding_event_payload(self, row, media, *, state="present"):
        media_id = "sha256:" + str(media["digest"])
        return {
            "binding_id": str(row["id"]), "project_id": str(row["project_id"]),
            "shot_id": str(row["shot_id"]), "kind": str(row["kind"]), "slot": row["slot"],
            "media_id": media_id, "content_hash": media_id, "byte_size": int(media["size"]),
            "mime_type": str(media["media_type"]), "state": state,
        }

    @_durable_mutation
    def set_project_shot_text_binding(self, project_id, body, *, idempotency_key=None):
        require_idempotency_key(idempotency_key)
        self._require_object_body(body)
        project = self.store.get_project(project_id)
        project_id = str(project["id"])
        expected = body.get("expected_head")
        if isinstance(expected, bool) or not isinstance(expected, int) or expected < 0:
            raise ValidationError("expected_head must be a non-negative integer", details={"reason": "expected_head"})
        data, digest = self._freeze_text(body.get("text"))
        binding_id, stream_id = self._text_binding_identity(project_id, body, expected)
        facts = {
            "project_id": project_id, "binding_id": binding_id, "event_stream_id": stream_id,
            "expected_head": expected, "desired_content_hash": "sha256:" + digest,
        }
        req_hash = hashlib.sha256(canonical_json({"command_kind": "shot.text_binding.set", **facts}).encode()).hexdigest()
        replay = self._command_replay("shot.text_binding.set", binding_id, idempotency_key, req_hash, project_id=project_id)
        if replay is not None:
            return replay
        if expected == 0:
            shot_id = body.get("shot_id") or body.get("shot_ref")
            kind, slot = body.get("kind"), body.get("slot")
            row = self.store.conn.execute("SELECT * FROM shot_text_bindings WHERE id=?", (binding_id,)).fetchone()
        else:
            row = self._resolve_text_binding(project_id, body)
            binding_id, stream_id = str(row["id"]), str(row["event_stream_id"])
            if binding_id != facts["binding_id"]:
                facts = {
                    "project_id": project_id, "binding_id": binding_id, "event_stream_id": stream_id,
                    "expected_head": expected, "desired_content_hash": "sha256:" + digest,
                }
                req_hash = hashlib.sha256(canonical_json({"command_kind": "shot.text_binding.set", **facts}).encode()).hexdigest()
                replay = self._command_replay("shot.text_binding.set", binding_id, idempotency_key, req_hash, project_id=project_id)
                if replay is not None:
                    return replay
            if int(row["head_seq"]) != expected:
                raise ConflictError(
                    "text binding head is stale",
                    details={"expected_head": expected, "actual_head": int(row["head_seq"]), "binding_id": binding_id},
                )
        self._require_unplaced_project_shot(project_id, shot_id if expected == 0 else row["shot_id"])
        if expected == 0 and row is not None:
            raise ConflictError(
                "text binding head is stale",
                details={"expected_head": 0, "actual_head": int(row["head_seq"]), "binding_id": binding_id},
            )
        if expected != 0:
            self._text_binding_resource(row)
        if expected == 0:
            media = self._materialize_text_object(project_id, data, digest)
            stamp = now()
            self.store.conn.execute(
                "INSERT INTO shot_text_bindings(id,project_id,shot_id,kind,slot,media_digest,event_stream_id,head_seq,created_at,updated_at) "
                "VALUES (?,?,?,?,?,?,?,0,?,?)",
                (binding_id, project_id, shot_id, kind, slot, digest, stream_id, stamp, stamp),
            )
            row = self.store.conn.execute("SELECT * FROM shot_text_bindings WHERE id=?", (binding_id,)).fetchone()
            event_id, seq = self._record_text_binding_event(
                row, "shot.text_binding.created", self._text_binding_event_payload(row, media), timestamp=stamp,
            )
            self.store.conn.execute("UPDATE shot_text_bindings SET head_seq=1 WHERE id=?", (binding_id,))
        else:
            media = self._materialize_text_object(project_id, data, digest)
            if str(row["media_digest"]) == digest:
                return {"data": self._text_binding_resource(row), "receipt": None}
            stamp = now()
            event_id, seq = self._record_text_binding_event(
                row, "shot.text_binding.rebound", self._text_binding_event_payload(row, media), timestamp=stamp,
            )
            self.store.conn.execute(
                "UPDATE shot_text_bindings SET media_digest=?, head_seq=?, updated_at=? WHERE id=?",
                (digest, seq, stamp, binding_id),
            )
        result = self._text_binding_resource(
            self.store.conn.execute("SELECT * FROM shot_text_bindings WHERE id=?", (binding_id,)).fetchone()
        )
        return self._command_record(
            "shot.text_binding.set", binding_id, idempotency_key, req_hash, result,
            project_id=project_id, event_ids=(event_id,), primary_stream_id=stream_id, resulting_stream_seq=seq,
        )

    @_durable_mutation
    def rebind_project_shot_text_binding(self, project_id, body, *, idempotency_key=None):
        require_idempotency_key(idempotency_key)
        self._require_object_body(body)
        project = self.store.get_project(project_id)
        project_id = str(project["id"])
        expected = body.get("expected_head")
        if isinstance(expected, bool) or not isinstance(expected, int) or expected < 1:
            raise ValidationError("rebind requires a positive expected_head", details={"reason": "expected_head"})
        desired_digest = str(body.get("media_id") or body.get("content_hash") or "").removeprefix("sha256:")
        if not re.fullmatch(r"[0-9a-f]{64}", desired_digest):
            raise ValidationError("media_id must be a SHA-256 object id", details={"reason": "media_id"})
        binding_id, stream_id = self._text_binding_identity(project_id, body, expected)
        facts = {
            "project_id": project_id, "binding_id": binding_id, "event_stream_id": stream_id,
            "expected_head": expected, "desired_media_id": "sha256:" + desired_digest,
            "desired_content_hash": "sha256:" + desired_digest,
        }
        req_hash = hashlib.sha256(canonical_json({"command_kind": "shot.text_binding.rebind", **facts}).encode()).hexdigest()
        replay = self._command_replay("shot.text_binding.rebind", binding_id, idempotency_key, req_hash, project_id=project_id)
        if replay is not None:
            return replay
        row = self._resolve_text_binding(project_id, body)
        if str(row["id"]) != binding_id:
            binding_id, stream_id = str(row["id"]), str(row["event_stream_id"])
            facts = {
                "project_id": project_id, "binding_id": binding_id, "event_stream_id": stream_id,
                "expected_head": expected, "desired_media_id": "sha256:" + desired_digest,
                "desired_content_hash": "sha256:" + desired_digest,
            }
            req_hash = hashlib.sha256(canonical_json({"command_kind": "shot.text_binding.rebind", **facts}).encode()).hexdigest()
            replay = self._command_replay("shot.text_binding.rebind", binding_id, idempotency_key, req_hash, project_id=project_id)
            if replay is not None:
                return replay
        if int(row["head_seq"]) != expected:
            raise ConflictError(
                "text binding head is stale",
                details={"expected_head": expected, "actual_head": int(row["head_seq"]), "binding_id": str(row["id"])},
            )
        self._require_unplaced_project_shot(project_id, row["shot_id"])
        current = self._text_binding_resource(row)
        media = self._verify_text_object(project_id, desired_digest, candidate=True)
        if str(row["media_digest"]) == desired_digest:
            return {"data": current, "receipt": None}
        stamp = now()
        event_id, seq = self._record_text_binding_event(
            row, "shot.text_binding.rebound", self._text_binding_event_payload(row, media), timestamp=stamp,
        )
        self.store.conn.execute(
            "UPDATE shot_text_bindings SET media_digest=?, head_seq=?, updated_at=? WHERE id=?",
            (desired_digest, seq, stamp, row["id"]),
        )
        result = self._text_binding_resource(
            self.store.conn.execute("SELECT * FROM shot_text_bindings WHERE id=?", (row["id"],)).fetchone()
        )
        return self._command_record(
            "shot.text_binding.rebind", binding_id, idempotency_key, req_hash, result,
            project_id=project_id, event_ids=(event_id,), primary_stream_id=stream_id, resulting_stream_seq=seq,
        )

    def get_project_shot_text_binding(self, project_id, binding_id):
        project = self.store.get_project(project_id)
        row = self.store.conn.execute("SELECT * FROM shot_text_bindings WHERE id=? AND project_id=?", (binding_id, project["id"])).fetchone()
        if row is None: raise NotFoundError("text binding not found")
        resource = self._text_binding_resource(row)
        if resource is None: raise NotFoundError("text binding not found")
        return resource

    def list_project_shot_text_bindings(self, project_id, *, shot_id=None, kind=None, slot=None):
        project = self.store.get_project(project_id); project_id = str(project["id"])
        params = [project_id]; query = "SELECT * FROM shot_text_bindings WHERE project_id=?"
        if shot_id is not None: query += " AND shot_id=?"; params.append(shot_id)
        if kind is not None:
            if kind not in TEXT_BINDING_KINDS: raise ValidationError("invalid text binding kind")
            query += " AND kind=?"; params.append(kind)
        if slot is not None: query += " AND slot=?"; params.append(slot)
        rows = self.store.conn.execute(query + " ORDER BY id", tuple(params)).fetchall()
        return {"items": [resource for row in rows if (resource := self._text_binding_resource(row)) is not None], "next_cursor": None}

    def _project_reference_resource(self, row):
        value = dict(row); value["reference_id"] = value.pop("id"); value["metadata"] = json.loads(value.pop("metadata_json")); value["archived"] = bool(value.pop("archived_at")); value["media_references"] = []
        for assoc in self.store.conn.execute("SELECT * FROM media_references WHERE reference_id=? ORDER BY ordinal, id", (value["reference_id"],)):
            item = dict(assoc); item["association_id"] = item.pop("id"); item["metadata"] = json.loads(item.pop("metadata_json")); item["is_primary"] = bool(item["is_primary"]); item["media_id"] = "sha256:" + item["media_id"]; value["media_references"].append(item)
        value["links"] = [dict(x) for x in self.store.conn.execute("SELECT * FROM reference_links WHERE from_reference_id=? OR to_reference_id=?", (value["reference_id"], value["reference_id"]))]
        return value

    def get_project_reference(self, project_id, reference_id):
        project = self.store.get_project(project_id); row = self.store.conn.execute("SELECT * FROM project_references WHERE id=? AND project_id=?", (reference_id, project["id"])).fetchone()
        if not row: raise NotFoundError("reference not found")
        return self._project_reference_resource(row)

    @_durable_mutation
    def update_project_reference(self, project_id, reference_id, body, *, idempotency_key=None, archived=None):
        idempotency_key = require_idempotency_key(idempotency_key)
        self._require_object_body(body)
        project = self.store.get_project(project_id); expected = self._expected_version(body); action = "update" if archived is None else "archive" if archived else "recover"; request_hash = hashlib.sha256(canonical_json(body).encode()).hexdigest()
        with self.store._mutex:
            replay = self._command_replay(f"reference.{action}", reference_id, idempotency_key, request_hash, project_id=project["id"])
            if replay is not None: return replay
            row = self.store.conn.execute("SELECT * FROM project_references WHERE id=? AND project_id=?", (reference_id, project["id"])).fetchone()
            if not row: raise NotFoundError("reference not found")
            if int(row["version"]) != expected: raise ConflictError("reference version conflict", details={"expected": expected, "actual": int(row["version"])})
            name = str(body.get("name", row["name"])); metadata = body.get("metadata", json.loads(row["metadata_json"]));
            if not name.strip() or not isinstance(metadata, dict): raise ValidationError("invalid reference name or metadata")
            self.store.conn.execute("UPDATE project_references SET name=?, description=?, metadata_json=?, version=version+1, updated_at=?, archived_at=? WHERE id=?", (name, str(body.get("description", row["description"])), canonical_json(metadata), now(), now() if archived is True else None if archived is False else row["archived_at"], reference_id))
            result = self._project_reference_resource(self.store.conn.execute("SELECT * FROM project_references WHERE id=?", (reference_id,)).fetchone()); return self._command_record(f"reference.{action}", reference_id, idempotency_key, request_hash, result, project_id=project["id"])

    @_durable_mutation
    def associate_reference(self, project_id, reference_id, body, *, idempotency_key=None):
        self._require_object_body(body)
        project = self.store.get_project(project_id); media_id = str(body.get("media_id") or "").removeprefix("sha256:"); role = body.get("role") or "depicts"
        if role not in {"canonical", "used_as_input", "depicts", "inspired_by"}: raise ValidationError("invalid reference role")
        self.get_project_reference(project["id"], reference_id)
        if not self.store.conn.execute("SELECT 1 FROM project_objects WHERE project_id=? AND digest=?", (project["id"], media_id)).fetchone(): raise NotFoundError("media is not owned by project")
        request_hash = hashlib.sha256(canonical_json(body).encode()).hexdigest()
        with self.store._mutex:
            replay = self._command_replay("reference.associate", reference_id, idempotency_key, request_hash, project_id=project["id"])
            if replay is not None: return replay
            if not isinstance(body.get("metadata", {}), dict): raise ValidationError("metadata must be an object")
            association_id = str(body.get("association_id") or new_id()); stamp = now()
            if role == "canonical": self.store.conn.execute("UPDATE media_references SET is_primary=0 WHERE reference_id=?", (reference_id,))
            self.store.conn.execute("INSERT INTO media_references(id, reference_id, media_id, role, ordinal, is_primary, metadata_json, created_at) VALUES (?, ?, ?, ?, (SELECT COALESCE(MAX(ordinal)+1,0) FROM media_references WHERE reference_id=?), ?, ?, ?)", (association_id, reference_id, media_id, role, reference_id, 1 if role == "canonical" else 0, canonical_json(body.get("metadata", {})), stamp))
            self.store.conn.execute("UPDATE project_references SET version=version+1, updated_at=? WHERE id=?", (stamp, reference_id)); result = self._project_reference_resource(self.store.conn.execute("SELECT * FROM project_references WHERE id=?", (reference_id,)).fetchone()); return self._command_record("reference.associate", reference_id, idempotency_key, request_hash, result, project_id=project["id"])

    @_durable_mutation
    def link_references(self, project_id, body, *, idempotency_key=None):
        self._require_object_body(body)
        project = self.store.get_project(project_id); source, target, kind = body.get("from_reference_id"), body.get("to_reference_id"), body.get("kind")
        if kind not in {"belongs_to", "wears", "located_in", "associated_with", "related_to"}: raise ValidationError("invalid reference link kind")
        self.get_project_reference(project["id"], source); self.get_project_reference(project["id"], target)
        request_hash = hashlib.sha256(canonical_json(body).encode()).hexdigest()
        with self.store._mutex:
            replay = self._command_replay("reference.link", source, idempotency_key, request_hash, project_id=project["id"])
            if replay is not None: return replay
            stamp = now(); metadata = canonical_json(body.get("metadata", {}))
            self.store.conn.execute("INSERT OR IGNORE INTO reference_links VALUES (?, ?, ?, ?, ?)", (source, target, kind, metadata, stamp))
            if kind == "related_to": self.store.conn.execute("INSERT OR IGNORE INTO reference_links VALUES (?, ?, ?, ?, ?)", (target, source, kind, metadata, stamp))
            result = {"from_reference_id": source, "to_reference_id": target, "kind": kind}; return self._command_record("reference.link", source, idempotency_key, request_hash, result, project_id=project["id"])

    @_durable_mutation
    def set_primary_reference(self, project_id, reference_id, association_id, body, *, idempotency_key=None):
        self._require_object_body(body)
        project = self.store.get_project(project_id); self.get_project_reference(project["id"], reference_id); expected = self._expected_version(body); request_hash = hashlib.sha256(canonical_json({"association_id": association_id, **body}).encode()).hexdigest()
        with self.store._mutex:
            replay = self._command_replay("reference.primary", reference_id, idempotency_key, request_hash, project_id=project["id"])
            if replay is not None: return replay
            row = self.store.conn.execute("SELECT * FROM project_references WHERE id=?", (reference_id,)).fetchone()
            if int(row["version"]) != expected: raise ConflictError("reference version conflict", details={"expected": expected, "actual": int(row["version"])})
            assoc = self.store.conn.execute("SELECT * FROM media_references WHERE id=? AND reference_id=?", (association_id, reference_id)).fetchone()
            if not assoc: raise NotFoundError("media association not found")
            self.store.conn.execute("UPDATE media_references SET is_primary=0 WHERE reference_id=?", (reference_id,)); self.store.conn.execute("UPDATE media_references SET is_primary=1, role='canonical' WHERE id=?", (association_id,)); self.store.conn.execute("UPDATE project_references SET version=version+1, updated_at=? WHERE id=?", (now(), reference_id)); result = self._project_reference_resource(self.store.conn.execute("SELECT * FROM project_references WHERE id=?", (reference_id,)).fetchone()); return self._command_record("reference.primary", reference_id, idempotency_key, request_hash, result, project_id=project["id"])

    def list_timeline_history(self, timeline_id, *, cursor=None, limit=PAGE_DEFAULT_LIMIT):
        self._timeline_resource(timeline_id)
        rows = self.store.conn.execute("SELECT * FROM timeline_revisions WHERE timeline_id=? ORDER BY version", (timeline_id,)).fetchall()
        if not rows:
            current = self._timeline_resource(timeline_id)
            rows = [{"version": current["version"], "shots_json": canonical_json(current["shots"]), "references_json": canonical_json(current["references"]), "created_at": now()}]
        page = _page_rows(rows, scope=f"timeline-history:{timeline_id}", cursor=cursor, limit=limit,
                          key_fn=lambda row: (int(row["version"]),),
                          resource_fn=lambda row: {"timeline_id": timeline_id, "version": int(row["version"]), "shots": json.loads(row["shots_json"]), "references": json.loads(row["references_json"]), "created_at": row["created_at"]})
        return page

    @staticmethod
    def _diff_items(before, after, key):
        old = {str(item.get(key)): item for item in before}
        new = {str(item.get(key)): item for item in after}
        return {"added": [new[item_id] for item_id in sorted(new.keys() - old.keys())], "removed": [old[item_id] for item_id in sorted(old.keys() - new.keys())], "changed": [{"id": item_id, "before": old[item_id], "after": new[item_id]} for item_id in sorted(old.keys() & new.keys()) if old[item_id] != new[item_id]]}

    def diff_timeline(self, timeline_id, from_version, to_version):
        self._timeline_resource(timeline_id)
        before = self._timeline_revision(timeline_id, int(from_version))
        after = self._timeline_revision(timeline_id, int(to_version))
        return {"timeline_id": timeline_id, "from_version": int(from_version), "to_version": int(to_version), "changes": {"shots": self._diff_items(before["shots"], after["shots"], "shot_id"), "references": self._diff_items(before["references"], after["references"], "reference_id")}}

    @_durable_mutation
    def archive_timeline(self, timeline_id, body, *, idempotency_key=None):
        self._require_object_body(body)
        expected = self._expected_version(body)
        current = self._timeline_resource(timeline_id)
        project_id = str(current["project_id"])
        request_hash = hashlib.sha256(canonical_json({
            "timeline_id": timeline_id, "body": body, "action": "archive",
        }).encode()).hexdigest()
        replay = self._command_replay(
            "timeline.archive", timeline_id, idempotency_key, request_hash,
            project_id=project_id,
        )
        if replay is not None:
            return replay
        if current["version"] != expected:
            raise ConflictError(
                "timeline version conflict",
                details={"expected": expected, "actual": current["version"]},
            )
        self.store.conn.execute(
            "UPDATE timelines SET archived_at=?, version=? WHERE id=?",
            (now(), expected + 1, timeline_id),
        )
        resource = self._timeline_resource(timeline_id)
        event_id = self.store._append_timeline_event(
            timeline_id, "timeline.archived", {
                "project_id": project_id, "version": resource["version"],
            },
        )
        event_seq = self.store.conn.execute(
            "SELECT COUNT(*) FROM timeline_events WHERE timeline_id=?",
            (timeline_id,),
        ).fetchone()[0]
        return self._command_record(
            "timeline.archive", timeline_id, idempotency_key, request_hash,
            resource, project_id=project_id, event_ids=(event_id,),
            primary_stream_id=timeline_id, resulting_stream_seq=event_seq,
        )

    @_durable_mutation
    def recover_timeline(self, timeline_id, body, *, idempotency_key=None):
        self._require_object_body(body)
        expected = self._expected_version(body)
        target = body.get("version")
        if "version" in body and (isinstance(target, bool) or not isinstance(target, int) or target < 1):
            raise ValidationError("version must be a positive integer when provided")
        current = self._timeline_resource(timeline_id)
        project_id = str(current["project_id"])
        request_hash = hashlib.sha256(canonical_json({
            "timeline_id": timeline_id, "body": body, "action": "recover",
        }).encode()).hexdigest()
        # This operation is catalog visibility only.  An exact receipt from
        # this implementation remains replayable, but only when its event
        # proves that it was the visibility-only operation.  Check this before
        # the ordinary replay path so absent and current-target retries cannot
        # replay a legacy flat-projection write.
        safe_receipt = self.store.conn.execute(
            "SELECT event_ids_json, primary_stream_id FROM command_idempotency "
            "WHERE command_kind=? AND aggregate_id=? AND idempotency_key=? "
            "AND request_hash=?",
            ("timeline.recover", timeline_id, idempotency_key, request_hash),
        ).fetchone() if idempotency_key is not None else None
        if safe_receipt:
            event_ids = None
            event = None
            payload = None
            try:
                event_ids = json.loads(safe_receipt["event_ids_json"] or "[]")
                if (safe_receipt["primary_stream_id"] == timeline_id
                        and isinstance(event_ids, list) and len(event_ids) == 1
                        and isinstance(event_ids[0], str) and event_ids[0]):
                    event = self.store.conn.execute(
                        "SELECT kind, payload_json FROM timeline_events "
                        "WHERE id=? AND timeline_id=?",
                        (event_ids[0], timeline_id),
                    ).fetchone()
                payload = json.loads(event["payload_json"]) if event else None
            except (TypeError, ValueError, json.JSONDecodeError):
                event_ids = None
                payload = None
            event_version = payload.get("version") if isinstance(payload, dict) else None
            if (event and event["kind"] == "timeline.recovered"
                    and isinstance(payload, dict)
                    and set(payload) == {"project_id", "version"}
                    and payload["project_id"] == project_id
                    and not isinstance(event_version, bool)
                    and isinstance(event_version, int) and event_version > 0
                    and event_version == expected + 1):
                replay = self._command_replay(
                    "timeline.recover", timeline_id, idempotency_key,
                    request_hash, project_id=project_id,
                )
                if replay is not None:
                    return replay
            raise RetiredRouteError(
                "legacy timeline recover cannot restore a historical film version; restore a revision with timeline.restore",
                details={
                    "status": "refused", "reason": "timeline_restore_required",
                    "replacement": "timeline.restore", "requested_version": target,
                    "current_version": current["version"],
                },
            )
        # A historical target is the retired flat-projection writer; canonical
        # history is restored by the recorded timeline.restore command.
        if target is not None and target != current["version"]:
            raise RetiredRouteError(
                "legacy timeline recover cannot restore a historical film version; restore a revision with timeline.restore",
                details={
                    "status": "refused", "reason": "timeline_restore_required",
                    "replacement": "timeline.restore", "requested_version": target,
                    "current_version": current["version"],
                },
            )
        replay = self._command_replay(
            "timeline.recover", timeline_id, idempotency_key, request_hash,
            project_id=project_id,
        )
        if replay is not None:
            return replay
        if current["version"] != expected:
            raise ConflictError(
                "timeline version conflict",
                details={"expected": expected, "actual": current["version"]},
            )
        self.store.conn.execute(
            "UPDATE timelines SET archived_at=NULL, version=? WHERE id=?",
            (expected + 1, timeline_id),
        )
        resource = self._timeline_resource(timeline_id)
        event_id = self.store._append_timeline_event(
            timeline_id, "timeline.recovered", {
                "project_id": project_id, "version": resource["version"],
            },
        )
        event_seq = self.store.conn.execute(
            "SELECT COUNT(*) FROM timeline_events WHERE timeline_id=?",
            (timeline_id,),
        ).fetchone()[0]
        return self._command_record(
            "timeline.recover", timeline_id, idempotency_key, request_hash,
            resource, project_id=project_id, event_ids=(event_id,),
            primary_stream_id=timeline_id, resulting_stream_seq=event_seq,
        )

    def get_shot(self, shot_id):
        row = self.store.conn.execute("SELECT * FROM timeline_shots WHERE id=?", (shot_id,)).fetchone()
        if not row: raise NotFoundError("shot not found")
        return self._shot_resource(row)

    @_durable_mutation
    def create_reference(self, timeline_id, body, *, idempotency_key=None):
        self._require_timeline_command()

    PREFERENCE_DOCUMENT_KIND = "astrid.preferences"
    PROJECT_PREFERENCE_PREFIX = "preferences:project:"

    @classmethod
    def _validate_preference_document(cls, project_id, document_id, kind, content):
        reserved = document_id.startswith(cls.PROJECT_PREFERENCE_PREFIX)
        if reserved or kind == cls.PREFERENCE_DOCUMENT_KIND:
            if document_id != cls.PROJECT_PREFERENCE_PREFIX + project_id:
                raise ValidationError("project preference document identity is reserved for its owning project")
            if kind != cls.PREFERENCE_DOCUMENT_KIND:
                raise ValidationError("project preference document kind is reserved")
            if not isinstance(content, str):
                raise ValidationError("preference content must be a Markdown string")

    def _preference_target(self, scope, project_id, identity):
        if scope not in ("user", "project"):
            raise ValidationError("preference scope must be user or project")
        actor = identity.get("actor") if isinstance(identity, dict) else None
        if not isinstance(actor, str) or not actor:
            raise AuthorizationError("authenticated actor is required")
        if scope == "user":
            if project_id is not None:
                raise ValidationError("user preferences do not accept a project selector")
            return actor, None, "preferences:user:" + actor
        if project_id is None:
            project = self.store.current_project(actor)["project"]
        else:
            project = self.store.get_project(project_id)
        return actor, project["id"], self.PROJECT_PREFERENCE_PREFIX + project["id"]

    @staticmethod
    def _preference_resource(scope, actor, project_id, document_id, row):
        return {
            "scope": scope, "actor_id": actor if scope == "user" else None,
            "project_id": project_id, "document_id": document_id,
            "content": (row["content"] if scope == "user" else json.loads(row["content_json"])) if row else "",
            "version": int(row["version"]) if row else 0,
            "created_at": row["created_at"] if row else None,
            "updated_at": row["updated_at"] if row else None,
        }

    def get_preferences(self, scope, project_id=None, *, identity):
        # Serialize the shared connection read so no caller observes another
        # handler's uncommitted write; absent reads have no side effects.
        with self.store._mutex:
            actor, project_id, document_id = self._preference_target(scope, project_id, identity)
            if scope == "user":
                row = self.store.conn.execute("SELECT * FROM user_preferences WHERE actor_id=?", (actor,)).fetchone()
            else:
                row = self.store.conn.execute("SELECT * FROM project_documents WHERE project_id=? AND id=?", (project_id, document_id)).fetchone()
                if row:
                    self._validate_preference_document(project_id, document_id, row["kind"], json.loads(row["content_json"]))
            return self._preference_resource(scope, actor, project_id, document_id, row)

    @_durable_mutation
    def update_preferences(self, scope, content, expected_version, idempotency_key, project_id=None, *, identity):
        actor, project_id, document_id = self._preference_target(scope, project_id, identity)
        require_idempotency_key(idempotency_key)
        if not isinstance(content, str):
            raise ValidationError("preference content must be a Markdown string")
        if isinstance(expected_version, bool) or not isinstance(expected_version, int) or expected_version < 0:
            raise ValidationError("expected_version must be a non-negative integer")
        request = {"scope": scope, "owner": actor if scope == "user" else project_id,
                   "content": content, "expected_version": expected_version}
        request_hash = hashlib.sha256(canonical_json(request).encode()).hexdigest()
        # The actor is part of the aggregate, not a caller-controlled field.
        aggregate_id = document_id
        replay = self._command_replay("preferences.update", aggregate_id, idempotency_key, request_hash, project_id=project_id)
        if replay is not None:
            return replay
        current = self.get_preferences(scope, project_id, identity=identity)
        if current["version"] != expected_version:
            raise ConflictError("preference version conflict", details={"expected": expected_version, "actual": current["version"]})
        timestamp = now()
        if scope == "user":
            if expected_version == 0:
                self.store.conn.execute("INSERT INTO user_preferences(actor_id, id, content, version, created_at, updated_at) VALUES (?, ?, ?, 1, ?, ?)", (actor, document_id, content, timestamp, timestamp))
            else:
                self.store.conn.execute("UPDATE user_preferences SET content=?, version=?, updated_at=? WHERE actor_id=?", (content, expected_version + 1, timestamp, actor))
        elif expected_version == 0:
            self.store.conn.execute("INSERT INTO project_documents VALUES (?, ?, ?, ?, 1, ?, ?)", (document_id, project_id, self.PREFERENCE_DOCUMENT_KIND, canonical_json(content), timestamp, timestamp))
        else:
            self.store.conn.execute("UPDATE project_documents SET content_json=?, version=?, updated_at=? WHERE project_id=? AND id=?", (canonical_json(content), expected_version + 1, timestamp, project_id, document_id))
        result = self.get_preferences(scope, project_id, identity=identity)
        if scope == "user":
            # A user command has neither a project sequence nor project receipt.
            return self._command_record("preferences.update", aggregate_id, idempotency_key, request_hash, {"data": result, "receipt": None})
        return self._command_record("preferences.update", aggregate_id, idempotency_key, request_hash, result, project_id=project_id)

    APP_STATE_KEY_PATTERN = re.compile(r"[a-z0-9][a-z0-9._-]{0,63}")
    APP_STATE_MAX_BYTES = 16 * 1024

    def _app_state_target(self, key, identity):
        actor = identity.get("actor") if isinstance(identity, dict) else None
        if not isinstance(actor, str) or not actor:
            raise AuthorizationError("authenticated actor is required")
        if not isinstance(key, str) or not self.APP_STATE_KEY_PATTERN.fullmatch(key):
            raise ValidationError("app-state key must be 1-64 characters of a-z, 0-9, '.', '_' or '-' and start with a letter or digit")
        return actor

    @staticmethod
    def _app_state_resource(key, actor, row):
        return {
            "scope": "user", "actor_id": actor, "key": key,
            "content": json.loads(row["content_json"]) if row else None,
            "version": int(row["version"]) if row else 0,
            "created_at": row["created_at"] if row else None,
            "updated_at": row["updated_at"] if row else None,
        }

    def get_app_state(self, key, *, identity):
        # Absent state reads as version zero and writes nothing.
        with self.store._mutex:
            actor = self._app_state_target(key, identity)
            row = self.store.conn.execute("SELECT * FROM user_app_state WHERE actor_id=? AND key=?", (actor, key)).fetchone()
            return self._app_state_resource(key, actor, row)

    @_durable_mutation
    def update_app_state(self, key, content, expected_version, idempotency_key, *, identity):
        actor = self._app_state_target(key, identity)
        require_idempotency_key(idempotency_key)
        if not isinstance(content, dict):
            raise ValidationError("app-state content must be a JSON object")
        if isinstance(expected_version, bool) or not isinstance(expected_version, int) or expected_version < 0:
            raise ValidationError("expected_version must be a non-negative integer")
        encoded = canonical_json(content)
        if len(encoded.encode("utf-8")) > self.APP_STATE_MAX_BYTES:
            raise ValidationError(f"app-state content exceeds {self.APP_STATE_MAX_BYTES} bytes")
        aggregate_id = f"app-state:user:{actor}:{key}"
        request_hash = hashlib.sha256(canonical_json({"owner": actor, "key": key, "content": content, "expected_version": expected_version}).encode()).hexdigest()
        replay = self._command_replay("app_state.update", aggregate_id, idempotency_key, request_hash)
        if replay is not None:
            return replay
        current = self.get_app_state(key, identity=identity)
        if current["version"] != expected_version:
            raise ConflictError("app-state version conflict", details={"expected": expected_version, "actual": current["version"]})
        timestamp = now()
        if expected_version == 0:
            self.store.conn.execute("INSERT INTO user_app_state(actor_id, key, content_json, version, created_at, updated_at) VALUES (?, ?, ?, 1, ?, ?)", (actor, key, encoded, timestamp, timestamp))
        else:
            self.store.conn.execute("UPDATE user_app_state SET content_json=?, version=?, updated_at=? WHERE actor_id=? AND key=?", (encoded, expected_version + 1, timestamp, actor, key))
        result = self.get_app_state(key, identity=identity)
        return self._command_record("app_state.update", aggregate_id, idempotency_key, request_hash, {"data": result, "receipt": None})

    @staticmethod
    def _transcript_document_id(project_id, media_id, source_id):
        # The array order and UTF-8 encoding are part of the cross-client ID
        # contract. canonical_json is compact and leaves Unicode unescaped.
        identity = [TRANSCRIPT_DOCUMENT_SCHEMA, project_id, media_id, source_id]
        digest = hashlib.sha256(canonical_json(identity).encode("utf-8")).hexdigest()
        return TRANSCRIPT_DOCUMENT_PREFIX + digest

    @staticmethod
    def _transcript_string(value, field, limit, *, nonempty=True):
        if not isinstance(value, str) or (nonempty and not value.strip()):
            raise ValidationError(f"transcript {field} must be a non-empty string")
        try:
            size = len(value.encode("utf-8"))
        except UnicodeEncodeError as exc:
            raise ValidationError(f"transcript {field} must be valid Unicode") from exc
        if size > limit:
            raise ValidationError(f"transcript {field} exceeds {limit} UTF-8 bytes")
        return value

    @staticmethod
    def _transcript_time(value, field):
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValidationError(f"transcript {field} must be a finite number")
        if (isinstance(value, float) and not math.isfinite(value)) or value < 0 or value > TRANSCRIPT_MAX_TIME_SECONDS:
            raise ValidationError(f"transcript {field} must be between 0 and {TRANSCRIPT_MAX_TIME_SECONDS} seconds")
        return float(value)

    def _validate_transcript_document(self, project_id, document_id, kind, content):
        is_reserved = document_id.startswith(TRANSCRIPT_DOCUMENT_PREFIX) or kind == TRANSCRIPT_DOCUMENT_KIND
        if not is_reserved:
            return
        if kind != TRANSCRIPT_DOCUMENT_KIND or not document_id.startswith(TRANSCRIPT_DOCUMENT_PREFIX):
            raise ValidationError("transcript document kind and reserved identity must be used together")
        if not isinstance(content, dict) or set(content) != {"schema", "media_id", "source_id", "segments"}:
            raise ValidationError("transcript content must have the canonical media.transcript/v1 fields")
        if content.get("schema") != TRANSCRIPT_DOCUMENT_SCHEMA:
            raise ValidationError("unsupported transcript content schema")

        media_id = content.get("media_id")
        if not isinstance(media_id, str) or not media_id.startswith("sha256:") or not OBJECT_ID_RE.fullmatch(media_id):
            raise ValidationError("transcript media_id must be a canonical sha256 object id")
        source_id = self._transcript_string(content.get("source_id"), "source_id", TRANSCRIPT_SOURCE_ID_MAX_BYTES)
        if document_id != self._transcript_document_id(project_id, media_id, source_id):
            raise ValidationError("transcript document identity does not match its project, media, and source")

        segments = content.get("segments")
        if not isinstance(segments, list) or len(segments) > TRANSCRIPT_MAX_SEGMENTS:
            raise ValidationError(f"transcript segments must be an array of at most {TRANSCRIPT_MAX_SEGMENTS} items")
        segment_ids = set()
        word_ids = set()
        total_words = 0
        for index, segment in enumerate(segments):
            if not isinstance(segment, dict) or set(segment) - {"id", "start", "end", "text", "speaker", "words"} or not {"id", "start", "end", "text"}.issubset(segment):
                raise ValidationError(f"transcript segment {index} has an invalid shape")
            segment_id = self._transcript_string(segment["id"], f"segments[{index}].id", TRANSCRIPT_ID_MAX_BYTES)
            if segment_id in segment_ids:
                raise ValidationError("transcript segment IDs must be unique")
            segment_ids.add(segment_id)
            start = self._transcript_time(segment["start"], f"segments[{index}].start")
            end = self._transcript_time(segment["end"], f"segments[{index}].end")
            if end < start:
                raise ValidationError(f"transcript segment {index} end must not precede start")
            self._transcript_string(segment["text"], f"segments[{index}].text", TRANSCRIPT_TEXT_MAX_BYTES)
            if "speaker" in segment and segment["speaker"] is not None:
                self._transcript_string(segment["speaker"], f"segments[{index}].speaker", TRANSCRIPT_ID_MAX_BYTES)
            words = segment.get("words", [])
            if not isinstance(words, list):
                raise ValidationError(f"transcript segment {index} words must be an array")
            total_words += len(words)
            if total_words > TRANSCRIPT_MAX_WORDS:
                raise ValidationError(f"transcript must contain at most {TRANSCRIPT_MAX_WORDS} words")
            for word_index, word in enumerate(words):
                if not isinstance(word, dict) or set(word) != {"id", "start", "end", "text"}:
                    raise ValidationError(f"transcript word {index}:{word_index} has an invalid shape")
                word_id = self._transcript_string(word["id"], f"segments[{index}].words[{word_index}].id", TRANSCRIPT_ID_MAX_BYTES)
                if word_id in word_ids:
                    raise ValidationError("transcript word IDs must be unique within the document")
                word_ids.add(word_id)
                word_start = self._transcript_time(word["start"], f"segments[{index}].words[{word_index}].start")
                word_end = self._transcript_time(word["end"], f"segments[{index}].words[{word_index}].end")
                if word_end < word_start or word_start < start or word_end > end:
                    raise ValidationError(f"transcript word {index}:{word_index} timing must fit within its segment")
                self._transcript_string(word["text"], f"segments[{index}].words[{word_index}].text", TRANSCRIPT_TEXT_MAX_BYTES)

        try:
            encoded = canonical_json(content).encode("utf-8")
        except (TypeError, ValueError, UnicodeEncodeError) as exc:
            raise ValidationError("transcript content must be canonical UTF-8 JSON") from exc
        if len(encoded) > TRANSCRIPT_MAX_BYTES:
            raise ValidationError(f"transcript content exceeds {TRANSCRIPT_MAX_BYTES} bytes")
        digest = media_id.removeprefix("sha256:")
        owned = self.store.conn.execute(
            "SELECT 1 FROM objects o JOIN project_objects po ON po.digest=o.digest "
            "WHERE o.digest=? AND po.project_id=? AND po.relation='managed'",
            (digest, project_id),
        ).fetchone()
        if not owned:
            raise ValidationError("transcript source media is not managed by the target project", details={"reason": "media_not_owned", "media_id": media_id})

    def _validate_project_document(self, project_id, document_id, kind, content):
        self._validate_preference_document(project_id, document_id, kind, content)
        self._validate_transcript_document(project_id, document_id, kind, content)
        from .timeline_commit_inputs import PROJECT_PACK_KIND, validate_pack_snapshot_objects
        if kind == PROJECT_PACK_KIND:
            validate_pack_snapshot_objects(self.store.conn, project_id, content)

    def _document_resource(self, row):
        content = json.loads(row["content_json"])
        self._validate_project_document(row["project_id"], row["id"], row["kind"], content)
        value = dict(row)
        value["document_id"] = value.pop("id")
        value.pop("content_json")
        value["content"] = content
        return value

    @staticmethod
    def _reject_canonical_document_write(document_id, kind, *, carries_timeline_id=False):
        if carries_timeline_id or str(document_id).startswith("timeline:") or kind == "timeline.composition":
            RuntimeService._require_timeline_command()

    @_durable_mutation
    def create_document(self, project_id, body, *, idempotency_key=None):
        self._require_object_body(body)
        project = self.store.get_project(project_id)
        document_id = str(body.get("document_id") or "")
        kind = str(body.get("kind") or "")
        if not document_id or not kind or "content" not in body:
            raise ValidationError("document_id, kind, and content are required")
        self._reject_canonical_document_write(
            document_id, kind, carries_timeline_id="timeline_id" in body,
        )
        existing = self.store.conn.execute("SELECT * FROM project_documents WHERE project_id=? AND id=?", (project["id"], document_id)).fetchone()
        if existing:
            self._reject_canonical_document_write(existing["id"], existing["kind"])
        content = body["content"]
        self._validate_project_document(project["id"], document_id, kind, content)
        request_hash = hashlib.sha256(canonical_json({"project_id": project["id"], "document_id": document_id, "kind": kind, "content": content}).encode()).hexdigest()
        replay = self._command_replay("document.create", document_id, idempotency_key, request_hash, project_id=project["id"])
        if replay is not None:
            return replay
        if existing:
            if existing["kind"] == kind and json.loads(existing["content_json"]) == content:
                return self._command_record("document.create", document_id, idempotency_key, request_hash, self._document_resource(existing), project_id=project["id"])
            raise ConflictError("document already exists", details={"document_id": document_id})
        timestamp = now()
        self.store.conn.execute("INSERT INTO project_documents VALUES (?, ?, ?, ?, 1, ?, ?)", (document_id, project["id"], kind, canonical_json(content), timestamp, timestamp))
        result = self._document_resource(self.store.conn.execute("SELECT * FROM project_documents WHERE id=?", (document_id,)).fetchone())
        return self._command_record("document.create", document_id, idempotency_key, request_hash, result, project_id=project["id"])

    def list_documents(self, project_id, *, cursor=None, limit=PAGE_DEFAULT_LIMIT, kind=None):
        project = self.store.get_project(project_id)
        # Timeline composition documents are immutable recovery material, not
        # a public document authority. Keep ordinary project documents
        # listable while forcing timeline callers through inspectTimeline.
        rows = self.store.conn.execute(
            "SELECT * FROM project_documents WHERE project_id=? AND id NOT LIKE 'timeline:%' AND (? IS NULL OR kind=?) ORDER BY created_at, id",
            (project["id"], kind, kind),
        ).fetchall()
        return _page_rows(rows, scope=f"documents:{project['id']}" if kind is None else canonical_json({"documents": project["id"], "kind": kind}), cursor=cursor, limit=limit,
                          key_fn=lambda row: (str(row["created_at"]), str(row["id"])),
                          resource_fn=self._document_resource)

    def get_document(self, project_id, document_id):
        project = self.store.get_project(project_id)
        row = self.store.conn.execute("SELECT * FROM project_documents WHERE project_id=? AND id=?", (project["id"], document_id)).fetchone()
        if not row:
            raise NotFoundError("document not found")
        return self._document_resource(row)

    @_durable_mutation
    def update_document(self, project_id, document_id, body, *, idempotency_key=None):
        self._require_object_body(body)
        expected = self._expected_version(body)
        project = self.store.get_project(project_id)
        carries_timeline_id = "timeline_id" in body
        self._reject_canonical_document_write(
            document_id, body.get("kind"), carries_timeline_id=carries_timeline_id,
        )
        self._reject_canonical_document_write(
            body.get("document_id", document_id), body.get("kind"),
            carries_timeline_id=carries_timeline_id,
        )
        row = self.store.conn.execute("SELECT * FROM project_documents WHERE project_id=? AND id=?", (project["id"], document_id)).fetchone()
        if row:
            self._reject_canonical_document_write(row["id"], row["kind"])
        request_hash = hashlib.sha256(canonical_json({"project_id": project["id"], "document_id": document_id, "body": body}).encode()).hexdigest()
        replay = self._command_replay("document.update", document_id, idempotency_key, request_hash, project_id=project["id"])
        if replay is not None:
            return replay
        if not row:
            raise NotFoundError("document not found")
        if int(row["version"]) != expected:
            raise ConflictError("document version conflict", details={"expected": expected, "actual": int(row["version"])})
        kind = str(body.get("kind", row["kind"]))
        content = body.get("content", json.loads(row["content_json"]))
        if not kind:
            raise ValidationError("document kind is required")
        previous_content = json.loads(row["content_json"])
        self._validate_project_document(project["id"], document_id, row["kind"], previous_content)
        self._validate_project_document(project["id"], document_id, kind, content)
        if row["kind"] == TRANSCRIPT_DOCUMENT_KIND or kind == TRANSCRIPT_DOCUMENT_KIND or document_id.startswith(TRANSCRIPT_DOCUMENT_PREFIX):
            if kind != row["kind"] or kind != TRANSCRIPT_DOCUMENT_KIND:
                raise ValidationError("transcript document kind is immutable")
            if "document_id" in body and body["document_id"] != document_id:
                raise ValidationError("transcript document identity is immutable")
            if content["media_id"] != previous_content["media_id"] or content["source_id"] != previous_content["source_id"]:
                raise ValidationError("transcript media_id and source_id are immutable")
        if document_id.startswith(self.PROJECT_PREFERENCE_PREFIX) and body.get("document_id", document_id) != document_id:
            raise ValidationError("project preference document identity is reserved")
        timestamp = now()
        self.store.conn.execute("UPDATE project_documents SET kind=?, content_json=?, version=?, updated_at=? WHERE id=?", (kind, canonical_json(content), expected + 1, timestamp, document_id))
        result = self._document_resource(self.store.conn.execute("SELECT * FROM project_documents WHERE id=?", (document_id,)).fetchone())
        return self._command_record("document.update", document_id, idempotency_key, request_hash, result, project_id=project["id"])

    def _generation_resource(self, row):
        value = dict(row)
        value["generation_id"] = value.pop("id")
        value["metadata"] = json.loads(value.pop("metadata_json"))
        return value

    @_durable_mutation
    def create_generation(self, project_id, body, *, idempotency_key=None):
        raise ConflictError(
            "direct generation publication is disabled; use an admitted GEN D1 settlement effect"
        )
        self._require_object_body(body)
        project = self.store.get_project(project_id)
        generation_id = str(body.get("generation_id") or "")
        if not generation_id:
            raise ValidationError("generation_id is required")
        metadata = body.get("metadata", {})
        if not isinstance(metadata, dict):
            raise ValidationError("generation metadata must be an object")
        generation_type = str(body.get("type", "generation"))
        status = str(body.get("status", "created"))
        source_task_id = body.get("source_task_id")
        request_hash = hashlib.sha256(canonical_json({"project_id": project["id"], "generation_id": generation_id, "source_task_id": source_task_id, "type": generation_type, "status": status, "metadata": metadata}).encode()).hexdigest()
        replay = self._command_replay("generation.create", generation_id, idempotency_key, request_hash, project_id=project["id"])
        if replay is not None:
            return replay
        try:
            self.store.conn.execute("INSERT INTO generations(id, project_id, source_task_id, type, status, metadata_json, version, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)", (generation_id, project["id"], source_task_id, generation_type, status, canonical_json(metadata), now(), now()))
        except sqlite3.IntegrityError as exc:
            raise ConflictError("generation already exists", details={"generation_id": generation_id}) from exc
        result = self._generation_resource(self.store.conn.execute("SELECT * FROM generations WHERE id=?", (generation_id,)).fetchone())
        return self._command_record("generation.create", generation_id, idempotency_key, request_hash, result, project_id=project["id"])

    def list_generations(self, project_id, *, cursor=None, limit=PAGE_DEFAULT_LIMIT,
                         kind=None, model=None, target=None, tag=None):
        project = self.store.get_project(project_id)
        filters, predicates, parameters = _generation_filters(
            kind=kind, model=model, target=target, tag=tag,
        )
        predicates.insert(0, "project_id=?")
        parameters.insert(0, project["id"])
        rows = self.store.conn.execute(
            "SELECT * FROM generations WHERE " + " AND ".join(predicates)
            + " ORDER BY created_at DESC, id ASC", parameters,
        ).fetchall()
        scope = f"generations:{project['id']}"
        if filters:
            scope += ":" + hashlib.sha256(canonical_json(filters).encode()).hexdigest()
        return _page_rows(rows, scope=scope, cursor=cursor, limit=limit,
                          key_fn=lambda row: (str(row["created_at"]), str(row["id"])),
                          resource_fn=self._generation_resource,
                          skip_after=lambda key, after: (
                              key[0] > after[0]
                              or (key[0] == after[0] and key[1] <= after[1])
                          ))

    def get_generation(self, generation_id):
        row = self.store.conn.execute("SELECT * FROM generations WHERE id=?", (generation_id,)).fetchone()
        if not row:
            raise NotFoundError("generation not found")
        return self._generation_resource(row)

    @_durable_mutation
    def create_variant(self, generation_id, body, *, idempotency_key=None):
        raise ConflictError(
            "direct variant publication is disabled; use an admitted GEN D1 settlement effect"
        )
        self._require_object_body(body)
        generation = self.get_generation(generation_id)
        variant_id = str(body.get("variant_id") or "")
        if not variant_id:
            raise ValidationError("variant_id is required")
        metadata = body.get("metadata", {})
        if not isinstance(metadata, dict):
            raise ValidationError("variant metadata must be an object")
        object_id = body.get("object_id")
        if object_id:
            object_id = str(object_id).removeprefix("sha256:")
            if not self.store.conn.execute("SELECT 1 FROM objects WHERE digest=?", (object_id,)).fetchone():
                raise NotFoundError("object not found")
        variant_type = str(body.get("variant_type", "original"))
        request_hash = hashlib.sha256(canonical_json({"generation_id": generation_id, "variant_id": variant_id, "object_id": object_id, "variant_type": variant_type, "metadata": metadata}).encode()).hexdigest()
        replay = self._command_replay("variant.create", variant_id, idempotency_key, request_hash, project_id=generation["project_id"])
        if replay is not None:
            return replay
        try:
            self.store.conn.execute(
                "INSERT INTO generation_variants(id, generation_id, object_id, variant_type, metadata_json, thumbnail_object_id, thumbnail_source_object_id, thumbnail_recipe_version, viewed_at, created_at) VALUES (?, ?, ?, ?, ?, NULL, NULL, NULL, NULL, ?)",
                (variant_id, generation_id, object_id, variant_type, canonical_json(metadata), now()),
            )
        except sqlite3.IntegrityError as exc:
            raise ConflictError("generation variant already exists", details={"variant_id": variant_id}) from exc
        result = self._variant_resource(self.store.conn.execute("SELECT * FROM generation_variants WHERE id=?", (variant_id,)).fetchone())
        return self._command_record("variant.create", variant_id, idempotency_key, request_hash, result, project_id=generation["project_id"])

    @staticmethod
    def _variant_resource(row):
        value = dict(row)
        value["variant_id"] = value.pop("id")
        value["metadata"] = json.loads(value.pop("metadata_json"))
        if value.get("object_id"):
            value["object_id"] = "sha256:" + value["object_id"]
        thumbnail_object_id = value.pop("thumbnail_object_id", None)
        thumbnail_source_object_id = value.pop("thumbnail_source_object_id", None)
        thumbnail_recipe_version = value.pop("thumbnail_recipe_version", None)
        if thumbnail_object_id and thumbnail_source_object_id and thumbnail_recipe_version is not None:
            value["thumbnail"] = {
                "object_id": "sha256:" + str(thumbnail_object_id),
                "source_object_id": "sha256:" + str(thumbnail_source_object_id),
                "recipe_version": int(thumbnail_recipe_version),
            }
        else:
            value["thumbnail"] = None
        return value

    def list_variants(self, generation_id, *, cursor=None, limit=PAGE_DEFAULT_LIMIT):
        self.get_generation(generation_id)
        rows = self.store.conn.execute("SELECT * FROM generation_variants WHERE generation_id=? ORDER BY created_at, id", (generation_id,)).fetchall()
        return _page_rows(rows, scope=f"variants:{generation_id}", cursor=cursor, limit=limit,
                          key_fn=lambda row: (str(row["created_at"]), str(row["id"])),
                          resource_fn=self._variant_resource)

    def get_variant(self, variant_id):
        row = self.store.conn.execute("SELECT * FROM generation_variants WHERE id=?", (variant_id,)).fetchone()
        if not row:
            raise NotFoundError("generation variant not found")
        return self._variant_resource(row)

    @_durable_mutation
    def attach_variant_thumbnail(self, variant_id, body, *, idempotency_key=None):
        """Attach a source-verified managed JPEG poster to one variant."""
        if not idempotency_key:
            raise InvalidRequestError("Idempotency-Key is required for state mutations")
        self._require_object_body(body)
        if set(body) != {"thumbnail_object_id", "source_object_id", "recipe_version"}:
            raise ValidationError(
                "variant thumbnail requires thumbnail_object_id, source_object_id, and recipe_version"
            )
        thumbnail_object_id = body["thumbnail_object_id"]
        source_object_id = body["source_object_id"]
        recipe_version = body["recipe_version"]
        for field, value in (("thumbnail_object_id", thumbnail_object_id), ("source_object_id", source_object_id)):
            if not isinstance(value, str) or not OBJECT_ID_RE.fullmatch(value) or not value.startswith("sha256:"):
                raise ValidationError(f"{field} must be a canonical sha256 object id")
        if isinstance(recipe_version, bool) or recipe_version != 1:
            raise ValidationError("recipe_version must be 1")
        row = self.store.conn.execute(
            "SELECT gv.*, g.project_id FROM generation_variants gv JOIN generations g ON g.id=gv.generation_id WHERE gv.id=?",
            (variant_id,),
        ).fetchone()
        if not row:
            raise NotFoundError("generation variant not found")
        source_digest = source_object_id.removeprefix("sha256:")
        thumbnail_digest = thumbnail_object_id.removeprefix("sha256:")
        if row["object_id"] != source_digest:
            raise ConflictError(
                "variant source changed before thumbnail attachment",
                details={"variant_id": str(variant_id), "expected_source_object_id": "sha256:" + str(row["object_id"]), "actual_source_object_id": source_object_id},
            )
        project_id = str(row["project_id"])
        thumbnail_row = self.store.conn.execute(
            "SELECT media_type FROM objects WHERE digest=?", (thumbnail_digest,)
        ).fetchone()
        if not thumbnail_row:
            raise NotFoundError("thumbnail object not found")
        if str(thumbnail_row["media_type"]).lower() != "image/jpeg":
            raise ConflictError("variant thumbnail object must be image/jpeg")
        if not self.store.conn.execute(
            "SELECT 1 FROM project_objects WHERE project_id=? AND digest=?",
            (project_id, thumbnail_digest),
        ).fetchone():
            raise ConflictError("thumbnail object is outside the variant project")
        request_hash = hashlib.sha256(canonical_json({"variant_id": str(variant_id), **body}).encode()).hexdigest()
        replay = self._command_replay(
            "variant.thumbnail.attach", str(variant_id), idempotency_key, request_hash,
            project_id=project_id,
        )
        if replay is not None:
            return replay
        self.store.conn.execute(
            "UPDATE generation_variants SET thumbnail_object_id=?, thumbnail_source_object_id=?, thumbnail_recipe_version=? WHERE id=? AND object_id=?",
            (thumbnail_digest, source_digest, recipe_version, variant_id, source_digest),
        )
        updated = self.store.conn.execute(
            "SELECT * FROM generation_variants WHERE id=?", (variant_id,)
        ).fetchone()
        return self._command_record(
            "variant.thumbnail.attach", str(variant_id), idempotency_key,
            request_hash, self._variant_resource(updated), project_id=project_id,
        )

    @_durable_mutation
    def mark_variant_viewed(self, variant_id, *, idempotency_key=None):
        """Persist the first lightbox view for one Runtime-owned variant."""
        if not idempotency_key:
            raise InvalidRequestError("Idempotency-Key is required for state mutations")
        row = self.store.conn.execute(
            "SELECT gv.*, g.project_id FROM generation_variants gv JOIN generations g ON g.id=gv.generation_id WHERE gv.id=?",
            (variant_id,),
        ).fetchone()
        if not row:
            raise NotFoundError("generation variant not found")
        project_id = str(row["project_id"])
        request_hash = hashlib.sha256(canonical_json({"variant_id": str(variant_id)}).encode()).hexdigest()
        replay = self._command_replay(
            "variant.view", str(variant_id), idempotency_key, request_hash,
            project_id=project_id,
        )
        if replay is not None:
            return replay
        timestamp = now()
        self.store.conn.execute(
            "UPDATE generation_variants SET viewed_at=COALESCE(viewed_at, ?) WHERE id=?",
            (timestamp, variant_id),
        )
        updated = self.store.conn.execute(
            "SELECT gv.* FROM generation_variants gv WHERE gv.id=?", (variant_id,)
        ).fetchone()
        return self._command_record(
            "variant.view", str(variant_id), idempotency_key,
            request_hash, self._variant_resource(updated), project_id=project_id,
        )

    @_durable_mutation
    def mark_generation_variants_viewed(self, generation_id, *, idempotency_key=None):
        """Persist first-view timestamps for every variant in a generation."""
        if not idempotency_key:
            raise InvalidRequestError("Idempotency-Key is required for state mutations")
        generation = self.store.conn.execute(
            "SELECT id, project_id FROM generations WHERE id=?", (generation_id,)
        ).fetchone()
        if not generation:
            raise NotFoundError("generation not found")
        project_id = str(generation["project_id"])
        request_hash = hashlib.sha256(canonical_json({"generation_id": str(generation_id)}).encode()).hexdigest()
        replay = self._command_replay(
            "generation.variants.view", str(generation_id), idempotency_key,
            request_hash, project_id=project_id,
        )
        if replay is not None:
            return replay
        timestamp = now()
        self.store.conn.execute(
            "UPDATE generation_variants SET viewed_at=COALESCE(viewed_at, ?) WHERE generation_id=?",
            (timestamp, generation_id),
        )
        rows = self.store.conn.execute(
            "SELECT * FROM generation_variants WHERE generation_id=? ORDER BY created_at, id",
            (generation_id,),
        ).fetchall()
        result = {
            "generation_id": str(generation_id),
            "viewed_at": timestamp,
            "variants": [self._variant_resource(row) for row in rows],
        }
        return self._command_record(
            "generation.variants.view", str(generation_id), idempotency_key,
            request_hash, result, project_id=project_id,
        )

    def get_reference(self, reference_id):
        row = self.store.conn.execute("SELECT * FROM timeline_references WHERE id=?", (reference_id,)).fetchone()
        if not row: raise NotFoundError("reference not found")
        return self._reference_resource(row)

    def update_shot(self, shot_id, body, *, idempotency_key=None): return self._update_shot_state(shot_id, body, idempotency_key=idempotency_key)
    def archive_shot(self, shot_id, body, *, idempotency_key=None): return self._update_shot_state(shot_id, body, archived=True, idempotency_key=idempotency_key)
    def recover_shot(self, shot_id, body, *, idempotency_key=None): return self._update_shot_state(shot_id, body, archived=False, idempotency_key=idempotency_key)

    @_verified_mutation
    def _update_reference_state(self, reference_id, body, *, archived=None, idempotency_key=None):
        self._require_timeline_command()

    def update_reference(self, reference_id, body, *, idempotency_key=None): return self._update_reference_state(reference_id, body, idempotency_key=idempotency_key)
    def archive_reference(self, reference_id, body, *, idempotency_key=None): return self._update_reference_state(reference_id, body, archived=True, idempotency_key=idempotency_key)
    def recover_reference(self, reference_id, body, *, idempotency_key=None): return self._update_reference_state(reference_id, body, archived=False, idempotency_key=idempotency_key)

    def stage_object(self, chunks, *, expected_digest=None):
        return self.cas.stage(chunks, self.store.staging_root,
                              max_bytes=self.max_object_bytes, expected_digest=expected_digest)

    def ingest(self, project, data, *, media_type="application/octet-stream", original_name=None,
               expected_digest=None, idempotency_key=None):
        return self._ingest_transfer(project, data, media_type=media_type, original_name=original_name,
                                     expected_digest=expected_digest, idempotency_key=idempotency_key)

    def _ingest_transfer(self, project, data, *, media_type, original_name, expected_digest,
                         idempotency_key, identity=None, upload_binding=None):
        idempotency_key = require_idempotency_key(idempotency_key)
        owned_stage = not isinstance(data, StagedObject)
        if owned_stage:
            if not isinstance(data, (bytes, bytearray, memoryview)):
                raise InvalidRequestError("object body must be bytes or a runtime staged transfer")
            if len(data) > self.max_object_bytes:
                raise ValidationError(f"object exceeds {self.max_object_bytes} byte limit")
            data = self.stage_object((data,), expected_digest=expected_digest)
        try:
            if data.size > self.max_object_bytes:
                raise ValidationError(f"object exceeds {self.max_object_bytes} byte limit")
            expected = (expected_digest or "").removeprefix("sha256:") or None
            if expected and expected != data.digest:
                raise ConflictError("content hash does not match expected digest")
            # The store mutex is the only publication/journal/receipt serializer.
            # Binary handlers verify before acquiring it; pinned stat tokens fence
            # reuse. A second upload lock would invert callers' existing store lock
            # (for example create_timeline_view -> ingest).
            existing = self.cas.existing_identity(data.digest, data.size)
            with self.store._mutex:
                self._assert_mutation_admitted()
                project_row = self.store.get_project(project) if project is not None else None
                project_id = project_row["id"] if project_row else "unscoped"
                aggregate_id = project_id if project_row else "objects"
                binding = dict(upload_binding) if upload_binding is not None else None
                request = {"content_digest": data.digest, "media_type": media_type,
                           "original_name": original_name, "expected_digest": expected}
                if project_row:
                    request["project_id"] = project_id
                if binding is not None:
                    request["publication_binding"] = binding
                    self.store.assert_attempt_not_abandoned(binding.get("attempt_id"))
                request_hash = hashlib.sha256(canonical_json(request).encode()).hexdigest()
                replay = self._command_replay("object.ingest", aggregate_id, idempotency_key,
                                              request_hash, project_id=project_id)
                if replay is not None:
                    return replay
                if binding is not None:
                    self._validate_generic_output_binding(binding, identity=identity,
                        digest=data.digest, size=data.size, media_type=media_type,
                        original_name=original_name, idempotency_key=idempotency_key)
                if existing is None:
                    self._begin_cas_publication_journal("ingest", [{"digest": data.digest}], project_id=project_id)
                try:
                    self.cas.publish(data, existing_identity=existing)
                    data.discard()  # Drop the staging link before receipt/stat proofs.
                    with self.cas.open(data.digest) as published:
                        self._verified_cas_objects[data.digest] = file_identity(os.fstat(published.fileno()))
                    with self.store._transaction():
                        timestamp = now()
                        self.store.conn.execute(
                            "INSERT OR IGNORE INTO objects(digest, size, media_type, original_name, created_at) VALUES (?, ?, ?, ?, ?)",
                            (data.digest, data.size, media_type, original_name, timestamp))
                        if project_row:
                            self.store.conn.execute(
                                "INSERT OR IGNORE INTO project_objects(project_id, digest, relation, created_at) VALUES (?, ?, 'managed', ?)",
                                (project_id, data.digest, timestamp))
                        row = dict(self.store.conn.execute("SELECT * FROM objects WHERE digest=?", (data.digest,)).fetchone())
                        result = self._object_resource(row)
                        if project_row:
                            result["relation"] = "managed"
                        result = self._command_record("object.ingest", aggregate_id, idempotency_key,
                                                      request_hash, result, project_id=project_id)
                except BaseException:
                    self._recover_cas_publication_journals()
                    raise
                self._recover_cas_publication_journals()
                return result
        finally:
            if owned_stage:
                data.discard()

    @staticmethod
    def _media_import_operation_id(project_id, idempotency_key):
        # The caller persists this key before sending bytes, so it remains a
        # usable recovery identity even when the first acknowledgement is
        # lost. Project scoping is carried by every ledger lookup below.
        _ = project_id
        return str(idempotency_key)

    @staticmethod
    def _media_import_aggregate_id(project_id, operation_id):
        return f"{project_id}:{operation_id}"

    @staticmethod
    def _media_import_subkey(operation_id, purpose):
        return "media-import-" + purpose + "-" + hashlib.sha256(
            str(operation_id).encode()
        ).hexdigest()

    @staticmethod
    def _media_import_optional_integer(value, field):
        if value is None:
            return None
        if isinstance(value, str) and value.isdecimal():
            value = int(value)
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise ValidationError(f"{field} must be a positive integer")
        return value

    @staticmethod
    def _media_import_optional_duration(value):
        if value is None:
            return None
        try:
            normalized = float(value)
        except (TypeError, ValueError) as exc:
            raise ValidationError("duration_seconds must be a positive finite number") from exc
        if not math.isfinite(normalized) or normalized <= 0:
            raise ValidationError("duration_seconds must be a positive finite number")
        return normalized

    def _media_import_request(self, project, data, *, media_type, original_name,
                              expected_digest, actor_id, width, height,
                              duration_seconds, idempotency_key):
        idempotency_key = require_idempotency_key(idempotency_key)
        if not isinstance(data, StagedObject):
            raise InvalidRequestError("media import body must be a runtime staged transfer")
        if data.size > self.max_object_bytes:
            raise ValidationError(f"object exceeds {self.max_object_bytes} byte limit")
        project_row = self.store.get_project(project)
        if not isinstance(media_type, str) or not media_type or len(media_type) > 255:
            raise ValidationError("media import Content-Type is invalid")
        content_type = media_type.lower().split("/", 1)[0]
        if content_type not in {"image", "video", "audio"} or "/" not in media_type:
            raise ValidationError("media import Content-Type must be image/*, video/* or audio/*")
        if original_name is not None:
            original_name = _canonical_managed_output_filename(original_name)
        if not isinstance(actor_id, str) or not actor_id:
            raise ValidationError("media import actor is required")
        width = self._media_import_optional_integer(width, "width")
        height = self._media_import_optional_integer(height, "height")
        duration_seconds = self._media_import_optional_duration(duration_seconds)
        if content_type == "audio" and (width is not None or height is not None):
            raise ValidationError("audio imports must not declare visual dimensions")
        if content_type == "image" and duration_seconds is not None:
            raise ValidationError("image imports must not declare duration_seconds")
        expected = (expected_digest or "").removeprefix("sha256:") or None
        digest = data.digest
        operation_id = self._media_import_operation_id(project_row["id"], idempotency_key)
        request = {
            "project_id": project_row["id"],
            "content_digest": digest,
            "media_type": media_type,
            "original_name": original_name,
            "expected_digest": expected,
            "actor_id": actor_id,
            "width": width,
            "height": height,
            "duration_seconds": duration_seconds,
        }
        return {
            "data": data,
            "project": project_row,
            "content_type": content_type,
            "digest": digest,
            "operation_id": operation_id,
            "idempotency_key": idempotency_key,
            "request": request,
            "request_hash": hashlib.sha256(canonical_json(request).encode()).hexdigest(),
        }

    def _claim_media_import_task(self, task_id):
        """Claim one exact private import task through the normal lease fence."""
        epoch = self.store._current_runtime_epoch()
        self.store.upsert_executor(
            MEDIA_IMPORT_EXECUTOR,
            [{
                "capability_id": MEDIA_IMPORT_CAPABILITY,
                "definition_digest": MEDIA_IMPORT_CAPABILITY_DIGEST,
                "status": "ready",
                "required_resource_keys": [],
                "estimated_scratch_bytes": 0,
                "estimated_output_bytes": 0,
            }],
            max_concurrency=1,
            runtime_epoch=epoch,
        )
        lease_id = new_id()
        claimed = self.store._claim_task(
            task_id, MEDIA_IMPORT_EXECUTOR, lease_id,
            runtime_epoch=epoch, _transactional=False,
        )
        task = claimed["task"]
        if task.get("status") != "running" or task.get("lease_token") != lease_id:
            raise ConflictError(
                "runtime host could not claim media import task",
                details={"task_id": task_id, "status": task.get("status")},
            )
        attempt_id = new_id()
        fence = int(task["lease_fence"])
        expires = task["lease_expires_at"]
        self.store.conn.execute(
            "INSERT INTO attempts(id, task_id, lease_id, fence, executor_id, lease_expires_at, settled, runtime_epoch) VALUES (?, ?, ?, ?, ?, ?, 0, ?)",
            (attempt_id, task_id, lease_id, fence, MEDIA_IMPORT_EXECUTOR, expires, epoch),
        )
        self.store.conn.execute(
            "UPDATE tasks SET attempt_id=? WHERE id=?", (attempt_id, task_id)
        )
        return {
            "attempt_id": attempt_id,
            "lease_id": lease_id,
            "fence": fence,
            "runtime_epoch": epoch,
        }

    @_durable_mutation
    def _settle_media_import_catalog(self, prepared, object_resource, verified_objects):
        """Atomically settle the host-owned task and publish one catalog pair."""
        project = prepared["project"]
        operation_id = prepared["operation_id"]
        idempotency_key = prepared["idempotency_key"]
        replay = self._command_replay(
            "media.import",
            self._media_import_aggregate_id(project["id"], operation_id),
            idempotency_key,
            prepared["request_hash"], project_id=project["id"],
        )
        if replay is not None:
            return replay

        object_id = object_resource["digest"]
        details = {
            "filename": prepared["request"]["original_name"],
            "mime_type": prepared["request"]["media_type"],
            "size": int(object_resource["size"]),
            "width": prepared["request"]["width"],
            "height": prepared["request"]["height"],
            "duration_seconds": prepared["request"]["duration_seconds"],
        }
        provenance = {
            "source": "external_upload",
            "origin": "imported",
            "actor_id": prepared["request"]["actor_id"],
            "import_operation_id": operation_id,
        }
        effect = {
            "effect_type": "generation.create_with_variant",
            "target_id": project["id"],
            "payload": {
                "generation_type": prepared["content_type"],
                "metadata": {
                    "gen": {"kind": prepared["content_type"], "origin": "imported"},
                    "provenance": provenance,
                    "params": {"content_type": prepared["content_type"], **details},
                },
                "variant_type": "original",
                "output_name": "original",
                "output_ordinal": 0,
                "primary_policy": "preserve",
            },
        }
        task = self.create_task({
            "capability_id": MEDIA_IMPORT_CAPABILITY,
            "capability_digest": MEDIA_IMPORT_CAPABILITY_DIGEST,
            "project": project["id"],
            "input_object_ids": [object_id],
            "settlement_effect": effect,
            "spec": {
                "operation": "media_import",
                "import_operation_id": operation_id,
            },
            "idempotency_key": self._media_import_subkey(operation_id, "task"),
        }, _host_owned=True)
        task_id = task["task"]["id"]
        attempt = self._claim_media_import_task(task_id)
        output = {
            "name": "original",
            "filename": prepared["request"]["original_name"] or "original",
            "kind": "object",
            "digest": object_id,
            "media_type": prepared["request"]["media_type"],
            "size": int(object_resource["size"]),
            "ordinal": 0,
            "role": "primary",
            "is_primary": True,
            "producer": {"kind": "runtime_host_import"},
            "provenance": provenance,
        }
        if prepared["request"]["duration_seconds"] is not None:
            output["duration_seconds"] = prepared["request"]["duration_seconds"]
        settled = self.settle_attempt(
            attempt["attempt_id"],
            {
                "lease_id": attempt["lease_id"],
                "fence": attempt["fence"],
                "runtime_epoch": attempt["runtime_epoch"],
                "outputs": [output],
                "effect": effect,
            },
            idempotency_key=self._media_import_subkey(operation_id, "settle"),
            _verified_objects=verified_objects,
        )
        generation_variant = settled["data"]["result"]["generation_variant"]
        result = {
            "provider": "runtime",
            "project": project["id"],
            "import_operation_id": operation_id,
            "status": "completed",
            "task_id": task_id,
            "generation_id": generation_variant["generation_id"],
            "variant_id": generation_variant["variant_id"],
            "asset_id": object_id,
            "entry": {
                "object_id": object_id,
                "media_type": prepared["request"]["media_type"],
                "size": int(object_resource["size"]),
                "filename": prepared["request"]["original_name"],
            },
            "provenance": provenance,
            "actor_id": prepared["request"]["actor_id"],
            **details,
        }
        return self._command_record(
            "media.import",
            self._media_import_aggregate_id(project["id"], operation_id),
            idempotency_key,
            prepared["request_hash"], result, project_id=project["id"],
        )

    @staticmethod
    def _validate_media_file(staged, media_type):
        """Bounded local decode check; forced demuxers cannot open playlists/URLs."""
        demuxers = {
            "image/png": "png_pipe", "image/jpeg": "jpeg_pipe", "image/webp": "webp_pipe",
            "image/gif": "gif", "image/bmp": "bmp_pipe", "image/tiff": "tiff_pipe",
            "image/avif": "mov", "video/mp4": "mov", "video/quicktime": "mov",
            "video/webm": "matroska", "video/x-matroska": "matroska", "video/x-msvideo": "avi",
            "video/mpeg": "mpeg", "video/mp2t": "mpegts", "audio/wav": "wav",
            "audio/x-wav": "wav", "audio/mpeg": "mp3", "audio/ogg": "ogg",
            "audio/flac": "flac", "audio/aac": "aac", "audio/mp4": "mov", "audio/webm": "matroska",
        }
        normalized = media_type.lower().split(";", 1)[0].strip()
        demuxer = demuxers.get(normalized)
        if demuxer is None:
            raise ValidationError("media import type has no supported local decoder")
        common = ["-v", "error", "-max_alloc", "67108864", "-protocol_whitelist", "file,pipe",
                  "-probesize", "8388608", "-analyzeduration", "5000000", "-f", demuxer]
        try:
            kind = "audio" if normalized.startswith("audio/") else "video"
            probe = subprocess.run(["ffprobe", *common, "-select_streams", "a:0" if kind == "audio" else "v:0", "-show_entries",
                "stream=codec_type,codec_name,width,height,duration:format=duration", "-of", "json", str(staged.path)],
                stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=30, check=True)
            info = json.loads(probe.stdout)
            streams = [item for item in info.get("streams", []) if item.get("codec_type") == kind]
            if not streams or any(int(item.get("width", 0)) * int(item.get("height", 0)) > 67108864 for item in streams):
                raise ValidationError("media import bytes do not match declared media type or dimensions exceed decoder limit")
            # Decode at least one frame/sample, beyond a merely recognizable header.
            decoded = subprocess.run(["ffmpeg", *common, "-threads", "1", "-i", str(staged.path),
                "-map", "0:a:0" if kind == "audio" else "0:v:0", "-frames:a" if kind == "audio" else "-frames:v", "1",
                "-threads", "1", "-f", "framehash", "-"], stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=30, check=True)
            if not any(line and not line.startswith(b"#") for line in decoded.stdout.splitlines()):
                raise ValidationError("media import has no decodable media frames")
        except (OSError, ValueError, subprocess.SubprocessError) as exc:
            raise ValidationError("media import is not locally decodable (ffprobe and ffmpeg are required)") from exc

    def import_media(self, project, data, *, media_type, original_name=None,
                     expected_digest=None, actor_id, width=None, height=None,
                     duration_seconds=None, idempotency_key=None):
        """Transfer/decode outside SQLite, then reuse fenced host settlement."""
        owned_stage = not isinstance(data, StagedObject)
        if owned_stage:
            if not isinstance(data, (bytes, bytearray, memoryview)):
                raise InvalidRequestError("media import body must be bytes")
            if len(data) > self.max_object_bytes:
                raise ValidationError(f"object exceeds {self.max_object_bytes} byte limit")
            data = self.stage_object((data,), expected_digest=expected_digest)
        try:
            with self.store._mutex:
                self._assert_mutation_admitted()
                prepared = self._media_import_request(
                    project, data, media_type=media_type, original_name=original_name,
                    expected_digest=expected_digest, actor_id=actor_id, width=width, height=height,
                    duration_seconds=duration_seconds, idempotency_key=idempotency_key)
            self._validate_media_file(data, media_type)
            ingested = self.ingest(prepared["project"]["id"], data,
                media_type=prepared["request"]["media_type"], original_name=prepared["request"]["original_name"],
                expected_digest=prepared["request"]["expected_digest"],
                idempotency_key=self._media_import_subkey(prepared["operation_id"], "object"))
            verified = self.cas.existing_identity(data.digest, data.size)
            if verified is None:
                raise ConflictError("imported CAS object is missing")
            return self._settle_media_import_catalog(prepared, ingested["data"], {data.digest: verified})
        finally:
            if owned_stage:
                data.discard()

    def get_media_import(self, project, operation_id):
        """Recover a completed import or its durable pre-settlement ingest."""
        if not isinstance(operation_id, str) or not IDEMPOTENCY_KEY_RE.fullmatch(operation_id):
            raise NotFoundError("media import operation not found")
        project_row = self.store.get_project(project)
        completed = self.store.conn.execute(
            "SELECT result_json FROM command_idempotency WHERE command_kind='media.import' AND aggregate_id=?",
            (self._media_import_aggregate_id(project_row["id"], operation_id),),
        ).fetchone()
        if completed:
            result = json.loads(completed["result_json"])
            if result.get("project") != project_row["id"]:
                raise NotFoundError("media import operation not found")
            return result
        pending = self.store.conn.execute(
            "SELECT result_json FROM command_idempotency WHERE command_kind='object.ingest' AND aggregate_id=? AND idempotency_key=?",
            (
                project_row["id"],
                self._media_import_subkey(operation_id, "object"),
            ),
        ).fetchone()
        if not pending:
            raise NotFoundError("media import operation not found")
        object_resource = json.loads(pending["result_json"])
        return {
            "provider": "runtime",
            "project": project_row["id"],
            "import_operation_id": operation_id,
            "status": "pending",
            "task_id": None,
            "generation_id": None,
            "variant_id": None,
            "asset_id": object_resource["digest"],
            "entry": {
                "object_id": object_resource["digest"],
                "media_type": object_resource["media_type"],
                "size": int(object_resource["size"]),
                "filename": object_resource.get("filename"),
            },
        }

    @staticmethod
    def _generic_output_idempotency_key(binding):
        return "output-" + hashlib.sha256(canonical_json(binding).encode()).hexdigest()

    def _validate_generic_output_binding(self, binding, *, identity, digest, size, media_type, original_name, idempotency_key):
        """Validate the explicit attempt identity carried by an output upload."""
        if not isinstance(binding, dict):
            raise ValidationError("output upload binding must be an object")
        required = {
            "project_id", "run_id", "task_id", "attempt_id", "executor_id",
            "lease_id", "fence", "runtime_epoch", "output_key", "output_port",
            "filename", "digest", "size", "media_type",
        }
        if set(binding) != required:
            raise ValidationError("output upload binding has unsupported or missing fields")
        if binding["project_id"] is not None and (not isinstance(binding["project_id"], str) or not binding["project_id"]):
            raise ValidationError("output upload binding project_id is invalid")
        for field in ("run_id", "task_id", "attempt_id", "executor_id", "lease_id", "output_key", "output_port", "filename", "media_type"):
            if not isinstance(binding[field], str) or not binding[field]:
                raise ValidationError(f"output upload binding {field} is invalid")
        for field in ("fence", "runtime_epoch", "size"):
            if isinstance(binding[field], bool) or not isinstance(binding[field], int) or binding[field] < 0:
                raise ValidationError(f"output upload binding {field} is invalid")
        if binding["runtime_epoch"] < 1 or binding["size"] > OBJECT_MAX_BYTES:
            raise ValidationError("output upload binding numeric fields are invalid")
        if binding["digest"] != "sha256:" + digest or binding["size"] != int(size) or binding["media_type"] != media_type:
            raise ConflictError("output upload binding does not match object bytes")
        if binding["filename"] != original_name:
            raise ConflictError("output upload binding does not match object filename")
        if idempotency_key != self._generic_output_idempotency_key(binding):
            raise ConflictError("output upload idempotency key is not bound to its provenance")
        if identity is not None and identity.get("actor") != binding["executor_id"]:
            raise AuthorizationError("output upload worker is not bound to the upload executor")
        row = self.store.conn.execute(
            "SELECT a.id AS attempt_id, a.task_id, a.executor_id, a.lease_id, a.fence, a.runtime_epoch, a.settled, "
            "t.run_id, t.status, t.attempt_id AS current_attempt_id, t.executor_id AS task_executor_id, "
            "t.lease_token, t.lease_fence, t.runtime_epoch AS task_runtime_epoch, r.project_id "
            "FROM attempts AS a JOIN tasks AS t ON t.id=a.task_id JOIN runs AS r ON r.id=t.run_id "
            "WHERE a.id=?",
            (binding["attempt_id"],),
        ).fetchone()
        if not row or row["settled"] != 0 or row["status"] != "running" or row["current_attempt_id"] != row["attempt_id"]:
            raise LeaseError("output upload attempt is stale")
        if (
            row["task_id"] != binding["task_id"]
            or row["run_id"] != binding["run_id"]
            or row["project_id"] != binding["project_id"]
            or row["executor_id"] != binding["executor_id"]
            or row["task_executor_id"] != binding["executor_id"]
            or row["lease_id"] != binding["lease_id"]
            or int(row["fence"]) != int(binding["fence"])
            or int(row["lease_fence"]) != int(binding["fence"])
            or int(row["runtime_epoch"]) != int(binding["runtime_epoch"])
            or int(row["task_runtime_epoch"]) != int(binding["runtime_epoch"])
            or int(row["runtime_epoch"]) != int(self.store._current_runtime_epoch())
        ):
            raise LeaseError("output upload provenance does not match the live attempt")

    @staticmethod
    def _generic_output_request_hash(digest, media_type, original_name, expected_digest, binding):
        request = {
            "content_digest": digest,
            "media_type": media_type,
            "original_name": original_name,
            "expected_digest": expected_digest,
        }
        if binding is not None:
            request["publication_binding"] = binding
        return hashlib.sha256(canonical_json(request).encode()).hexdigest()

    def ingest_object(self, data, *, media_type="application/octet-stream", original_name=None,
                      expected_digest=None, idempotency_key=None, identity=None, upload_binding=None):
        return self._ingest_transfer(None, data, media_type=media_type, original_name=original_name,
            expected_digest=expected_digest, idempotency_key=idempotency_key,
            identity=identity, upload_binding=upload_binding)

    def _discard_published_digest(self, digest):
        """Remove a newly published CAS file after a failed metadata commit."""
        try:
            self._unlink_cas_destination(digest)
        except (FileNotFoundError, OSError, ConflictError):
            # A failed cleanup is reconciled from the publication journal.
            pass

    def _object_resource(self, row):
        return {"object_id": "sha256:" + row["digest"], "digest": "sha256:" + row["digest"], "media_type": row["media_type"], "size": int(row["size"]), "version": 1, "created_at": row["created_at"], **({"filename": row["original_name"]} if row.get("original_name") else {})}

    def object(self, digest):
        digest = digest.removeprefix("sha256:")
        row = self.store.conn.execute("SELECT * FROM objects WHERE digest=?", (digest,)).fetchone()
        if not row:
            from .errors import NotFoundError
            raise NotFoundError("object not found")
        return dict(row), self.cas.read(digest)

    @staticmethod
    def _open_pack_file(root_fd, item):
        """Walk only a manifest-selected file, retaining every parent handle."""
        directory_fd = os.dup(root_fd)
        file_fd = None
        try:
            parts = item["disk"].split("/")
            for part in parts[:-1]:
                next_fd = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=directory_fd)
                os.close(directory_fd)
                directory_fd = next_fd
            file_fd = os.open(parts[-1], os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW, dir_fd=directory_fd)
            RuntimeService._verify_open_file(file_fd, item["sha256"], item["size"], label=f'pack asset {item["path"]}')
            stream = os.fdopen(file_fd, "rb")
            file_fd = None
            stream.seek(0)
            return stream
        finally:
            if file_fd is not None:
                os.close(file_fd)
            os.close(directory_fd)

    def _pack_asset(self, record, path, *, verify_all=False, retained_fd=None):
        root_fd = None
        entry_stream = None
        try:
            root_fd = (os.dup(retained_fd) if retained_fd is not None
                       else _open_directory_chain(record["root"]))
            held = os.fstat(root_fd)
            if "rootIdentity" in record and record["rootIdentity"] != (held.st_dev, held.st_ino):
                raise ConflictError("installed pack folder changed after admission; retry against the committed folder")
            entry_stream = self._open_pack_file(root_fd, record["files"]["index.js"])
            prelude = f'/* astrid-graph-index-sha256:{record["artifactManifest"]["graphIndexDigest"]} */\n'.encode()
            if entry_stream.read(len(prelude)) != prelude:
                raise ConflictError("pack entry does not commit the admitted graph index")
            if verify_all:
                for name, item in record["files"].items():
                    if name != "index.js":
                        self._open_pack_file(root_fd, item).close()
            if path == "index.js":
                entry_stream.seek(0)
                result, entry_stream = entry_stream, None
                return result
            return self._open_pack_file(root_fd, record["files"][path])
        except FileNotFoundError as exc:
            raise ConflictError("installed pack artifact bytes are missing; reinstall the admitted bundle", details={"packId": record["packId"], "path": path}) from exc
        except OSError as exc:
            raise ConflictError("installed pack artifact must be an accessible regular file in its admitted folder", details={"packId": record["packId"], "path": path}) from exc
        finally:
            if entry_stream is not None:
                entry_stream.close()
            if root_fd is not None:
                os.close(root_fd)

    def pack_inventory(self):
        """Expose only committed, enabled browser admissions, with no roots."""
        revision, records = read_pack_admissions(self._pack_admissions)
        self._prune_pack_leases(records)
        packs = []
        for record in records:
            # Verify exactly the admitted file set before advertising it.
            # Asset reads also verify the full admitted set; no source scan/cache.
            self._pack_asset(record, "index.js", verify_all=True).close()
            item = {key: record[key] for key in ("packId", "sourceDigest", "digest", "artifactManifestDigest", "enabled")}
            item["url"] = f'/api/runtime/packs/assets/{record["packId"]}/{record["digest"]}/index.js'
            item["artifactManifest"] = record["artifactManifest"]
            packs.append(item)
        return {"version": 1, "revision": revision, "packs": packs}

    def _prune_pack_leases(self, records):
        """Disable/uninstall revokes retention, including not-yet-imported chunks."""
        enabled = {record["packId"] for record in records}
        with self.store._mutex:
            for token, (record, fd) in list(self._pack_leases.items()):
                if record["packId"] not in enabled:
                    os.close(fd)
                    del self._pack_leases[token]

    def acquire_pack_lease(self, pack_id, digest):
        """Only a current admission grants a lease; retained revisions cannot."""
        if not isinstance(pack_id, str) or not PACK_ID_RE.fullmatch(pack_id):
            raise ValidationError("packId must identify one installed pack")
        if not isinstance(digest, str) or not PACK_DIGEST_RE.fullmatch(digest):
            raise ValidationError("pack digest must be a lowercase SHA-256")
        _revision, records = read_pack_admissions(self._pack_admissions, pack_id=pack_id)
        record = next((r for r in records if r["packId"] == pack_id and r["digest"] == digest), None)
        if record is None:
            raise NotFoundError("only an installed admitted revision can acquire a lease")
        fd = _open_directory_chain(record["root"])
        try:
            self._pack_asset(record, "index.js", verify_all=True, retained_fd=fd).close()
            token = secrets.token_hex(32)
            with self.store._mutex:
                self._pack_leases[token] = (record, fd)
            fd = None
            return {"version": 1, "lease": token}
        finally:
            if fd is not None:
                os.close(fd)

    def release_pack_lease(self, token):
        if not isinstance(token, str) or not PACK_DIGEST_RE.fullmatch(token):
            raise ValidationError("pack lease must be a lowercase SHA-256 token")
        with self.store._mutex:
            retained = self._pack_leases.pop(token, None)
            if retained is not None:
                os.close(retained[1])
        return {"version": 1, "released": True}

    def open_pack_asset(self, pack_id, digest, path):
        """Serve only listed bytes from an installed, enabled admitted bundle."""
        if not isinstance(pack_id, str) or not PACK_ID_RE.fullmatch(pack_id):
            raise ValidationError("pack asset packId is invalid")
        if not isinstance(digest, str) or not PACK_DIGEST_RE.fullmatch(digest):
            raise ValidationError("pack asset bundle digest must be a full lowercase SHA-256")
        pack_asset_path(path)
        _revision, records = read_pack_admissions(self._pack_admissions, pack_id=pack_id)
        record = next((item for item in records if item["packId"] == pack_id and item["digest"] == digest), None)
        # Presence still comes from the current installed authority. A lease only
        # retains bytes of a revision admitted before a committed replacement.
        retained_fd = None
        with self.store._mutex:
            if not records:
                for token, (old, fd) in list(self._pack_leases.items()):
                    if old["packId"] == pack_id:
                        os.close(fd)
                        del self._pack_leases[token]
            if record is None and records:
                for old, fd in self._pack_leases.values():
                    if old["packId"] == pack_id and old["digest"] == digest:
                        record, retained_fd = old, os.dup(fd)
                        break
        if record is None:
            raise NotFoundError("pack bundle is not installed and admitted")
        item = record["files"].get(path)
        try:
            if item is None:
                raise NotFoundError("pack asset is not listed in the admitted manifest")
            stream = self._pack_asset(record, path, verify_all=True, retained_fd=retained_fd)
            return {"digest": item["sha256"], "size": item["size"], "media_type": item["mime"]}, stream
        finally:
            if retained_fd is not None:
                os.close(retained_fd)

    def open_object(self, digest):
        normalized = str(digest).removeprefix("sha256:")
        with self.store._mutex:
            row = self.store.conn.execute("SELECT * FROM objects WHERE digest=?", (normalized,)).fetchone()
            if not row:
                raise NotFoundError("object not found")
            metadata = dict(row)
            stream = self.cas.open(normalized)
        try:
            value = os.fstat(stream.fileno())
            if value.st_size != int(metadata["size"]):
                raise ConflictError("CAS object size does not match metadata")
            token = file_identity(value)
            # Verify once per immutable file identity, including after restart.
            # Repeated byte-range seeks do not scan the entire large object.
            if self._verified_cas_objects.get(normalized) != token:
                verified = self._verify_open_file(stream.fileno(), normalized, int(metadata["size"]), label="CAS object")
                self._verified_cas_objects[normalized] = file_identity(verified)
            stream.seek(0)
            return metadata, stream
        except BaseException:
            stream.close()
            raise

    def object_location(self, project, digest):
        """Verify project-owned bytes and return their current local CAS path.

        This separate local-host lookup is not a portable output receipt.
        Verification describes the file at lookup time, not a path lease.
        """
        with self.store._mutex:
            project_id = self.store.get_project(project)["id"]
            match = OBJECT_ID_RE.fullmatch(str(digest))
            if not match:
                raise ValidationError("object_id must be a canonical SHA-256 object id")
            normalized = match.group(1)
            row = self.store.conn.execute(
                "SELECT o.* FROM objects o JOIN project_objects po ON po.digest=o.digest "
                "WHERE o.digest=? AND po.project_id=? AND po.relation='managed'",
                (normalized, project_id),
            ).fetchone()
            if not row:
                raise NotFoundError("object is not owned by project")
        root_fd = prefix_fd = file_fd = None
        try:
            root_fd, prefix_fd = self._cas_prefix_fds(normalized, create=False)
            file_fd = os.open(
                normalized[2:], os.O_RDONLY | os.O_NONBLOCK | getattr(os, "O_NOFOLLOW", 0),
                dir_fd=prefix_fd,
            )
            self._verify_open_file(file_fd, normalized, int(row["size"]), label="canonical CAS object")
        except FileNotFoundError as exc:
            raise NotFoundError("canonical object bytes are missing", details={"object_id": digest}) from exc
        except OSError as exc:
            raise ConflictError("canonical CAS object is not a regular accessible file") from exc
        finally:
            for fd in (file_fd, prefix_fd, root_fd):
                if fd is not None:
                    os.close(fd)
        return {
            "object_id": "sha256:" + normalized, "digest": "sha256:" + normalized,
            "size": int(row["size"]), "media_type": row["media_type"],
            "filename": row["original_name"] or None,
            "local_path": str(self.cas.path_for(normalized)),
            "storage": "runtime_cas", "verified": True,
        }

    def objects(self, project):
        return self.store.list_project_objects(project)

    def list_project_objects(self, project, *, cursor=None, limit=PAGE_DEFAULT_LIMIT,
                             kind=None, model=None, target=None, tag=None):
        project_id = self.store.get_project(project)["id"]
        filters, predicates, parameters = _generation_filters(
            kind=kind, model=model, target=target, tag=tag,
        )
        scope = f"objects:{project_id}"
        if filters:
            # All predicates belong to ONE generation in the object's project.
            # Existence checks avoid multiplying objects by variants/generations.
            # MIN retains one deterministic relation if a promoted ref also exists.
            rows = [dict(row) for row in self.store.conn.execute(
                "SELECT o.*, MIN(po.relation) AS relation FROM objects o "
                "JOIN project_objects po ON po.digest=o.digest WHERE po.project_id=? "
                "AND EXISTS (SELECT 1 FROM generations WHERE project_id=po.project_id AND "
                + " AND ".join(predicates)
                + " AND EXISTS (SELECT 1 FROM generation_variants "
                "WHERE generation_id=generations.id AND object_id=o.digest)) "
                "GROUP BY o.digest ORDER BY o.created_at, o.digest",
                [project_id, *parameters],
            ).fetchall()]
            scope += ":" + hashlib.sha256(canonical_json(filters).encode()).hexdigest()
        else:
            rows = self.store.list_project_objects(project)
        return _page_rows(rows, scope=scope, cursor=cursor, limit=limit,
                          key_fn=lambda row: (str(row["created_at"]), str(row["digest"])),
                          resource_fn=lambda row: self._object_resource(row) | {"relation": row["relation"]})

    @_durable_mutation
    def create_media_relation(self, project, body, *, idempotency_key=None):
        self._require_object_body(body)
        project_id = self.store.get_project(project)["id"]
        allowed = {"derived_from", "variant_of", "uses_as_input", "mask_for", "audio_for"}
        kind = str(body.get("kind") or "")
        if kind not in allowed: raise ValidationError("unsupported media relation kind")
        source = str(body.get("from_object_id") or "").removeprefix("sha256:")
        target = str(body.get("to_object_id") or "").removeprefix("sha256:")
        if not source or not target or source == target: raise ValidationError("media relation requires distinct from_object_id and to_object_id")
        for digest in (source, target):
            if not self.store.conn.execute("SELECT 1 FROM objects WHERE digest=?", (digest,)).fetchone(): raise NotFoundError("object not found")
            if not self.store.conn.execute("SELECT 1 FROM project_objects WHERE project_id=? AND digest=?", (project_id, digest)).fetchone(): raise NotFoundError("object is not in project")
        metadata = body.get("metadata", {})
        if not isinstance(metadata, dict): raise ValidationError("media relation metadata must be an object")
        try:
            ordinal = int(body.get("ordinal", 0))
        except (TypeError, ValueError) as exc:
            raise ValidationError("media relation ordinal must be an integer") from exc
        if ordinal < 0: raise ValidationError("media relation ordinal must be non-negative")
        request_hash = hashlib.sha256(canonical_json({"project_id": project_id, "from_object_id": source, "to_object_id": target, "kind": kind, "ordinal": ordinal, "metadata": metadata}).encode()).hexdigest()
        aggregate_id = "media-relations"
        replay = self._command_replay("media_relation.create", aggregate_id, idempotency_key, request_hash, project_id=project_id)
        if replay is not None:
            return replay
        try:
            self.store.conn.execute("INSERT INTO media_relations VALUES (?, ?, ?, ?, ?, ?, ?)", (project_id, source, target, kind, ordinal, canonical_json(metadata), now()))
        except sqlite3.IntegrityError as exc:
            raise ConflictError("media relation already exists") from exc
        created_at = self.store.conn.execute("SELECT created_at FROM media_relations WHERE project_id=? AND from_digest=? AND to_digest=? AND kind=? AND ordinal=?", (project_id, source, target, kind, ordinal)).fetchone()[0]
        result = {"project_id": project_id, "from_object_id": "sha256:" + source, "to_object_id": "sha256:" + target, "kind": kind, "ordinal": ordinal, "metadata": metadata, "created_at": created_at}
        return self._command_record("media_relation.create", aggregate_id, idempotency_key, request_hash, result, project_id=project_id)

    @staticmethod
    def _source_frame_thumbnail_descriptor(body):
        if not isinstance(body, dict) or set(body) != {"object_id", "source_object_id", "recipe_version", "selection"}:
            raise ValidationError("source-frame thumbnail requires object_id, source_object_id, recipe_version, and selection")
        descriptor = copy.deepcopy(body)
        for field in ("object_id", "source_object_id"):
            value = descriptor[field]
            if not isinstance(value, str) or not OBJECT_ID_RE.fullmatch(value) or not value.startswith("sha256:"):
                raise ValidationError(f"thumbnail {field} must be a canonical sha256 object id")
        if isinstance(descriptor["recipe_version"], bool) or not isinstance(descriptor["recipe_version"], int) or descriptor["recipe_version"] != 1:
            raise ValidationError("thumbnail recipe_version is unsupported")
        selection = descriptor["selection"]
        if not isinstance(selection, dict) or set(selection) != {"kind", "source_time_seconds"} or selection.get("kind") != "source_frame":
            raise ValidationError("thumbnail selection must identify a source_frame and source_time_seconds")
        source_time = selection.get("source_time_seconds")
        if isinstance(source_time, bool) or not isinstance(source_time, (int, float)) or not math.isfinite(float(source_time)) or not 0 <= float(source_time) <= 4_000_000_000:
            raise ValidationError("thumbnail source_time_seconds must be finite and in [0, 4000000000]")
        normalized_time = round(float(source_time), 6)
        if normalized_time != float(source_time):
            raise ValidationError("thumbnail source_time_seconds must be normalized to six decimal places")
        descriptor["selection"]["source_time_seconds"] = normalized_time
        return descriptor

    @staticmethod
    def _source_frame_thumbnail_identity(descriptor):
        time_micros = int(round(float(descriptor["selection"]["source_time_seconds"]) * 1_000_000))
        return (1 << 62) + time_micros * 1_000 + int(descriptor["recipe_version"])

    def get_source_frame_thumbnail(self, project, *, source_object_id, source_time_seconds, recipe_version=1):
        project_id = self.store.get_project(project)["id"]
        if not isinstance(source_object_id, str) or not OBJECT_ID_RE.fullmatch(source_object_id) or not source_object_id.startswith("sha256:"):
            raise ValidationError("thumbnail source_object_id must be a canonical sha256 object id")
        source_digest = source_object_id.removeprefix("sha256:")
        owned = self.store.conn.execute(
            "SELECT 1 FROM project_objects WHERE project_id=? AND digest=?", (project_id, source_digest),
        ).fetchone()
        if not owned:
            raise NotFoundError("thumbnail source object is outside the project")
        descriptor = self._source_frame_thumbnail_descriptor({
            "object_id": "sha256:" + "0" * 64,
            "source_object_id": source_object_id,
            "recipe_version": recipe_version,
            "selection": {"kind": "source_frame", "source_time_seconds": source_time_seconds},
        })
        source = descriptor["source_object_id"].removeprefix("sha256:")
        rows = self.store.conn.execute(
            "SELECT from_digest, metadata_json FROM media_relations "
            "WHERE project_id=? AND to_digest=? AND kind='derived_from' AND ordinal=? "
            "ORDER BY created_at, from_digest",
            (project_id, source, self._source_frame_thumbnail_identity(descriptor)),
        ).fetchall()
        for row in rows:
            metadata = json.loads(row["metadata_json"])
            if metadata.get("thumbnail") == descriptor | {"object_id": "sha256:" + row["from_digest"]}:
                return {"thumbnail": descriptor | {"object_id": "sha256:" + row["from_digest"]}}
        return {"thumbnail": None}

    @_durable_mutation
    def ensure_source_frame_thumbnail(self, project, body, *, idempotency_key=None):
        idempotency_key = require_idempotency_key(idempotency_key)
        project_id = self.store.get_project(project)["id"]
        descriptor = self._source_frame_thumbnail_descriptor(body)
        source = descriptor["source_object_id"].removeprefix("sha256:")
        thumbnail = descriptor["object_id"].removeprefix("sha256:")
        if source == thumbnail:
            raise ValidationError("thumbnail source and image objects must be distinct")
        ordinal = self._source_frame_thumbnail_identity(descriptor)
        for digest in (source, thumbnail):
            if not self.store.conn.execute("SELECT 1 FROM objects WHERE digest=?", (digest,)).fetchone():
                raise NotFoundError("thumbnail source or image object not found")
            if not self.store.conn.execute("SELECT 1 FROM project_objects WHERE project_id=? AND digest=?", (project_id, digest)).fetchone():
                raise NotFoundError("thumbnail source or image object is outside the project")
        source_row = self.store.conn.execute("SELECT media_type FROM objects WHERE digest=?", (source,)).fetchone()
        if not str(source_row["media_type"]).lower().startswith("video/"):
            raise ConflictError("source-frame thumbnail source object must be video")
        image = self.store.conn.execute("SELECT media_type FROM objects WHERE digest=?", (thumbnail,)).fetchone()
        if not image or str(image["media_type"]).lower() != "image/jpeg":
            raise ConflictError("source-frame thumbnail object must be image/jpeg")
        aggregate_id = f"{source}:{ordinal}:{descriptor['recipe_version']}"
        request_hash = hashlib.sha256(canonical_json({"project_id": project_id, "thumbnail": descriptor}).encode()).hexdigest()
        replay = self._command_replay("thumbnail.source_frame.ensure", aggregate_id, idempotency_key, request_hash, project_id=project_id)
        if replay is not None:
            return replay
        candidates = self.store.conn.execute(
            "SELECT from_digest, metadata_json, created_at FROM media_relations "
            "WHERE project_id=? AND to_digest=? AND kind='derived_from' AND ordinal=? "
            "ORDER BY created_at, from_digest",
            (project_id, source, ordinal),
        ).fetchall()
        existing = None
        for candidate in candidates:
            candidate_thumbnail = json.loads(candidate["metadata_json"]).get("thumbnail")
            if isinstance(candidate_thumbnail, dict) and all(
                candidate_thumbnail.get(key) == descriptor.get(key)
                for key in ("source_object_id", "recipe_version", "selection")
            ):
                existing = {"thumbnail": candidate_thumbnail}
                break
        if existing:
            result = existing["thumbnail"]
        else:
            metadata = {"thumbnail": descriptor}
            self.store.conn.execute(
                "INSERT INTO media_relations VALUES (?, ?, ?, 'derived_from', ?, ?, ?)",
                (project_id, thumbnail, source, ordinal, canonical_json(metadata), now()),
            )
            result = descriptor
        return self._command_record("thumbnail.source_frame.ensure", aggregate_id, idempotency_key, request_hash, result, project_id=project_id)

    def list_media_relations(self, project, *, cursor=None, limit=PAGE_DEFAULT_LIMIT):
        project_id = self.store.get_project(project)["id"]
        rows = self.store.conn.execute("SELECT * FROM media_relations WHERE project_id=? ORDER BY created_at, from_digest, to_digest, kind, ordinal", (project_id,)).fetchall()
        return _page_rows(rows, scope=f"media-relations:{project_id}", cursor=cursor, limit=limit,
                          key_fn=lambda row: (str(row["created_at"]), str(row["from_digest"]), str(row["to_digest"]), str(row["kind"]), int(row["ordinal"])),
                          resource_fn=lambda row: {"project_id": row["project_id"], "from_object_id": "sha256:" + row["from_digest"], "to_object_id": "sha256:" + row["to_digest"], "kind": row["kind"], "ordinal": int(row["ordinal"]), "metadata": json.loads(row["metadata_json"]), "created_at": row["created_at"]})

    @staticmethod
    def _child_policy(value):
        required = {"capabilities", "targets", "input_object_ids"}
        if not isinstance(value, dict) or not required.issubset(value) or set(value) - required - {"stages", "final_publication", "publications", "limits", "recoverable_outputs", "discovery_grant"}:
            raise ValidationError("child_delegation requires capabilities, targets, and input_object_ids")
        capabilities = value["capabilities"]
        if not isinstance(capabilities, list) or not capabilities or len(capabilities) > 32:
            raise ValidationError("child_delegation.capabilities must be a non-empty bounded list")
        normalized_caps = []
        for item in capabilities:
            if not isinstance(item, dict) or set(item) != {"capability_id", "capability_digest"}:
                raise ValidationError("child_delegation capability must pin id and digest")
            if not isinstance(item["capability_id"], str) or not item["capability_id"] or not isinstance(item["capability_digest"], str) or not re.fullmatch(r"sha256:[0-9a-f]{64}", item["capability_digest"]):
                raise ValidationError("child_delegation capability identity is invalid")
            normalized_caps.append(dict(item))
        targets = value["targets"]
        if not isinstance(targets, list) or not targets or len(targets) > 32:
            raise ValidationError("child_delegation.targets must be a non-empty bounded list")
        normalized_targets = [_normalize_execution_target(target) for target in targets]
        inputs = value["input_object_ids"]
        if not isinstance(inputs, list) or len(inputs) > 256 or any(not isinstance(item, str) or not item.startswith("sha256:") or not OBJECT_ID_RE.fullmatch(item) for item in inputs):
            raise ValidationError("child_delegation.input_object_ids must contain sha256 object IDs")
        if len({canonical_json(item) for item in normalized_targets}) != len(normalized_targets) or len(set(inputs)) != len(inputs) or len({item["capability_id"] for item in normalized_caps}) != len(normalized_caps):
            raise ValidationError("child_delegation entries must be unique")
        policy = {"capabilities": normalized_caps, "targets": normalized_targets, "input_object_ids": inputs}
        limits = value.get("limits", {})
        if (not isinstance(limits, dict) or set(limits) - CHILD_LIMIT_CEILINGS.keys()
                or any(type(n) is not int or n < 1 or n > CHILD_LIMIT_CEILINGS[key] for key, n in limits.items())):
            raise ValidationError("child_delegation.limits must fit the finite Runtime ceilings")
        # Freeze effective defaults in the admitted policy. Reading an existing
        # full policy preserves its bounds after future default changes.
        policy["limits"] = CHILD_LIMITS | limits
        if "discovery_grant" in value:
            grant = value["discovery_grant"]
            identities = {"project_id", "run_id", "task_id", "attempt_id", "capability_id"}
            if (not isinstance(grant, dict) or set(grant) != identities | {"capability_digest", "limits"}
                    or any(not isinstance(grant[key], str) or not grant[key] or "*" in grant[key]
                           for key in identities)
                    or not isinstance(grant["capability_digest"], str)
                    or not re.fullmatch(r"sha256:[0-9a-f]{64}", grant["capability_digest"])):
                raise ValidationError("discovery_grant requires one exact project/run/task/attempt and root capability")
            bounds = grant["limits"]
            if (not isinstance(bounds, dict) or set(bounds) != DISCOVERY_GRANT_CEILINGS.keys()
                    or any(type(n) is not int or n < 1 or n > DISCOVERY_GRANT_CEILINGS[key]
                           for key, n in bounds.items())):
                raise ValidationError("discovery_grant.limits requires every finite prototype bound")
            policy["discovery_grant"] = {**grant, "limits": dict(bounds)}
        if "recoverable_outputs" in value:
            grants = value["recoverable_outputs"]
            if not isinstance(grants, list) or len(grants) != 1:
                raise ValidationError("recoverable_outputs requires one exact pinned Human Review grant")
            grant = grants[0]
            if (not isinstance(grant, dict)
                    or set(grant) != {"capability_id", "capability_digest", "output_ports"}
                    or grant.get("capability_id") != "editorial.human_review"
                    or grant.get("output_ports") != ["state_result"]
                    or {key: grant.get(key) for key in ("capability_id", "capability_digest")} not in normalized_caps):
                raise ValidationError("recoverable_outputs must pin editorial.human_review/state_result in capabilities")
            policy["recoverable_outputs"] = [dict(grant)]
        if "stages" in value:
            stages = value["stages"]
            if not isinstance(stages, list) or not stages or len(stages) > 16:
                raise ValidationError("child_delegation.stages must be a non-empty bounded list")
            normalized_stages = []
            preceding = set()
            for stage in stages:
                if (not isinstance(stage, dict) or not {"name", "capability_id", "capability_digest", "target", "inputs"} <= set(stage)
                        or set(stage) - {"name", "capability_id", "capability_digest", "target", "inputs", "execution_request"}):
                    raise ValidationError("each child stage requires name, capability, target, and inputs")
                name = stage["name"]
                if not isinstance(name, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{0,63}", name) or name in preceding:
                    raise ValidationError("child stage name is invalid or repeated")
                capability = {"capability_id": stage["capability_id"], "capability_digest": stage["capability_digest"]}
                target = _normalize_execution_target(stage["target"])
                if capability not in normalized_caps or target not in normalized_targets:
                    raise ValidationError("child stage capability or target is outside policy")
                declared_inputs = stage["inputs"]
                if not isinstance(declared_inputs, list) or len(declared_inputs) > 256:
                    raise ValidationError("child stage inputs must be a bounded ordered list")
                names = set()
                for ref in declared_inputs:
                    if not isinstance(ref, dict) or not isinstance(ref.get("name"), str) or not ref["name"] or len(ref["name"]) > 128 or ref["name"] in names:
                        raise ValidationError("child stage input names must be unique non-empty strings")
                    names.add(ref["name"])
                    if set(ref) == {"name", "root_object_id"}:
                        if ref["root_object_id"] not in inputs:
                            raise ValidationError("child stage root input is outside parent policy")
                    elif set(ref) == {"name", "producer_stage", "output_port"}:
                        if (not isinstance(ref["producer_stage"], str) or ref["producer_stage"] not in preceding
                                or not isinstance(ref["output_port"], str) or not ref["output_port"] or len(ref["output_port"]) > 255):
                            raise ValidationError("child stage producer must be an earlier declared stage and port")
                    else:
                        raise ValidationError("child stage input must name a root object or producer stage and port")
                normalized_stage = {**stage, "target": target, "inputs": [dict(ref) for ref in declared_inputs]}
                if "execution_request" in stage:
                    if not isinstance(stage["execution_request"], dict) or "inputs" in stage["execution_request"]:
                        raise ValidationError("stage execution_request inputs are resolved by Runtime")
                    frozen_request = _normalize_execution_request(stage["execution_request"], [])
                    if frozen_request["target"] != target:
                        raise ValidationError("stage execution_request differs from its declared target")
                    normalized_stage["execution_request"] = frozen_request
                normalized_stages.append(normalized_stage)
                preceding.add(name)
            policy["stages"] = normalized_stages
        if "final_publication" in value:
            final = value["final_publication"]
            if "stages" not in policy or not isinstance(final, dict) or set(final) != {"stage", "verify_stage", "verify_output_port", "effect"}:
                raise ValidationError("final_publication requires a declared stage, verify source, and effect")
            if final["stage"] != policy["stages"][-1]["name"] or final["verify_stage"] not in [stage["name"] for stage in policy["stages"][:-1]]:
                raise ValidationError("final publication must follow its declared verify stage")
            final_inputs = policy["stages"][-1]["inputs"]
            matches = [ref for ref in final_inputs if ref.get("producer_stage") == final["verify_stage"] and ref.get("output_port") == final["verify_output_port"]]
            if len(final_inputs) != 1 or len(matches) != 1:
                raise ValidationError("final publication must consume exactly one declared verify output")
            effect = final["effect"]
            if not isinstance(effect, dict) or effect.get("effect_type") != "generation.publish_v1":
                raise ValidationError("final publication requires generation.publish_v1")
            groups = effect.get("payload", {}).get("groups") if isinstance(effect.get("payload"), dict) else None
            selectors = [selector for group in groups for selector in group.get("selectors", [])] if isinstance(groups, list) and all(isinstance(group, dict) and isinstance(group.get("selectors"), list) for group in groups) else []
            if any(not isinstance(selector, dict) for selector in selectors):
                raise ValidationError("final publication effect selectors must be objects")
            if len(selectors) != 1 or selectors[0].get("output_port") != final["verify_output_port"]:
                raise ValidationError("final publication effect must select the verified output port")
            policy["final_publication"] = dict(final)
        if "publications" in value:
            publications = value["publications"]
            if ("final_publication" in value or "stages" not in policy
                    or not isinstance(publications, dict) or set(publications) != {"raw", "final"}):
                raise ValidationError("publications requires exactly named raw and final declarations and stages")
            raw, final = publications["raw"], publications["final"]
            if (not isinstance(raw, dict) or set(raw) != {"stage", "output_port", "effect"}
                    or not isinstance(final, dict) or set(final) != {"stage", "output_port", "candidate_stage", "candidate_output_port", "verify_stage", "verify_output_port", "effect"}):
                raise ValidationError("named publications require exact raw and final source declarations")
            stages = {stage["name"]: stage for stage in policy["stages"]}
            order = list(stages)
            for publication in (raw, final):
                if (not isinstance(publication["stage"], str) or publication["stage"] not in stages or not isinstance(publication["output_port"], str)
                        or not publication["output_port"] or len(publication["output_port"]) > 255):
                    raise ValidationError("named publication stage or output port is invalid")
                effect = publication["effect"]
                groups = effect.get("payload", {}).get("groups") if isinstance(effect, dict) and isinstance(effect.get("payload"), dict) else None
                selectors = groups[0].get("selectors") if isinstance(groups, list) and len(groups) == 1 and isinstance(groups[0], dict) else None
                if (not isinstance(effect, dict) or effect.get("effect_type") != "generation.publish_v1"
                        or not isinstance(selectors, list) or len(selectors) != 1
                        or not isinstance(selectors[0], dict) or selectors[0].get("output_port") != publication["output_port"]
                        or effect["payload"].get("partial_success_policy") != "reject"):
                    raise ValidationError("named publication effect must select its one declared output port with partial_success_policy reject")
            candidate, verify = final["candidate_stage"], final["verify_stage"]
            if (not isinstance(candidate, str) or not isinstance(verify, str) or candidate not in stages or verify not in stages
                    or not isinstance(final["candidate_output_port"], str) or not final["candidate_output_port"]
                    or not isinstance(final["verify_output_port"], str) or not final["verify_output_port"]
                    or not (order.index(raw["stage"]) <= order.index(candidate) < order.index(verify) < order.index(final["stage"]))
                    or final["stage"] != order[-1] or raw["effect"] == final["effect"]):
                raise ValidationError("named publications must order raw, candidate, verification, and distinct final effects")
            def consumes(stage, producer, port, *, allow_auxiliary=False):
                count = sum(ref.get("producer_stage") == producer and ref.get("output_port") == port for ref in stages[stage]["inputs"])
                return count >= 1 if allow_auxiliary else count == 1
            if candidate == raw["stage"]:
                if final["candidate_output_port"] != raw["output_port"]:
                    raise ValidationError("raw candidate must use the declared raw output port")
            elif not consumes(candidate, raw["stage"], raw["output_port"], allow_auxiliary=True):
                raise ValidationError("candidate stage must consume the actual raw publication")
            if (not consumes(verify, candidate, final["candidate_output_port"])
                    or len(stages[final["stage"]]["inputs"]) != 2
                    or not consumes(final["stage"], candidate, final["candidate_output_port"])
                    or not consumes(final["stage"], verify, final["verify_output_port"])):
                raise ValidationError("verification and final publication must consume their declared candidate lineage")
            policy["publications"] = copy.deepcopy(publications)
        return policy

    def _validate_discovery_grant_binding(self, policy, project, capability, digest):
        grant = policy.get("discovery_grant")
        if grant is None:
            return
        if (project is None or grant["project_id"] != project
                or grant["capability_id"] != capability or grant["capability_digest"] != digest):
            raise AuthorizationError("discovery grant does not match parent project or root capability")
        # The selected attempt is historical and explicit. Never fall back to
        # a current attempt or expand this tuple through ancestry.
        selected = self.store.conn.execute(
            "SELECT 1 FROM runs r JOIN tasks t ON t.run_id=r.id "
            "JOIN attempts a ON a.task_id=t.id "
            "WHERE r.project_id=? AND r.id=? AND t.id=? AND a.id=?",
            (project, grant["run_id"], grant["task_id"], grant["attempt_id"]),
        ).fetchone()
        if selected is None:
            raise AuthorizationError("discovery grant selected project/run/task/attempt association does not match")

    @_verified_mutation
    def create_task(self, body, *, enforce_readiness=False, _host_owned=False, _delegated_lineage=None, _delegated_stage=None, _delegated_inputs=None, _verified_publication_source=None, _recoverable_outputs=None):
        if "capability" in body or "expected_effect" in body:
            raise ValidationError("legacy task body aliases are not supported")
        capability = body.get("capability_id")
        if capability == MEDIA_IMPORT_CAPABILITY and not _host_owned:
            raise AuthorizationError("runtime media import capability is host-owned")
        digest = body.get("capability_digest", "sha256:" + hashlib.sha256(str(capability).encode()).hexdigest())
        execution_request = body.get("execution_request")
        task_spec_value = body.get("spec", {})
        if not isinstance(task_spec_value, dict):
            raise ValidationError("task spec must be an object")
        reserved = {"child_delegation", "delegated_parent", "delegated_stage", "delegated_inputs", "verified_publication_source", "input_refs", "derived_input_registry", "delegation_closed_attempt_id", "delegated_recoverable_outputs", "discovery_grant"}
        if set(task_spec_value) & reserved or set(body) & (reserved - {"child_delegation"}):
            raise ValidationError("delegation fields must use Runtime admission authority")
        if _delegated_lineage is not None and "child_delegation" in body:
            raise ValidationError("delegated children cannot delegate further")
        if isinstance(task_spec_value, dict) and (
            "execution_request" in task_spec_value
            or (
                isinstance(task_spec_value.get("spec"), dict)
                and "execution_request" in task_spec_value["spec"]
            )
        ):
            raise ValidationError("execution_request must be supplied through the first-class admission field")
        if isinstance(task_spec_value, dict) and (
            "execution_binding" in task_spec_value
            or (
                isinstance(task_spec_value.get("spec"), dict)
                and "execution_binding" in task_spec_value["spec"]
            )
        ):
            raise ValidationError("caller-supplied execution_binding is not accepted")
        if isinstance(execution_request, dict) and "execution_binding" in execution_request:
            raise ValidationError("caller-supplied execution_binding is not accepted")
        task_spec = {"input_object_ids": body.get("input_object_ids", []), "schema_version": body.get("schema_version", "1"), "capability_digest": digest, "spec": body.get("spec", {})}
        if "child_delegation" in body:
            task_spec["child_delegation"] = self._child_policy(body["child_delegation"])
            if any(object_id not in task_spec["input_object_ids"] for object_id in task_spec["child_delegation"]["input_object_ids"]):
                raise AuthorizationError("child policy root inputs must be admitted parent inputs")
            if "discovery_grant" in task_spec["child_delegation"]:
                project = self.store.get_project(body.get("project")) if body.get("project") else None
                self._validate_discovery_grant_binding(
                    task_spec["child_delegation"], project["id"] if project else None, capability, digest,
                )
            declarations = list(task_spec["child_delegation"].get("publications", {}).values())
            final = task_spec["child_delegation"].get("final_publication")
            if final is not None:
                declarations.append(final)
            for publication in declarations:
                project = self.store.get_project(body.get("project")) if body.get("project") else None
                if project is None:
                    raise ValidationError("final publication requires a project-scoped parent")
                self.store._validate_settlement_effect(publication["effect"], project_id=project["id"])
        if _delegated_lineage is not None:
            task_spec["delegated_parent"] = dict(_delegated_lineage)
        if _recoverable_outputs is not None:
            task_spec["delegated_recoverable_outputs"] = _recoverable_outputs
        if _delegated_stage is not None:
            task_spec["delegated_stage"] = _delegated_stage
        if _delegated_inputs is not None:
            task_spec["delegated_inputs"] = list(_delegated_inputs or [])
        if _verified_publication_source is not None:
            task_spec["verified_publication_source"] = dict(_verified_publication_source)
        if "generation_intent" in body:
            if not isinstance(body["generation_intent"], dict):
                raise ValidationError("generation_intent must be an object")
            # Runtime owns transport and durability only. GEN owns the
            # meaning of this opaque producer intent and its member fields.
            task_spec[GENERATION_INTENT_STORAGE_KEY] = body["generation_intent"]
        if "required_facts" in body:
            task_spec["required_facts"] = normalize_execution_facts(body["required_facts"], field="required_facts")
        if "storage_estimate" in body:
            task_spec["storage_estimate"] = self.store._validate_storage_estimate(body["storage_estimate"])
        from .capture_validation import validate_capture
        inputs = task_spec_value.get("inputs") if isinstance(task_spec_value.get("inputs"), dict) else {}
        value = self.store.create_task(capability, task_spec, body.get("project"), body.get("idempotency_key"), body.get("settlement_effect"), digest, enforce_readiness=enforce_readiness, execution_request=execution_request,
                                       capture_validator=lambda snapshot, ref: validate_capture(self, snapshot, ref, inputs))
        return value

    def _live_delegating_parent(self, attempt_id, lease, *, identity):
        row = self.store.conn.execute("SELECT * FROM attempts WHERE id=?", (attempt_id,)).fetchone()
        self._assert_attempt_identity(row, identity)
        self._validate_attempt_lease(row, lease, self.store._current_runtime_epoch())
        task = self.store.conn.execute("SELECT * FROM tasks WHERE id=?", (row["task_id"],)).fetchone()
        if (not task or task["status"] != "running" or task["attempt_id"] != attempt_id
                or task["lease_token"] != row["lease_id"] or int(task["lease_fence"]) != int(row["fence"])
                or task["executor_id"] != row["executor_id"] or int(task["runtime_epoch"] or 0) != int(row["runtime_epoch"])):
            raise LeaseError("parent attempt is no longer live")
        if identity is not None and (self._task_requires_remote_activation(task["id"]) or isinstance(identity.get("qualified_activation"), dict)):
            # A draining activation may still finish the parent attempt captured at
            # the cutoff (_assert_attempt_identity enforced it above), so freshness
            # applies only when no drain has begun.
            activation = identity.get("qualified_activation")
            marker = self._remote_drain(activation.get("task_id"), activation.get("activation_id")) if isinstance(activation, dict) else None
            if not self._remote_activation_matches(task["id"], identity, self._trusted_execution_placement(identity), require_fresh=marker is None):
                raise AuthorizationError("parent activation is missing, expired, revoked, or foreign")
        if self.store._spec(task).get("delegated_parent") is not None:
            raise AuthorizationError("delegated children cannot delegate further")
        policy = self.store._spec(task).get("child_delegation")
        if self.store._spec(task).get("delegation_closed_attempt_id") == attempt_id:
            raise AuthorizationError("parent child authority has ended")
        if policy is None:
            raise AuthorizationError("parent task has no child delegation policy")
        policy = self._child_policy(policy)
        project = self.store.conn.execute("SELECT project_id FROM runs WHERE id=?", (task["run_id"],)).fetchone()[0]
        self._validate_discovery_grant_binding(policy, project, task["capability"], task["capability_digest"])
        return row, task, project, policy

    def _child_identity_digest(self, identity):
        if identity is None:
            raise AuthorizationError("authenticated worker identity is required")
        return sha256_bytes(canonical_json({
            "actor": identity.get("actor"),
            "placement": self._trusted_execution_placement(identity),
        }).encode())

    @_durable_mutation
    def issue_child_authority(self, attempt_id, body, *, identity):
        body = _wire_object(body, required=("lease_id", "fence", "runtime_epoch"), allowed=("lease_id", "fence", "runtime_epoch", "child", "derived_inputs"))
        _wire_string(body, "lease_id")
        _wire_integer(body, "fence")
        _wire_integer(body, "runtime_epoch", positive=True)
        row, task, project, policy = self._live_delegating_parent(attempt_id, body, identity=identity)
        recovery = self.store.placement_recovery(task["id"])
        effective_target = self.store.effective_execution_target(task["id"])
        payload = {
            "version": 1, "realm_id": self.realm["id"], "session_id": self.runtime_session_id,
            "parent_task_id": task["id"], "parent_attempt_id": attempt_id,
            "parent_lease_id": row["lease_id"], "parent_fence": int(row["fence"]),
            "runtime_epoch": int(row["runtime_epoch"]), "executor_id": row["executor_id"],
            "project_id": project, "expires_at": row["lease_expires_at"],
            "policy_digest": sha256_bytes(canonical_json(policy).encode()),
            "identity_digest": self._child_identity_digest(identity),
            "effective_target": effective_target,
            "placement_version": int(recovery.get("placement_version", 0)) if recovery else 0,
        }
        if "derived_inputs" in body or "child" in body:
            child = _wire_object(body.get("child"), required=("child_id", "capability_id", "capability_digest"), allowed=("child_id", "capability_id", "capability_digest"))
            require_idempotency_key(child["child_id"])
            capability = {key: child[key] for key in ("capability_id", "capability_digest")}
            if capability not in policy["capabilities"] or "stages" in policy:
                raise AuthorizationError("derived input child must match an unstaged declared capability")
            payload["child"] = dict(child)
            payload["derived_inputs"] = self._register_derived_inputs(
                body.get("derived_inputs", []), row, task, project, policy, body,
            )
        encoded = base64.urlsafe_b64encode(canonical_json(payload).encode()).decode().rstrip("=")
        signature = hmac.new(self._child_authority_key, encoded.encode(), hashlib.sha256).hexdigest()
        return {"authority": encoded + "." + signature, "expires_at": row["lease_expires_at"], "parent_task_id": task["id"], "parent_attempt_id": attempt_id, **({"child": payload["child"], "derived_inputs": payload["derived_inputs"]} if "child" in payload else {})}

    def _verify_derived_association(self, ref, parent, attempt, project):
        association = self.store.get_managed_output(ref["association_id"])
        provenance = association["provenance"]
        if (association["task_id"] != parent["id"] or association["attempt_id"] != attempt["id"]
                or association["project_id"] != project or association["role"] != "derived_input"
                or association["object_id"] != ref["object_id"] or association["size"] != ref["size"]
                or association["media_type"] != ref["media_type"] or association["filename"] != ref["filename"]
                or association["output_port"] != ref["output_port"] or association["durability"] != "durable"
                or association["lifecycle"]["state"] not in {"available", "promoted"}
                or provenance.get("task_id") != parent["id"] or provenance.get("attempt_id") != attempt["id"]
                or provenance.get("executor_id") != attempt["executor_id"]
                or provenance.get("fence") != int(attempt["fence"])
                or provenance.get("runtime_epoch") != int(attempt["runtime_epoch"])):
            raise AuthorizationError("derived input managed association no longer matches its receipt")
        digest = ref["object_id"].removeprefix("sha256:")
        obj = self.store.conn.execute("SELECT size, media_type FROM objects WHERE digest=?", (digest,)).fetchone()
        if (obj is None or int(obj["size"]) != ref["size"] or obj["media_type"] != ref["media_type"]
                or not self.store.conn.execute("SELECT 1 FROM project_objects WHERE project_id=? AND digest=?", (project, digest)).fetchone()):
            raise ConflictError("derived input object metadata or project association changed")
        self._verify_child_object_bytes(digest, ref["size"], label="derived input CAS object")

    def _verify_child_object_bytes(self, digest, size, *, label):
        try:
            root_fd, prefix_fd = self._cas_prefix_fds(digest, create=False)
        except OSError as exc:
            raise ConflictError(f"{label} is unavailable") from exc
        try:
            self._verify_file_at(prefix_fd, digest[2:], digest, size, label=label)
        finally:
            os.close(prefix_fd)
            os.close(root_fd)

    def _register_derived_inputs(self, inputs, attempt, parent, project, policy, lease):
        limits = policy["limits"]
        if not isinstance(inputs, list) or len(inputs) > limits["max_child_inputs"]:
            raise ValidationError("derived_inputs exceeds the child input count limit")
        if inputs and project is None:
            raise ValidationError("derived inputs require a project-scoped parent")
        spec = self.store._spec(parent)
        registry = {key: ref for key, ref in spec.get("derived_input_registry", {}).items() if ref.get("parent_attempt_id") == attempt["id"]}
        normalized = []
        for item in inputs:
            item = _wire_object(item, required=("name", "output_port", "filename", "object_id", "size", "media_type"), allowed=("name", "output_port", "filename", "object_id", "size", "media_type"))
            for key in ("name", "output_port", "media_type"):
                _wire_string(item, key)
                if len(item[key]) > 255 or any(ord(c) < 32 for c in item[key]):
                    raise ValidationError("derived input metadata is invalid")
            _canonical_execution_input_filename(item["filename"], "derived input filename")
            _wire_integer(item, "size")
            if item["size"] < 0 or item["size"] > OBJECT_MAX_BYTES or not isinstance(item["object_id"], str) or not re.fullmatch(r"sha256:[0-9a-f]{64}", item["object_id"]):
                raise ValidationError("derived input identity or size is invalid")
            normalized.append(dict(item))
        if len({item["object_id"] for item in normalized}) != len(normalized) or len({item["name"] for item in normalized}) != len(normalized):
            raise ValidationError("derived input identities and names must be unique")
        if sum(item["size"] for item in normalized) > limits["max_child_bytes"]:
            raise ValidationError("child input byte limit exceeded")
        # Budget the union before checking bytes or associating anything.
        candidate = dict(registry)
        for item in normalized:
            candidate.setdefault(item["object_id"], item)
        if len(candidate) > limits["max_derived_objects"] or sum(item["size"] for item in candidate.values()) > limits["max_derived_bytes"]:
            raise ValidationError("derived input attempt count or byte limit exceeded")
        refs = []
        for item in normalized:
            digest = item["object_id"].removeprefix("sha256:")
            if not self._is_authorized_generic_output(
                digest, item["size"], item["media_type"], name=item["name"], output_port=item["output_port"],
                filename=item["filename"], recorded_filename=item["filename"], attempt_row=attempt,
                task_row=parent, project_id=project, lease_body=lease,
            ):
                raise AuthorizationError("derived input requires this live attempt's authenticated upload receipt")
            previous = registry.get(item["object_id"])
            if previous is not None:
                if any(previous.get(key) != value for key, value in item.items()):
                    raise ConflictError("derived input was already registered with another descriptor")
                ref = previous
            else:
                obj = self.store.conn.execute("SELECT size, media_type FROM objects WHERE digest=?", (digest,)).fetchone()
                if obj is None or int(obj["size"]) != item["size"] or obj["media_type"] != item["media_type"]:
                    raise ConflictError("derived input object metadata does not match upload")
                self._verify_child_object_bytes(digest, item["size"], label="derived input CAS object")
                self.store.conn.execute("INSERT OR IGNORE INTO project_objects(project_id, digest, relation, created_at) VALUES (?, ?, 'managed', ?)", (project, digest, now()))
                output = {**item, "digest": item["object_id"], "kind": "object", "role": "derived_input", "group_key": "derived-input-" + attempt["id"], "variant_key": digest}
                association = self.store._associate_managed_outputs({"outputs": [output]}, task_id=parent["id"], attempt_id=attempt["id"], project_id=project)[0]
                ref = {**item, "association_id": association["association_id"], "parent_attempt_id": attempt["id"]}
                registry[item["object_id"]] = ref
            self._verify_derived_association(ref, parent, attempt, project)
            refs.append(ref)
        spec["derived_input_registry"] = registry
        self.store.conn.execute("UPDATE tasks SET spec_digest=? WHERE id=?", (self.store._store_spec(spec), parent["id"]))
        return refs

    def _decode_child_authority(self, token):
        if not isinstance(token, str) or len(token) > 1024 * 1024 or token.count(".") != 1:
            raise AuthorizationError("invalid child authority")
        encoded, supplied = token.split(".", 1)
        expected = hmac.new(self._child_authority_key, encoded.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(supplied, expected):
            raise AuthorizationError("invalid child authority")
        try:
            payload = json.loads(base64.urlsafe_b64decode(encoded + "=" * (-len(encoded) % 4)))
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise AuthorizationError("invalid child authority") from exc
        if not isinstance(payload, dict) or payload.get("version") != 1 or payload.get("realm_id") != self.realm["id"] or payload.get("session_id") != self.runtime_session_id:
            raise AuthorizationError("child authority belongs to another runtime session")
        return payload

    def _delegated_stage_rows(self, project, lineage):
        """Read the already admitted siblings under the same parent fence."""
        rows = self.store.conn.execute(
            "SELECT t.id, t.status, t.attempt_id, t.spec_digest FROM tasks t "
            "JOIN runs r ON r.id=t.run_id JOIN task_specs s ON s.digest=t.spec_digest WHERE r.project_id IS ? "
            "AND json_extract(s.body_json, '$.delegated_parent.parent_attempt_id')=?",
            (project, lineage["parent_attempt_id"]),
        ).fetchall()
        stages = {}
        for row in rows:
            spec = self.store._spec(row)
            recorded = spec.get("delegated_parent")
            if not isinstance(recorded, dict) or any(recorded.get(key) != lineage[key] for key in ("parent_task_id", "parent_attempt_id", "parent_lease_id", "parent_fence", "runtime_epoch", "executor_id", "parent_placement", "parent_effective_target", "parent_placement_version", "project_id")):
                continue
            name = spec.get("delegated_stage")
            if name in stages:
                raise ConflictError("delegated stage has duplicate admissions")
            if name is not None:
                stages[name] = row
        return stages

    def _resolve_delegated_stage_inputs(self, declared, supplied, *, siblings, project, lineage):
        if not isinstance(supplied, list) or len(supplied) != len(declared):
            raise ValidationError("input_refs must match the declared stage order")
        object_ids, resolved = [], []
        for expected, ref in zip(declared, supplied):
            if not isinstance(ref, dict) or ref.get("name") != expected["name"]:
                raise ValidationError("input_refs must match the declared stage order")
            if "root_object_id" in expected:
                if set(ref) != {"name", "root_object_id"} or ref["root_object_id"] != expected["root_object_id"]:
                    raise AuthorizationError("root input is outside the declared stage policy")
                object_id = expected["root_object_id"]
                resolved.append({"name": ref["name"], "root_object_id": object_id, "object_id": object_id})
            else:
                if set(ref) != {"name", "producer_task_id", "association_id", "output_port"} or ref["output_port"] != expected["output_port"]:
                    raise AuthorizationError("producer input is outside the declared stage policy")
                producer = siblings.get(expected["producer_stage"])
                if producer is None or producer["id"] != ref["producer_task_id"] or producer["status"] != "completed":
                    raise ConflictError("declared producer stage is not settled")
                association = self.store.get_managed_output(ref["association_id"])
                if (association["task_id"] != producer["id"] or association["attempt_id"] != producer["attempt_id"]
                        or association["project_id"] != project or association["output_port"] != expected["output_port"]
                        or association["role"] == "recoverable_snapshot"
                        or association["durability"] != "durable" or association["lifecycle"]["state"] not in {"available", "promoted"}):
                    raise AuthorizationError("managed output does not match the declared live lineage and port")
                attempt = self.store.conn.execute("SELECT settled, runtime_epoch FROM attempts WHERE id=? AND task_id=?", (association["attempt_id"], producer["id"])).fetchone()
                if not attempt or not attempt["settled"] or int(attempt["runtime_epoch"]) != lineage["runtime_epoch"]:
                    raise ConflictError("producer managed output is not settled in the parent epoch")
                object_id = association["object_id"]
                resolved.append({"name": ref["name"], "producer_stage": expected["producer_stage"], "producer_task_id": producer["id"], "producer_attempt_id": producer["attempt_id"], "association_id": association["association_id"], "output_port": association["output_port"], "object_id": object_id})
            object_ids.append(object_id)
        if len(set(object_ids)) != len(object_ids):
            raise ValidationError("resolved delegated inputs must have unique object IDs")
        return object_ids, resolved

    @staticmethod
    def _named_publication_output(effect, outputs):
        """Resolve the admitted GEN selector, including legacy output defaults."""
        group = effect["payload"]["groups"][0]
        selector = group["selectors"][0]
        key = (selector["output_port"], group["group_key"], selector["variant_key"], selector["ordinal"])
        if not isinstance(outputs, list):
            raise ValidationError("named publication requires an outputs list")
        matches = []
        for output in outputs:
            if not isinstance(output, dict) or output.get("role") == "thumbnail":
                continue
            ordinal = output.get("ordinal", 0)
            if type(ordinal) is not int or ordinal < 0:
                continue
            alias = output.get("selector")
            alias = alias if isinstance(alias, dict) else {}
            actual = (output.get("output_port", output.get("name", "output")),
                      output.get("group_key", alias.get("group_key", "default")),
                      output.get("variant_key", alias.get("variant_key", str(ordinal))), ordinal)
            if actual == key:
                matches.append(output)
        if len(matches) != 1:
            raise ConflictError("named publication selector must resolve exactly one output")
        return matches[0]

    def _named_publication_association(self, task, publication):
        outputs = [output for output in self.store.list_managed_outputs(task["id"])
                   if output["attempt_id"] == task["attempt_id"]]
        output = self._named_publication_output(publication["effect"], outputs)
        if (output["role"] == "recoverable_snapshot" or output["durability"] != "durable"
                or output["lifecycle"]["state"] not in {"available", "promoted"}):
            raise ConflictError("named publication selected association is no longer available")
        return output

    def _assert_delegated_publication_source(self, source, project):
        association = self.store.get_managed_output(source["association_id"])
        producer = self.store.conn.execute("SELECT * FROM tasks WHERE id=?", (source["producer_task_id"],)).fetchone()
        attempt = self.store.conn.execute("SELECT * FROM attempts WHERE id=?", (source["producer_attempt_id"],)).fetchone()
        obj = self.store.conn.execute("SELECT size FROM objects WHERE digest=?", (source["object_id"].removeprefix("sha256:"),)).fetchone()
        if (producer is None or producer["status"] != "completed" or producer["attempt_id"] != source["producer_attempt_id"]
                or attempt is None or not attempt["settled"] or int(attempt["runtime_epoch"]) != self.store._current_runtime_epoch()
                or obj is None or int(obj["size"]) != association["size"]
                or (project is not None and not self.store.conn.execute("SELECT 1 FROM project_objects WHERE project_id=? AND digest=?", (project, source["object_id"].removeprefix("sha256:"))).fetchone())
                or association["task_id"] != source["producer_task_id"]
                or association["attempt_id"] != source["producer_attempt_id"]
                or association["project_id"] != project or association["object_id"] != source["object_id"]
                or association["output_port"] != source["output_port"]
                or association["role"] == "recoverable_snapshot" or association["durability"] != "durable"
                or association["lifecycle"]["state"] not in {"available", "promoted"}):
            raise ConflictError("delegated publication source is no longer available")
        self._verify_child_object_bytes(source["object_id"].removeprefix("sha256:"), association["size"], label="delegated publication source CAS object")
        return producer, association

    def _read_delegated_publication(self, source, effect, project):
        """Read the existing effect result and Generation rows, never caller receipts."""
        producer, association = self._assert_delegated_publication_source(source, project)
        declared = json.loads(producer["expected_effect_json"]) if producer["expected_effect_json"] else None
        result = json.loads(producer["result_json"] or "{}")
        publication = result.get("generation_publish_v1")
        if declared != effect or not isinstance(publication, dict) or publication.get("effect_type") != "generation.publish_v1":
            raise ConflictError("raw publication does not match its admitted effect")
        groups = publication.get("publications", [])
        variants = [variant for group in groups for variant in group.get("variants", [])]
        if (len(groups) != 1 or len(variants) != 1
                or variants[0].get("generation_id") != association["generation_id"]
                or variants[0].get("object_id") != source["object_id"]
                or variants[0].get("output_port") != source["output_port"]
                or variants[0].get("variant_key") != association["variant_key"]
                or variants[0].get("ordinal") != association["ordinal"]
                or groups[0].get("group_key") != association["group_key"]
                or groups[0].get("generation_id") != association["generation_id"]
                or variants[0].get("variant_id") != "variant-" + hashlib.sha256(canonical_json({"generation_id": association["generation_id"], "ordinal": association["ordinal"], "variant_key": association["variant_key"]}).encode()).hexdigest()):
            raise ConflictError("raw publication result does not match its actual managed association")
        variant = self.store.conn.execute(
            "SELECT v.object_id, v.generation_id, g.project_id, g.source_task_id FROM generation_variants v JOIN generations g ON g.id=v.generation_id WHERE v.id=?",
            (variants[0].get("variant_id"),),
        ).fetchone()
        if (variant is None or variant["object_id"] != source["object_id"].removeprefix("sha256:")
                or variant["generation_id"] != association["generation_id"]
                or variant["project_id"] != project or variant["source_task_id"] != source["producer_task_id"]):
            raise ConflictError("raw publication Generation readback does not match its lineage")
        return publication

    def _bound_named_final_publication_effect(self, effect, source):
        """Fill only native H3 lineage metadata from Runtime-owned readback."""
        effect = copy.deepcopy(effect)
        metadata = effect["payload"].get("metadata")
        h3 = metadata.get("h3_av") if isinstance(metadata, dict) else None
        if isinstance(h3, dict):
            raw = source["raw"]
            association = self.store.get_managed_output(raw["association_id"])
            variant = source["raw_publication"]["publications"][0]["variants"][0]
            h3.update({
                "candidate_sha256": source["candidate"]["object_id"].removeprefix("sha256:"),
                "raw_sha256": raw["object_id"].removeprefix("sha256:"),
                "raw_generation_id": association["generation_id"],
                "raw_variant_id": variant["variant_id"],
                "raw_association_id": association["association_id"],
                "raw_group_key": association["group_key"],
                "raw_variant_key": association["variant_key"],
                "raw_output_port": association["output_port"],
            })
        return effect

    def _validate_named_publication_lineage(self, source, project, lineage):
        producers = {}
        for key in ("candidate", "verification", "raw"):
            producer, _ = self._assert_delegated_publication_source(source[key], project)
            spec = self.store._spec(producer)
            if spec.get("delegated_parent") != lineage or spec.get("delegated_stage") != source[key]["producer_stage"]:
                raise ConflictError("named publication source escaped its parent lineage")
            producers[key] = spec
        raw_task = self.store.conn.execute("SELECT * FROM tasks WHERE id=?", (source["raw"]["producer_task_id"],)).fetchone()
        selected_raw = self._named_publication_association(raw_task, {"effect": source["raw_effect"]})
        if selected_raw["association_id"] != source["raw"]["association_id"]:
            raise ConflictError("raw publication selector no longer resolves its frozen association")
        def consumes(spec, selected):
            return any(all(ref.get(key) == selected[key] for key in ("producer_task_id", "producer_attempt_id", "association_id", "output_port", "object_id"))
                       for ref in spec.get("delegated_inputs", []))
        if (source["candidate"]["producer_task_id"] != source["raw"]["producer_task_id"]
                and not consumes(producers["candidate"], source["raw"])):
            raise AuthorizationError("candidate does not descend from the actual raw publication")
        if (source["candidate"]["producer_task_id"] == source["raw"]["producer_task_id"]
                and source["candidate"]["association_id"] != source["raw"]["association_id"]):
            raise AuthorizationError("candidate substituted the raw publication")
        if not consumes(producers["verification"], source["candidate"]):
            raise AuthorizationError("verification does not consume this candidate")
        actual = self._read_delegated_publication(source["raw"], source["raw_effect"], project)
        if actual != source["raw_publication"]:
            raise ConflictError("actual raw publication changed after final admission")

    def _require_candidate_verification_receipt(self, source, manifest_digest):
        verification = source.get("verification", source)
        task = self.store.conn.execute("SELECT * FROM tasks WHERE id=?", (verification["producer_task_id"],)).fetchone()
        receipt = self.store._spec(task).get("candidate_verification_receipt")
        if not isinstance(receipt, dict):
            raise VerificationReceiptMissingError("Runtime verification receipt is missing")
        if receipt.get("candidate_verified") is not True:
            raise CandidateNotVerifiedError("candidate was not verified")
        if manifest_digest is None or receipt.get("candidate_sha256") != manifest_digest:
            raise VerificationDigestMismatchError("verification receipt does not match the manifest")

    def _verification_receipt_writer(self, policy, spec, staged, result, project_id):
        """Build a receipt only for the declared verifier and its stored evidence."""
        final = (policy.get("publications") or {}).get("final") or policy.get("final_publication")
        if not final or spec.get("delegated_stage") != final["verify_stage"]:
            return None
        manifest_digest = self.store._validated_manifest_digest(result, project_id=project_id)
        outputs = [item for item in staged["items"]
                   if item["output_port"] == final["verify_output_port"]
                   and item["output"]["kind"] == "object" and item["durability"] == "durable"]
        if manifest_digest is None or len(outputs) != 1 or outputs[0]["size"] > 16 * 1024 * 1024:
            return None

        def read_verified(digest, size, *, collect=False):
            root_fd, prefix_fd = self._cas_prefix_fds(digest, create=False)
            try:
                fd = os.open(digest[2:], os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0), dir_fd=prefix_fd)
                try:
                    self._verify_open_file(fd, digest, size, label="verification evidence CAS object")
                    os.lseek(fd, 0, os.SEEK_SET)
                    hasher, chunks = hashlib.sha256(), []
                    while True:
                        chunk = os.read(fd, 1024 * 1024)
                        if not chunk:
                            break
                        hasher.update(chunk)
                        if collect:
                            chunks.append(chunk)
                    if hasher.hexdigest() != digest:
                        raise ConflictError("verification evidence CAS object changed while reading")
                    return hasher.hexdigest(), b"".join(chunks)
                finally:
                    os.close(fd)
            finally:
                os.close(prefix_fd)
                os.close(root_fd)

        def write(timestamp):
            _, data = read_verified(outputs[0]["digest"], outputs[0]["size"], collect=True)
            try:
                decision = json.loads(data)
            except (ValueError, UnicodeError):
                return None
            if not isinstance(decision, dict) or type(decision.get("candidate_verified")) is not bool:
                return None
            actual_digest, _ = read_verified(manifest_digest, result["manifest_ref"]["size"])
            return {"candidate_verified": decision["candidate_verified"],
                    "candidate_sha256": actual_digest, "verifier": final["verify_stage"],
                    "verified_at": timestamp}

        return write

    def _live_child_authority(self, authority, *, identity):
        payload = self._decode_child_authority(authority)
        if payload.get("identity_digest") != self._child_identity_digest(identity):
            raise AuthorizationError("child authority is bound to another worker identity")
        lease = {"lease_id": payload.get("parent_lease_id"), "fence": payload.get("parent_fence"), "runtime_epoch": payload.get("runtime_epoch")}
        row, parent, project, policy = self._live_delegating_parent(payload.get("parent_attempt_id"), lease, identity=identity)
        recovery = self.store.placement_recovery(parent["id"])
        placement_version = int(recovery.get("placement_version", 0)) if recovery else 0
        effective_target = self.store.effective_execution_target(parent["id"])
        activation = identity.get("qualified_activation") if isinstance(identity, dict) else None
        if self._task_requires_remote_activation(parent["id"]) or isinstance(activation, dict):
            placement = self._trusted_execution_placement(identity)
            marker = self._remote_drain(parent["id"], activation.get("activation_id") if isinstance(activation, dict) else None)
            cutoff = marker.get("parent_attempt") if marker else None
            if marker is not None and (cutoff is None or any(payload.get(key) != value for key, value in cutoff.items())):
                raise AuthorizationError("child authority is outside remote drain cutoff")
            if not self._remote_activation_matches(
                parent["id"], identity, placement, require_fresh=marker is None
            ):
                raise AuthorizationError("remote activation is missing, expired, revoked, or foreign")
            if not self._activation_allows_child(parent, activation, effective_target, placement_version):
                raise AuthorizationError("qualified credential is not authorized for this child lineage")
        if (payload.get("parent_task_id") != parent["id"] or payload.get("executor_id") != row["executor_id"]
                or payload.get("project_id") != project or payload.get("expires_at") != row["lease_expires_at"]
                or payload.get("policy_digest") != sha256_bytes(canonical_json(policy).encode())
                or payload.get("effective_target") != effective_target
                or payload.get("placement_version") != placement_version):
            raise AuthorizationError("child authority no longer matches parent attempt")
        return payload, row, parent, project, policy, recovery, placement_version, effective_target

    @_durable_mutation
    def admit_delegated_child(self, body, *, idempotency_key, identity):
        body = _wire_object(body, required=("authority", "task"), allowed=("authority", "task"))
        payload, row, parent, project, policy, recovery, placement_version, effective_target = self._live_child_authority(body["authority"], identity=identity)
        task = _wire_object(body["task"], required=("capability_id", "capability_digest"), allowed=("capability_id", "capability_digest", "input_object_ids", "input_refs", "stage", "schema_version", "spec", "execution_request", "generation_intent", "required_facts", "storage_estimate"))
        if {"capability_id": task["capability_id"], "capability_digest": task["capability_digest"]} not in policy["capabilities"]:
            raise AuthorizationError("child capability is outside parent policy")
        idempotency_key = require_idempotency_key(idempotency_key)
        stages = policy.get("stages")
        exact_child = payload.get("child")
        derived_refs = payload.get("derived_inputs", [])
        if exact_child is not None and (exact_child["child_id"] != idempotency_key
                or any(exact_child[key] != task[key] for key in ("capability_id", "capability_digest"))):
            raise AuthorizationError("derived input receipt is bound to another exact child")
        limits = policy["limits"]
        accounting = self.store.delegated_child_accounting(parent["id"], row["id"], idempotency_key=idempotency_key)
        if not accounting["replay"]:
            if accounting["lifetime"] >= limits["max_children"]:
                raise ValidationError("parent child count limit exceeded")
            if accounting["active"] >= limits["max_active_children"]:
                raise ValidationError("parent active child count limit exceeded")
        stage_name = task.get("stage")
        request = task.get("execution_request")
        if request is not None and not isinstance(request, dict):
            raise ValidationError("execution_request must be an object")
        resolved_inputs = None
        verified_source = None
        publication_effect = None
        if stages is None:
            if stage_name is not None or "input_refs" in task:
                raise ValidationError("parent policy does not declare child stages")
            inputs = task.get("input_object_ids", [])
            authorized_ids = list(policy["input_object_ids"]) + [ref["object_id"] for ref in derived_refs]
            if not isinstance(inputs, list) or any(item not in authorized_ids for item in inputs):
                raise AuthorizationError("child inputs are outside parent policy")
            if len(inputs) > limits["max_child_inputs"]:
                raise ValidationError("child input count limit exceeded")
            if derived_refs:
                if [item for item in inputs if item in {ref["object_id"] for ref in derived_refs}] != [ref["object_id"] for ref in derived_refs]:
                    raise AuthorizationError("child inputs must consume the exact derived receipt")
                registry = self.store._spec(parent).get("derived_input_registry", {})
                for ref in derived_refs:
                    if registry.get(ref["object_id"]) != ref:
                        raise AuthorizationError("derived input receipt is not registered to the parent")
                    self._verify_derived_association(ref, parent, row, project)
                resolved_inputs = derived_refs
        else:
            if "input_object_ids" in task or not isinstance(stage_name, str):
                raise ValidationError("staged child requires stage and input_refs, not bare input_object_ids")
            stage_by_name = {item["name"]: (index, item) for index, item in enumerate(stages)}
            if stage_name not in stage_by_name:
                raise AuthorizationError("child stage is outside parent policy")
            index, stage = stage_by_name[stage_name]
            if {"capability_id": task["capability_id"], "capability_digest": task["capability_digest"]} != {"capability_id": stage["capability_id"], "capability_digest": stage["capability_digest"]}:
                raise AuthorizationError("child capability does not match declared stage")
            supplied_target = _normalize_execution_target(request.get("target")) if request is not None else {"kind": "default"}
            if supplied_target not in (stage["target"], effective_target):
                raise AuthorizationError("child target does not match declared stage")
            if "execution_request" in stage:
                if request is None or _normalize_execution_request(request, []) != stage["execution_request"]:
                    raise AuthorizationError("child execution request differs from its admitted stage")
                request = dict(stage["execution_request"])
            lineage_keys = {"parent_task_id": parent["id"], "parent_attempt_id": row["id"], "parent_lease_id": row["lease_id"], "parent_fence": int(row["fence"]), "runtime_epoch": int(row["runtime_epoch"]), "executor_id": row["executor_id"], "parent_placement": self._trusted_execution_placement(identity), "parent_effective_target": effective_target, "parent_placement_version": placement_version, "project_id": project}
            siblings = self._delegated_stage_rows(project, lineage_keys)
            existing = siblings.get(stage_name)
            if existing is not None:
                old_key = self.store.conn.execute("SELECT r.idempotency_key FROM runs r JOIN tasks t ON t.run_id=r.id WHERE t.id=?", (existing["id"],)).fetchone()[0]
                if old_key != idempotency_key:
                    raise ConflictError("delegated stage was already admitted")
            if any(item["name"] not in siblings or siblings[item["name"]]["status"] != "completed" for item in stages[:index]):
                raise ConflictError("delegated stages must be admitted once and completed in order")
            inputs, resolved_inputs = self._resolve_delegated_stage_inputs(stage["inputs"], task.get("input_refs"), siblings=siblings, project=project, lineage=lineage_keys)
            if len(inputs) > limits["max_child_inputs"]:
                raise ValidationError("child input count limit exceeded")
            final = policy.get("final_publication")
            if final is not None and stage_name == final["stage"]:
                verified_source = next(ref for ref in resolved_inputs if ref.get("producer_stage") == final["verify_stage"] and ref.get("output_port") == final["verify_output_port"])
                publication_effect = final["effect"]
            publications = policy.get("publications")
            if publications is not None:
                raw = publications["raw"]
                final = publications["final"]
                raw_consumer = (final["candidate_stage"] if final["candidate_stage"] != raw["stage"]
                                else final["verify_stage"])
                if stage_name == raw_consumer:
                    raw_task = siblings[raw["stage"]]
                    selected_raw = self._named_publication_association(raw_task, raw)
                    consumed = [ref for ref in resolved_inputs if ref.get("producer_stage") == raw["stage"]
                                and ref.get("output_port") == raw["output_port"]]
                    if sum(ref.get("association_id") == selected_raw["association_id"] for ref in consumed) != 1:
                        raise AuthorizationError("candidate lineage must consume the selected raw publication")
                for publication_name, publication in publications.items():
                    if stage_name == publication["stage"]:
                        publication_effect = publication["effect"]
                        verified_source = {"publication_name": publication_name, "output_port": publication["output_port"]}
                        if publication_name == "final":
                            candidate = next(ref for ref in resolved_inputs if ref.get("producer_stage") == publication["candidate_stage"] and ref.get("output_port") == publication["candidate_output_port"])
                            verification = next(ref for ref in resolved_inputs if ref.get("producer_stage") == publication["verify_stage"] and ref.get("output_port") == publication["verify_output_port"])
                            raw = publications["raw"]
                            raw_task = siblings[raw["stage"]]
                            raw_association = self._named_publication_association(raw_task, raw)
                            raw_source = {"producer_stage": raw["stage"], "producer_task_id": raw_task["id"], "producer_attempt_id": raw_task["attempt_id"], "association_id": raw_association["association_id"], "output_port": raw["output_port"], "object_id": raw_association["object_id"]}
                            if candidate["producer_task_id"] != raw_task["id"]:
                                candidate_task = self.store.conn.execute("SELECT * FROM tasks WHERE id=?", (candidate["producer_task_id"],)).fetchone()
                                if not any(ref.get("association_id") == raw_association["association_id"] for ref in self.store._spec(candidate_task).get("delegated_inputs", [])):
                                    raise AuthorizationError("candidate does not descend from the actual raw publication")
                            elif candidate["association_id"] != raw_association["association_id"]:
                                raise AuthorizationError("candidate substituted the raw publication")
                            verification_task = self.store.conn.execute("SELECT * FROM tasks WHERE id=?", (verification["producer_task_id"],)).fetchone()
                            if not any(ref.get("association_id") == candidate["association_id"] for ref in self.store._spec(verification_task).get("delegated_inputs", [])):
                                raise AuthorizationError("verification does not consume this candidate")
                            verified_source.update({"candidate": candidate, "verification": verification, "raw": raw_source, "raw_effect": raw["effect"]})
                            verified_source["raw_publication"] = self._read_delegated_publication(raw_source, raw["effect"], project)
                            publication_effect = self._bound_named_final_publication_effect(publication_effect, verified_source)
        target = _normalize_execution_target(request.get("target")) if isinstance(request, dict) else {"kind": "default"}
        derived_object_ids = {ref["object_id"] for ref in (resolved_inputs or []) if "association_id" in ref}
        total_input_bytes = 0
        for object_id in inputs:
            if not isinstance(object_id, str) or not re.fullmatch(r"sha256:[0-9a-f]{64}", object_id):
                raise ValidationError("delegated input object identity is invalid")
            obj = self.store.conn.execute("SELECT size FROM objects WHERE digest=?", (object_id[7:],)).fetchone()
            if obj is None:
                raise ConflictError("delegated input object is unavailable")
            if object_id in derived_object_ids:
                total_input_bytes += int(obj["size"])
        if total_input_bytes > limits["max_child_bytes"]:
            raise ValidationError("child input byte limit exceeded")
        if target not in policy["targets"] and target != effective_target:
            raise AuthorizationError("child target is outside parent policy")
        if stages is not None and request is not None:
            if "inputs" in request:
                raise ValidationError("staged child execution_request.inputs are resolved by Runtime")
            child_spec = task.get("spec", {})
            spec_inputs = child_spec.get("inputs") if isinstance(child_spec, dict) else None
            if not isinstance(spec_inputs, dict):
                raise ValidationError("staged child spec must declare its managed input descriptors")
            canonical_inputs = []
            for ref in resolved_inputs:
                name = ref["name"]
                descriptor = spec_inputs.get(name)
                if not isinstance(descriptor, dict):
                    raise ValidationError(
                        "staged child spec is missing its managed input descriptor",
                        details={"name": name},
                    )
                supplied_object_id = descriptor.get("object_id") or descriptor.get("digest")
                if supplied_object_id != ref["object_id"]:
                    raise AuthorizationError(
                        "staged child input descriptor disagrees with the Runtime-resolved object",
                        details={"name": name},
                    )
                filename = _canonical_execution_input_filename(
                    descriptor.get("filename"),
                    f"staged child input {name!r}.filename",
                )
                required = descriptor.get("required", True)
                if type(required) is not bool:
                    raise ValidationError(
                        f"staged child input {name!r}.required must be a boolean"
                    )
                canonical = {
                    "name": name,
                    "object_id": ref["object_id"],
                    "filename": filename,
                    "required": required,
                }
                digest = descriptor.get("digest")
                if digest is not None:
                    if digest != ref["object_id"]:
                        raise AuthorizationError(
                            "staged child input descriptor digest disagrees with the Runtime-resolved object",
                            details={"name": name},
                        )
                    canonical["digest"] = digest
                canonical_inputs.append(canonical)
            request = dict(request)
            request["inputs"] = canonical_inputs
        if request is not None:
            request = dict(request)
            # Supplied default is explicit; absent requests inherit below.
            # An admitted frozen stage keeps its exact request, while ordinary
            # children retain authorized parent-selector recovery projection.
            if (not (stages is not None and "execution_request" in stage)
                    and target["kind"] != "default" and recovery is not None
                    and target == recovery["original_target"]):
                target = effective_target or target
            request["target"] = target
        elif effective_target is not None:
            request = {"schema_version": 1, "target": effective_target}
        if derived_refs:
            if request is None:
                request = {"schema_version": 1, "target": {"kind": "default"}}
            descriptors = request.get("inputs")
            if not isinstance(descriptors, list):
                raise ValidationError("derived input child requires execution_request.inputs descriptors")
            for ref in derived_refs:
                matches = [item for item in descriptors if isinstance(item, dict) and item.get("object_id") == ref["object_id"]]
                if (len(matches) != 1 or matches[0].get("name") != ref["name"]
                        or matches[0].get("filename") != ref["filename"]
                        or matches[0].get("digest", ref["object_id"]) != ref["object_id"]):
                    raise AuthorizationError("derived execution input descriptor disagrees with its receipt")
        child_spec = task.get("spec", {})
        if not isinstance(child_spec, dict) or "runtime_dependencies" in child_spec:
            raise ValidationError("delegated child spec cannot use runtime_dependencies")
        lineage = {"parent_task_id": parent["id"], "parent_attempt_id": row["id"], "parent_lease_id": row["lease_id"], "parent_fence": int(row["fence"]), "runtime_epoch": int(row["runtime_epoch"]), "executor_id": row["executor_id"], "parent_placement": self._trusted_execution_placement(identity), "parent_effective_target": effective_target, "parent_placement_version": placement_version, "project_id": project}
        lineage["policy_digest"] = payload["policy_digest"]
        admitted = dict(task)
        admitted.pop("stage", None)
        admitted.pop("input_refs", None)
        admitted["input_object_ids"] = inputs
        if request is not None:
            admitted["execution_request"] = request
        if publication_effect is not None:
            admitted["settlement_effect"] = publication_effect
        admitted["project"] = project
        admitted["idempotency_key"] = idempotency_key
        recoverable = self._recoverable_child_grant(policy, task, lineage)
        return self.create_task(admitted, enforce_readiness=True, _delegated_lineage=lineage, _delegated_stage=stage_name, _delegated_inputs=resolved_inputs, _verified_publication_source=verified_source, _recoverable_outputs=recoverable)

    @staticmethod
    def _recoverable_child_grant(policy, task, lineage):
        grant = next((item for item in policy.get("recoverable_outputs", [])
                      if all(item[key] == task[key] for key in ("capability_id", "capability_digest"))), None)
        if grant is None:
            return None
        return {**grant, "limits": {key: policy["limits"][key] for key in (
            "max_recoverable_snapshots", "max_recoverable_bytes", "max_snapshot_bytes")},
            "parent_attempt_id": lineage["parent_attempt_id"], "policy_digest": lineage["policy_digest"]}

    @_durable_mutation
    def publish_recoverable_snapshot(self, attempt_id, body, *, idempotency_key, identity):
        """Commit an opaque child draft; this never settles either attempt."""
        body = _wire_object(body, required=("lease_id", "fence", "runtime_epoch", "revision", "output"),
                            allowed=("lease_id", "fence", "runtime_epoch", "revision", "output"))
        _wire_string(body, "lease_id")
        for key in ("fence", "runtime_epoch", "revision"):
            _wire_integer(body, key, positive=True)
        if body["revision"] > 9007199254740991:
            raise ValidationError("snapshot revision exceeds the portable integer bound")
        item = _wire_object(body["output"], required=("name", "output_port", "filename", "object_id", "size", "media_type"),
                            allowed=("name", "output_port", "filename", "object_id", "size", "media_type"))
        for key in ("name", "output_port", "media_type"):
            _wire_string(item, key)
            if len(item[key]) > 255 or any(ord(c) < 32 for c in item[key]):
                raise ValidationError("snapshot metadata is invalid")
        _canonical_execution_input_filename(item["filename"], "snapshot filename")
        _wire_integer(item, "size")
        if (item["size"] < 0 or item["size"] > OBJECT_MAX_BYTES
                or not isinstance(item["object_id"], str) or not re.fullmatch(r"sha256:[0-9a-f]{64}", item["object_id"])):
            raise ValidationError("snapshot object identity or size is invalid")
        idempotency_key = require_idempotency_key(idempotency_key)
        if identity is None:
            raise AuthorizationError("authenticated snapshot worker identity is required")
        attempt = self.store.conn.execute("SELECT * FROM attempts WHERE id=?", (attempt_id,)).fetchone()
        self._assert_attempt_identity(attempt, identity)
        # Historical fence facts remain necessary for receipt recovery, but a
        # replay does not require that the old lease or epoch is still live.
        if (not attempt or attempt["lease_id"] != body["lease_id"]
                or int(attempt["fence"]) != body["fence"] or int(attempt["runtime_epoch"]) != body["runtime_epoch"]):
            raise LeaseError("snapshot attempt fence does not match")
        task = self.store.conn.execute("SELECT * FROM tasks WHERE id=?", (attempt["task_id"],)).fetchone()
        spec = self.store._spec(task)
        project = self.store.conn.execute("SELECT project_id FROM runs WHERE id=?", (task["run_id"],)).fetchone()[0]
        kind = "attempt.recoverable_snapshot.publish"
        request_hash = sha256_bytes(canonical_json(body).encode())
        alias_kind = "attempt.recoverable_snapshot.replay"
        alias = self._command_replay(alias_kind, attempt_id, idempotency_key, request_hash, with_receipt=False)
        if alias is not None:
            return alias
        replay = self._command_replay(kind, attempt_id, idempotency_key, request_hash, project_id=project)
        if replay is not None:
            return replay
        prior = self.store.recoverable_snapshots(attempt_id=attempt_id, output_port=item["output_port"])
        same = next((a for a in prior if a["provenance"]["revision"] == body["revision"]), None)
        if same is not None:
            original_key = same["provenance"]["idempotency_key"]
            original = self._command_replay(kind, attempt_id, original_key, request_hash, project_id=project)
            # Bind an alternate replay key without another publication receipt,
            # event, association or quota charge, even after authority closes.
            return self._command_record(alias_kind, attempt_id, idempotency_key, request_hash, original, with_receipt=False)
        self._validate_attempt_lease(attempt, body, self.store._current_runtime_epoch())
        if (task["status"] != "running" or task["attempt_id"] != attempt_id
                or task["lease_token"] != body["lease_id"] or int(task["lease_fence"]) != body["fence"]
                or task["executor_id"] != attempt["executor_id"] or int(task["runtime_epoch"]) != body["runtime_epoch"]):
            raise LeaseError("snapshot producing child is no longer live")
        lineage = spec.get("delegated_parent")
        frozen = spec.get("delegated_recoverable_outputs")
        if not isinstance(lineage, dict) or not isinstance(frozen, dict) or project is None:
            raise AuthorizationError("child has no admitted recoverable output grant")
        parent_attempt, parent, parent_project, policy = self._live_delegating_parent(
            lineage["parent_attempt_id"], {"lease_id": lineage["parent_lease_id"],
            "fence": lineage["parent_fence"], "runtime_epoch": lineage["runtime_epoch"]}, identity=None)
        recovery = self.store.placement_recovery(parent["id"])
        if (parent["id"] != lineage["parent_task_id"] or parent_project != project or lineage["project_id"] != project
                or parent_attempt["executor_id"] != lineage["executor_id"]
                or self.store.effective_execution_target(parent["id"]) != lineage["parent_effective_target"]
                or int(recovery.get("placement_version", 0) if recovery else 0) != lineage["parent_placement_version"]
                or sha256_bytes(canonical_json(policy).encode()) != lineage["policy_digest"]
                or frozen != self._recoverable_child_grant(policy, {"capability_id": task["capability"],
                    "capability_digest": spec["capability_digest"]}, lineage)
                or item["output_port"] not in frozen["output_ports"]):
            raise AuthorizationError("snapshot grant or parent lineage does not match")
        if prior and body["revision"] <= max(a["provenance"]["revision"] for a in prior):
            raise ConflictError("snapshot revision is stale")
        limits = frozen["limits"]
        committed = self.store.recoverable_snapshots(parent_attempt_id=lineage["parent_attempt_id"])
        if (item["size"] > limits["max_snapshot_bytes"]
                or len(committed) >= limits["max_recoverable_snapshots"]
                or sum(a["size"] for a in committed) + item["size"] > limits["max_recoverable_bytes"]):
            raise ValidationError("recoverable snapshot count or byte limit exceeded")
        digest = item["object_id"][7:]
        if not self._is_authorized_generic_output(digest, item["size"], item["media_type"], name=item["name"],
                output_port=item["output_port"], filename=item["filename"], recorded_filename=item["filename"],
                attempt_row=attempt, task_row=task, project_id=project, lease_body=body):
            raise AuthorizationError("snapshot requires the producing child's authenticated upload receipt")
        obj = self.store.conn.execute("SELECT size, media_type FROM objects WHERE digest=?", (digest,)).fetchone()
        if obj is None or int(obj["size"]) != item["size"] or obj["media_type"] != item["media_type"]:
            raise ConflictError("snapshot object metadata does not match upload")
        self._verify_child_object_bytes(digest, item["size"], label="snapshot CAS object")
        self.store.conn.execute("INSERT OR IGNORE INTO project_objects(project_id, digest, relation, created_at) VALUES (?, ?, 'managed', ?)", (project, digest, now()))
        output = {**item, "digest": item["object_id"], "kind": "object", "role": "recoverable_snapshot",
                  "group_key": "recoverable-" + attempt_id, "variant_key": str(body["revision"]),
                  "provenance": {"parent_attempt_id": lineage["parent_attempt_id"],
                    "revision": body["revision"], "idempotency_key": idempotency_key}}
        association = self.store._associate_managed_outputs({"outputs": [output]}, task_id=task["id"],
                        attempt_id=attempt_id, project_id=project)[0]
        event = self.store._append_event(task["run_id"], task["id"], "attempt.recoverable_snapshot_published",
                        {"association_id": association["association_id"], "revision": body["revision"]})
        return self._command_record(kind, attempt_id, idempotency_key, request_hash, association,
                                    project_id=project, event_ids=(event,))

    def task(self, task_id):
        self.store.reap_overdue_leases()
        return self.store.get_task(task_id)

    @_verified_mutation
    def reap_task_lifetimes(self):
        """Run the existing claim/read reaper from the server's poll hook."""
        self.store.reap_overdue_leases()

    def managed_outputs(self, task_id):
        """Read Runtime-owned immutable output associations and lifecycle state."""
        return self.store.list_managed_outputs(task_id)

    def managed_output_page(self, task_id):
        """Return the public task-scoped managed-output collection."""
        self.store.get_task(str(task_id))
        return {"items": self.store.list_managed_outputs(task_id), "next_cursor": None}

    def managed_output(self, association_id):
        """Read one named managed association without exposing CAS or SQLite."""
        return self.store.get_managed_output(association_id)

    def _export_source(self, association_id):
        """Resolve one retained output and validate its historical fence facts."""
        association = self.store.get_managed_output(association_id)
        if association.get("durability") != "durable":
            raise ConflictError("only durable managed outputs may be exported")
        attempt = self.store.conn.execute(
            "SELECT id, task_id, lease_id, fence, executor_id, runtime_epoch, settled FROM attempts WHERE id=?",
            (str(association["attempt_id"]),),
        ).fetchone()
        if not attempt or str(attempt["task_id"]) != str(association["task_id"]):
            raise ConflictError("managed output attempt provenance is unavailable")
        if not int(attempt["settled"]):
            raise ConflictError("managed output attempt is not completed")
        run = self.store.conn.execute(
            "SELECT id, project_id FROM runs WHERE id=?",
            (str(association["run_id"]),),
        ).fetchone()
        if not run or run["project_id"] != association.get("project_id"):
            raise ConflictError("managed output run/project provenance is inconsistent")
        provenance = association.get("provenance") or {}
        if not isinstance(provenance, dict):
            raise ConflictError("managed output provenance is malformed")
        for field, expected in (
            ("task_id", association["task_id"]),
            ("attempt_id", association["attempt_id"]),
            ("executor_id", attempt["executor_id"]),
            ("fence", int(attempt["fence"])),
            ("runtime_epoch", int(attempt["runtime_epoch"])),
        ):
            if field in provenance and provenance[field] != expected:
                raise ConflictError("managed output historical provenance is inconsistent", details={"field": field})
        if not attempt["lease_id"] or not attempt["executor_id"] or int(attempt["fence"]) < 1 or int(attempt["runtime_epoch"]) < 1:
            raise ConflictError("managed output attempt fence provenance is incomplete")
        digest = str(association["digest"])
        if not digest.startswith("sha256:"):
            raise ConflictError("managed output digest is not canonical")
        raw_digest = digest.removeprefix("sha256:")
        object_row = self.store.conn.execute(
            "SELECT size FROM objects WHERE digest=?",
            (raw_digest,),
        ).fetchone()
        if not object_row:
            raise ConflictError("managed output CAS object is unavailable")
        data = self.cas.read(raw_digest)
        if len(data) != int(association["size"]) or len(data) != int(object_row["size"]):
            raise ConflictError("managed output CAS size does not match its association")
        try:
            export_filename = _canonical_managed_output_filename(str(association["filename"]))
        except ValidationError as exc:
            raise ConflictError("managed output filename is not a direct safe file name") from exc
        return association, attempt, data, export_filename

    def _ensure_export_root(self) -> Path:
        """Use the configured export root, else default to ~/Downloads/Astrid exports (created on demand)."""
        if self.export_root is not None:
            return self.export_root
        default = Path.home() / "Downloads" / "Astrid exports"
        try:
            default.mkdir(parents=True, exist_ok=True)
            resolved = default.resolve()
        except OSError as exc:
            raise ConflictError("managed-output default export folder is unavailable") from exc
        if resolved == self.store.root or resolved.is_relative_to(self.store.root) or self.store.root.is_relative_to(resolved):
            raise ConflictError("managed-output export root must be outside the active realm root")
        if default.is_symlink() or not resolved.is_dir():
            raise ConflictError("managed-output default export folder must be an ordinary directory")
        self.export_root = resolved
        return resolved

    def _materialize_export(self, filename, data):
        export_root = self._ensure_export_root()
        if len(str(filename).encode("utf-8")) > self._export_leaf_max_bytes():
            raise ConflictError("managed-output export destination filename is too long")
        identity, root_fd, _ = _pin_directory(export_root)
        temporary = f".{filename}.{os.getpid()}-{uuid.uuid4().hex}.tmp"
        fd = -1
        try:
            fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600, dir_fd=root_fd)
            view = memoryview(data)
            while view:
                written = os.write(fd, view)
                view = view[written:]
            os.fsync(fd)
            os.close(fd)
            fd = -1
            try:
                os.link(temporary, filename, src_dir_fd=root_fd, dst_dir_fd=root_fd, follow_symlinks=False)
            except FileExistsError as exc:
                raise ConflictError("managed-output export destination already exists") from exc
            os.unlink(temporary, dir_fd=root_fd)
            os.fsync(root_fd)
        finally:
            if fd >= 0:
                os.close(fd)
            try:
                os.unlink(temporary, dir_fd=root_fd)
            except FileNotFoundError:
                pass
            _close_pinned(identity)
            os.close(root_fd)

    def _export_leaf_max_bytes(self):
        """Return the safe direct-leaf budget including the temporary file name."""
        try:
            name_max = int(os.pathconf(self.export_root, "PC_NAME_MAX"))
        except (OSError, TypeError, ValueError):
            name_max = 255
        # _materialize_export writes .<leaf>.<pid>-<uuid>.tmp before linking
        # the final leaf. Reserve the complete fixed suffix so a valid final
        # name cannot fail only because its private staging sibling is longer.
        temporary_suffix = f"..{os.getpid()}-{'0' * 32}.tmp"
        return max(1, name_max - len(temporary_suffix.encode("utf-8")))

    @staticmethod
    def _truncate_utf8(value, limit):
        raw = str(value).encode("utf-8")
        if len(raw) <= limit:
            return str(value)
        truncated = raw[:limit].decode("utf-8", "ignore")
        return truncated or "output"

    def _collision_safe_export_filename(self, association_id, filename):
        """Return a deterministic direct-leaf fallback under the export root."""
        prefix = f"{association_id}--"
        filename = str(filename)
        if filename.startswith(prefix):
            filename = filename[len(prefix):]
        counter = 1
        while True:
            suffix = "" if counter == 1 else f"--{counter}"
            available = self._export_leaf_max_bytes() - len((prefix + suffix).encode("utf-8"))
            base = self._truncate_utf8(filename, max(1, available))
            candidate = f"{prefix}{base}{suffix}"
            if not os.path.lexists(self.export_root / candidate):
                return candidate
            counter += 1

    @_durable_mutation
    def export_managed_output(self, association_id, body, *, idempotency_key=None):
        """Materialize exact CAS bytes for one completed retained output."""
        idempotency_key = require_idempotency_key(idempotency_key)
        export_root = self._ensure_export_root()
        body = _wire_object(body, required=("destination_filename",), allowed=("destination_filename", "expected"))
        destination_filename = _wire_string(body, "destination_filename")
        expected = body.get("expected") or {}
        if not isinstance(expected, dict):
            raise ValidationError("expected export identity must be an object")
        allowed_expected = {
            "project_id", "run_id", "task_id", "attempt_id", "executor_id", "lease_id", "fence",
            "runtime_epoch", "association_id", "output_port", "role", "object_id", "digest", "size",
            "filename", "media_type",
        }
        unknown = sorted(set(expected) - allowed_expected)
        if unknown:
            raise ValidationError("expected export identity contains unsupported fields", details={"fields": unknown})
        association, attempt, data, export_filename = self._export_source(association_id)
        if destination_filename not in {association["filename"], export_filename}:
            raise ConflictError("export destination filename must equal managed output filename")
        source = {
            "project_id": association.get("project_id"),
            "run_id": association["run_id"], "task_id": association["task_id"],
            "attempt_id": association["attempt_id"], "executor_id": attempt["executor_id"],
            "lease_id": attempt["lease_id"], "fence": int(attempt["fence"]),
            "runtime_epoch": int(attempt["runtime_epoch"]), "association_id": association["association_id"],
            "output_port": association["output_port"], "role": association["role"],
            "object_id": association["object_id"], "digest": association["digest"],
            "size": int(association["size"]), "filename": association["filename"],
            "media_type": association["media_type"],
        }
        for field, value in expected.items():
            if field == "filename" and value == export_filename:
                continue
            if value != source[field]:
                raise ConflictError("export identity assertion does not match", details={"field": field})
        request_hash = hashlib.sha256(canonical_json({"association_id": str(association_id), "body": body}).encode()).hexdigest()
        project_id = association.get("project_id") or "unscoped"
        replay = self._command_replay("managed_output.export", str(association_id), idempotency_key, request_hash, project_id=project_id)
        if replay is not None:
            return replay
        destination_export_filename = export_filename
        if (
            len(destination_export_filename.encode("utf-8")) > self._export_leaf_max_bytes()
            or os.path.lexists(export_root / destination_export_filename)
        ):
            destination_export_filename = self._collision_safe_export_filename(
                association["association_id"], export_filename
            )
        for _attempt in range(100):
            try:
                self._materialize_export(destination_export_filename, data)
                break
            except ConflictError as exc:
                if "destination already exists" not in str(exc):
                    raise
                destination_export_filename = self._collision_safe_export_filename(
                    association["association_id"], export_filename
                )
        else:
            raise ConflictError("managed-output export could not allocate a collision-safe destination")
        result = {
            "export_id": "export-" + new_id(),
            **source,
            "producer": association.get("producer") or {},
            "destination": {"root": str(export_root), "filename": destination_export_filename},
            "source_provenance": association.get("provenance") or {},
            "exported_at": now(),
        }
        event_id = self.store._append_event(
            association["run_id"], association["task_id"], "managed_output.exported", result,
        )
        event_seq = self.store.conn.execute("SELECT COUNT(*) FROM events WHERE run_id=?", (association["run_id"],)).fetchone()[0]
        return self._command_record(
            "managed_output.export", str(association_id), idempotency_key, request_hash,
            result, project_id=project_id, event_ids=(event_id,), primary_stream_id=association["run_id"],
            resulting_stream_seq=event_seq,
        )

    @_durable_mutation
    def adopt_managed_output(self, association_id, body=None, *, idempotency_key=None):
        """Acknowledge/adopt an existing immutable association by managed name.

        Adoption never creates a second association or resolves a filesystem
        path. Optional identity fields are equality assertions against the
        Runtime-owned association, making a changed payload a conflict while
        preserving the durable receipt for an exact retry.
        """
        idempotency_key = require_idempotency_key(idempotency_key)
        body = {} if body is None else _wire_object(body, allowed=(
            "association_id", "manifest_ref", "object_id", "digest", "size",
            "filename", "media_type", "output_port", "selector", "ordinal",
            "role", "durability",
        ))
        association = self.store.get_managed_output(association_id)
        if body.get("association_id") is not None and str(body["association_id"]) != str(association_id):
            raise ConflictError("association_id does not match the managed-output path")
        for field in (
            "manifest_ref", "object_id", "digest", "size", "filename", "media_type",
            "output_port", "selector", "ordinal", "role", "durability",
        ):
            if field in body and body[field] != association.get(field):
                raise ConflictError("managed-output adoption identity does not match", details={"field": field})
        request_hash = hashlib.sha256(canonical_json({"association_id": str(association_id), "body": body}).encode()).hexdigest()
        project_id = association.get("project_id") or "unscoped"
        replay = self._command_replay("managed_output.adopt", str(association_id), idempotency_key, request_hash, project_id=project_id)
        if replay is not None:
            return replay
        return self._command_record(
            "managed_output.adopt", str(association_id), idempotency_key, request_hash,
            association, project_id=project_id,
        )

    @_durable_mutation
    def update_managed_output_lifecycle(self, association_id, body, *, idempotency_key=None):
        """Mutate only Runtime lifecycle state for one immutable association."""
        idempotency_key = require_idempotency_key(idempotency_key)
        body = _wire_object(
            body,
            required=("operation", "expected_version"),
            allowed=("operation", "expected_version", "lease_id", "lease_owner", "lease_seconds", "provenance"),
        )
        operation = _wire_string(body, "operation")
        _wire_integer(body, "expected_version", positive=True)
        if "lease_id" in body and (not isinstance(body["lease_id"], str) or not body["lease_id"]):
            raise ValidationError("lease_id must be a non-empty string")
        if "lease_owner" in body and (not isinstance(body["lease_owner"], str) or not body["lease_owner"]):
            raise ValidationError("lease_owner must be a non-empty string")
        if "lease_seconds" in body and (
            isinstance(body["lease_seconds"], bool) or not isinstance(body["lease_seconds"], int)
            or body["lease_seconds"] <= 0
        ):
            raise ValidationError("lease_seconds must be a positive integer")
        if "provenance" in body and not isinstance(body["provenance"], dict):
            raise ValidationError("lifecycle provenance must be an object")
        association = self.store.get_managed_output(association_id)
        project_id = association.get("project_id") or "unscoped"
        request_hash = hashlib.sha256(canonical_json({"association_id": str(association_id), "body": body}).encode()).hexdigest()
        replay = self._command_replay("managed_output.lifecycle", str(association_id), idempotency_key, request_hash, project_id=project_id)
        if replay is not None:
            return replay
        result = self.store.update_managed_output_lifecycle(
            association_id, operation, expected_version=body["expected_version"],
            lease_id=body.get("lease_id"), lease_owner=body.get("lease_owner"),
            lease_seconds=body.get("lease_seconds"),
        )
        if "provenance" in body:
            result["lifecycle_provenance"] = dict(body["provenance"])
        return self._command_record(
            "managed_output.lifecycle", str(association_id), idempotency_key, request_hash,
            result, project_id=project_id,
        )

    def run(self, run_id):
        self.store.reap_overdue_leases()
        row = self.store.conn.execute("SELECT * FROM runs WHERE id=?", (run_id,)).fetchone()
        if not row:
            raise NotFoundError("run not found")
        value = dict(row)
        if value["spec_digest"] is None:
            value["spec_retired"] = True
        value["spec"], generation_intent = public_task_spec(self.store._load_spec(value.pop("spec_digest")))
        if generation_intent is not None:
            value["generation_intent"] = generation_intent
        value["task_ids"] = [task["id"] for task in self.store.conn.execute("SELECT id FROM tasks WHERE run_id=? ORDER BY created_at, id", (run_id,))]
        return value

    def _task_resource(self, value, *, progress=None, related_loaded=False):
        task, run = value["task"], value["run"]
        spec, generation_intent = public_task_spec(task.get("spec", {}))
        if task.get("generation_intent") is not None:
            generation_intent = task["generation_intent"]
        resource = {"task_id": task["id"], "run_id": run["id"], "project_id": run.get("project_id"), "state": "succeeded" if task["status"] == "completed" else ("cancelled" if task["status"] == "cancelled" else task["status"]), "version": int(task.get("attempt", 0)) + 1, "capability_id": task["capability"], "capability_digest": task.get("capability_digest") or spec.get("capability_digest", "sha256:" + hashlib.sha256(task["capability"].encode()).hexdigest()), "schema_version": spec.get("schema_version", "1"), "input_object_ids": spec.get("input_object_ids", []), "spec": spec, "idempotency_key": run.get("idempotency_key") or task["id"], "created_at": task["created_at"], "updated_at": task["updated_at"], "attempt_id": task.get("attempt_id"), "runtime_epoch": int(task.get("runtime_epoch") or self.store._current_runtime_epoch())}
        if task.get("execution_request") is not None:
            resource["execution_request"] = dict(task["execution_request"])
        binding = value.get("execution_binding")
        if binding is None and not related_loaded:
            binding = self.store.execution_binding(task["id"])
        if binding is not None:
            resource["execution_binding"] = binding
        if generation_intent is not None:
            resource["generation_intent"] = generation_intent
        if task.get("expected_effect") is not None:
            resource["expected_effect"] = dict(task["expected_effect"])
        if "required_facts" in spec:
            resource["required_facts"] = dict(spec["required_facts"])
        if "storage_estimate" in spec:
            resource["storage_estimate"] = dict(spec["storage_estimate"])
        if task.get("waiting_reason"):
            resource["waiting_reason"] = task["waiting_reason"]
        if task.get("lease_fence"):
            resource["lease_fence"] = task["lease_fence"]
        if task.get("lease_expires_at"):
            resource["lease_expires_at"] = task["lease_expires_at"]
        if task.get("result") is not None:
            resource["result"] = task["result"]
        if not related_loaded:
            row = self.store.conn.execute(
                "SELECT payload_json FROM events WHERE task_id=? AND kind='task.progress' ORDER BY id DESC LIMIT 1",
                (task["id"],),
            ).fetchone()
            progress = json.loads(row["payload_json"]) if row else None
        if isinstance(progress, dict):
            resource["progress"] = progress
        return resource

    @staticmethod
    def _require_placement_recovery_owner(identity):
        scopes = set(identity.get("scopes", [])) if isinstance(identity, dict) else set()
        actor = identity.get("actor") if isinstance(identity, dict) else None
        if not isinstance(actor, str) or not actor or "admin" not in scopes:
            raise AuthorizationError("placement recovery requires owner authority")
        return actor

    @staticmethod
    def _placement_evidence_digest(value, field):
        if not isinstance(value, str) or not re.fullmatch(r"sha256:[0-9a-f]{64}", value):
            raise ValidationError(f"{field} must be a sha256 digest")
        return value

    def _validate_placement_loss_evidence(self, value, *, current_target):
        value = _wire_object(
            value,
            required=(
                "source", "status", "target", "observed_at",
                "evidence_digest", "no_active_work",
            ),
            allowed=(
                "source", "status", "target", "observed_at",
                "evidence_digest", "no_active_work",
            ),
        )
        if not isinstance(value["source"], str) or not value["source"].strip():
            raise ValidationError("loss_evidence.source is required")
        if value["status"] != "absent":
            raise ConflictError("old placement loss is not established")
        if value["no_active_work"] is not True:
            raise ConflictError("old placement has unknown active work")
        target = _normalize_execution_target(value["target"])
        if target != current_target:
            raise ConflictError(
                "loss evidence does not match the current effective placement",
                details={"expected": current_target, "actual": target},
            )
        observed_at = value["observed_at"]
        if not isinstance(observed_at, str) or not observed_at:
            raise ValidationError("loss_evidence.observed_at is required")
        try:
            observed = datetime.fromisoformat(observed_at.replace("Z", "+00:00"))
        except ValueError as exc:
            raise ValidationError("loss_evidence.observed_at is invalid") from exc
        if observed.tzinfo is None:
            raise ValidationError("loss_evidence.observed_at must include a timezone")
        age = (datetime.now(timezone.utc) - observed.astimezone(timezone.utc)).total_seconds()
        if age < -60 or age > PLACEMENT_LOSS_EVIDENCE_MAX_AGE_SECONDS:
            raise ConflictError(
                "loss evidence is stale",
                details={"maximum_age_seconds": PLACEMENT_LOSS_EVIDENCE_MAX_AGE_SECONDS},
            )
        return {
            "source": value["source"].strip(),
            "status": "absent",
            "target": target,
            "observed_at": observed_at,
            "evidence_digest": self._placement_evidence_digest(
                value["evidence_digest"], "loss_evidence.evidence_digest"
            ),
            "no_active_work": True,
        }

    def _validate_replacement_qualification(self, value, *, replacement_target):
        value = _wire_object(
            value,
            required=("target", "verified", "evidence_digest", "executor_incarnation"),
            allowed=("target", "verified", "evidence_digest", "executor_incarnation"),
        )
        target = _normalize_execution_target(value["target"])
        if target != replacement_target:
            raise ConflictError(
                "replacement qualification targets a different placement",
                details={"expected": replacement_target, "actual": target},
            )
        if value["verified"] is not True:
            raise AuthorizationError("replacement placement is not qualified")
        incarnation = value["executor_incarnation"]
        if not isinstance(incarnation, str) or not incarnation.strip() or len(incarnation) > 256:
            raise ValidationError("qualification.executor_incarnation is invalid")
        return {
            "target": target,
            "verified": True,
            "evidence_digest": self._placement_evidence_digest(
                value["evidence_digest"], "qualification.evidence_digest"
            ),
            "executor_incarnation": incarnation.strip(),
        }

    def _delegated_children(self, parent_task_id):
        children = []
        for row in self.store.conn.execute(
            "SELECT id, run_id, status, waiting_reason, attempt_id, spec_digest "
            "FROM tasks ORDER BY rowid"
        ).fetchall():
            try:
                lineage = self.store._spec(row).get("delegated_parent")
            except (TypeError, json.JSONDecodeError):
                continue
            if isinstance(lineage, dict) and lineage.get("parent_task_id") == parent_task_id:
                children.append((row, lineage))
        return children

    def _assert_placement_recovery_quiescent(self, task, children):
        if task["status"] not in {"failed", "cancelled"}:
            raise ConflictError(
                "task must be terminal before placement recovery",
                details={"status": task["status"]},
            )
        if task["waiting_reason"] == "provider_state_unknown":
            raise ConflictError("old placement has unknown active work")
        unsettled = self.store.conn.execute(
            "SELECT id FROM attempts WHERE task_id=? AND settled=0 ORDER BY rowid",
            (task["id"],),
        ).fetchall()
        if unsettled:
            raise ConflictError(
                "old placement has unknown active work",
                details={"attempt_ids": [row["id"] for row in unsettled]},
            )
        if self.store.conn.execute(
            "SELECT 1 FROM reservations WHERE task_id=? AND released_at IS NULL LIMIT 1",
            (task["id"],),
        ).fetchone():
            raise ConflictError("old placement still owns an active reservation")
        binding = self.store.execution_binding(task["id"])
        if binding is None:
            raise ConflictError("task has no targeted execution binding")
        if binding["status"] == "claimed":
            raise ConflictError("old placement still has a claimed execution binding")
        for child, _lineage in children:
            child_unsettled = self.store.conn.execute(
                "SELECT id FROM attempts WHERE task_id=? AND settled=0 ORDER BY rowid",
                (child["id"],),
            ).fetchall()
            child_binding = self.store.execution_binding(child["id"])
            if (
                child["status"] in {"running", "cancel_requested"}
                or child["waiting_reason"] == "provider_state_unknown"
                or child_unsettled
                or (child_binding is not None and child_binding["status"] == "claimed")
                or self.store.conn.execute(
                    "SELECT 1 FROM reservations WHERE task_id=? AND released_at IS NULL LIMIT 1",
                    (child["id"],),
                ).fetchone()
            ):
                raise ConflictError(
                    "delegated child has unknown active work",
                    details={"child_task_id": child["id"]},
                )
        return binding

    @_durable_mutation
    def recover_task_placement(self, task_id, body, *, idempotency_key=None, identity=None):
        """Authorize one exact effective-placement revision without rewriting admission."""
        actor = self._require_placement_recovery_owner(identity)
        idempotency_key = require_idempotency_key(idempotency_key)
        body = _wire_object(
            body,
            required=(
                "schema_version", "expected_task_version", "expected_placement_version",
                "expected_original_target", "expected_current_target", "replacement_target",
                "reason", "loss_evidence", "qualification",
            ),
            allowed=(
                "schema_version", "expected_task_version", "expected_placement_version",
                "expected_original_target", "expected_current_target", "replacement_target",
                "reason", "loss_evidence", "qualification",
            ),
        )
        if body["schema_version"] != PLACEMENT_RECOVERY_SCHEMA_VERSION:
            raise ValidationError("placement recovery schema_version is unsupported")
        for field in ("expected_task_version", "expected_placement_version"):
            if isinstance(body[field], bool) or not isinstance(body[field], int) or body[field] < 0:
                raise ValidationError(f"{field} must be a non-negative integer")
        reason = body["reason"]
        if not isinstance(reason, str) or not reason.strip() or len(reason) > 1024:
            raise ValidationError("placement recovery reason is invalid")
        request_hash = hashlib.sha256(
            canonical_json({"task_id": str(task_id), "body": body}).encode()
        ).hexdigest()
        current = self.store.get_task(task_id)
        project_id = current["run"].get("project_id") or "unscoped"
        replay = self._command_replay(
            "task.placement_recover", str(task_id), idempotency_key, request_hash,
            project_id=project_id,
        )
        if replay is not None:
            return replay
        task = self.store.conn.execute("SELECT * FROM tasks WHERE id=?", (str(task_id),)).fetchone()
        request = self.store._execution_request_from_row(task)
        if request is None:
            raise ConflictError("placement recovery requires a targeted task")
        original_target = _normalize_execution_target(body["expected_original_target"])
        if original_target != request["target"]:
            raise ConflictError("original immutable placement does not match admission")
        latest = self.store.placement_recovery(task_id)
        placement_version = int(latest.get("placement_version", 0)) if latest else 0
        current_target = self.store.effective_execution_target(task_id)
        expected_current = _normalize_execution_target(body["expected_current_target"])
        if expected_current != current_target:
            raise ConflictError(
                "current effective placement changed",
                details={"expected": expected_current, "actual": current_target},
            )
        if body["expected_placement_version"] != placement_version:
            raise ConflictError(
                "stale placement version",
                details={"expected": body["expected_placement_version"], "actual": placement_version},
            )
        task_version = int(task["attempt"] or 0) + 1
        if body["expected_task_version"] != task_version:
            raise ConflictError(
                "stale task version",
                details={"expected": body["expected_task_version"], "actual": task_version},
            )
        replacement = _normalize_execution_target(body["replacement_target"])
        if current_target.get("kind") != "runpod" or replacement.get("kind") != "runpod":
            raise ValidationError("placement recovery currently supports exact RunPod targets")
        if replacement["provider_account_ref"] != current_target["provider_account_ref"]:
            raise AuthorizationError("replacement target belongs to a different provider account")
        if replacement == current_target:
            raise ConflictError("replacement target must differ from the lost placement")
        loss = self._validate_placement_loss_evidence(
            body["loss_evidence"], current_target=current_target
        )
        qualification = self._validate_replacement_qualification(
            body["qualification"], replacement_target=replacement
        )
        children = self._delegated_children(str(task_id))
        binding = self._assert_placement_recovery_quiescent(task, children)
        timestamp = now()
        decision = {
            "schema_version": PLACEMENT_RECOVERY_SCHEMA_VERSION,
            "placement_version": placement_version + 1,
            "task_id": str(task_id),
            "run_id": current["run"]["id"],
            "task_version": task_version,
            "original_target": request["target"],
            "previous_effective_target": current_target,
            "replacement_target": replacement,
            "reason": reason.strip(),
            "owner_actor": actor,
            "loss_evidence": loss,
            "qualification": qualification,
            "superseded_binding": {
                "binding_id": binding["binding_id"],
                "attempt_id": binding.get("attempt_id"),
                "lease_id": binding.get("lease_id"),
                "fence": int(binding.get("fence") or 0),
                "executor_id": binding.get("executor_id"),
                "executor_incarnation": binding.get("executor_incarnation"),
            },
            "created_at": timestamp,
        }
        decision["decision_digest"] = "sha256:" + sha256_bytes(
            canonical_json(decision).encode()
        )
        event_ids = []
        for child, lineage in children:
            if child["status"] == "queued":
                self.store.conn.execute(
                    "UPDATE tasks SET status='cancelled', waiting_reason='parent_placement_recovered', "
                    "lease_token=NULL, executor_id=NULL, lease_expires_at=NULL, updated_at=? WHERE id=?",
                    (timestamp, child["id"]),
                )
                self.store.conn.execute(
                    "UPDATE runs SET status='cancelled', updated_at=? WHERE id=?",
                    (timestamp, child["run_id"]),
                )
                self.store.conn.execute(
                    "UPDATE execution_bindings SET status='stale', updated_at=? "
                    "WHERE task_id=? AND status='prepared'",
                    (timestamp, child["id"]),
                )
            event_ids.append(self.store._append_event(
                child["run_id"], child["id"], "task.parent_placement_fenced",
                {
                    "parent_task_id": str(task_id),
                    "parent_attempt_id": lineage.get("parent_attempt_id"),
                    "placement_version": placement_version + 1,
                    "replacement_target": replacement,
                },
            ))
        updated = self.store.conn.execute(
            "UPDATE execution_bindings SET attempt_id=NULL, lease_id=NULL, fence=0, "
            "executor_id=NULL, session_id=(SELECT boot_id FROM runtime_lifecycle WHERE id=1), "
            "runtime_epoch=?, resolved_target_json=?, status='prepared', updated_at=? "
            "WHERE task_id=? AND status IN ('prepared', 'released', 'stale')",
            (
                self.store._current_runtime_epoch(),
                canonical_json({"selected": replacement}),
                timestamp,
                str(task_id),
            ),
        )
        if updated.rowcount != 1:
            raise ConflictError("execution binding changed during placement recovery")
        self.store.conn.execute(
            "UPDATE tasks SET updated_at=? WHERE id=?", (timestamp, str(task_id))
        )
        parent_event = self.store._append_event(
            current["run"]["id"], str(task_id), "task.placement_recovered", decision
        )
        event_ids.append(parent_event)
        previous_activation = self._latest_remote_activation(task_id)
        if previous_activation is not None:
            event_ids.append(self.store._append_event(
                current["run"]["id"], str(task_id), "task.remote_activation_revoked",
                {"activation_id": previous_activation["activation_id"],
                 "reason": "placement_recovered", "revoked_at": timestamp},
            ))
        result = {
            "task": self._task_resource(self.store.get_task(task_id)),
            "placement_recovery": decision,
        }
        event_seq = self.store.conn.execute(
            "SELECT COUNT(*) FROM events WHERE run_id=?", (current["run"]["id"],)
        ).fetchone()[0]
        return self._command_record(
            "task.placement_recover", str(task_id), idempotency_key, request_hash, result,
            project_id=project_id, event_ids=event_ids,
            primary_stream_id=current["run"]["id"], resulting_stream_seq=event_seq,
            created_at=timestamp,
        )

    @_verified_mutation
    def cancel(self, task_id):
        return self.store.cancel_task(task_id)

    @_durable_mutation
    def cancel_task_canonical(self, task_id, body=None, *, idempotency_key=None, identity=None):
        idempotency_key = require_idempotency_key(idempotency_key)
        body = {} if body is None else body
        body = _wire_object(body, allowed=("expected_version", "attempt_id", "lease_id", "fence",
                                            "runtime_epoch", "outputs", "result", "stop_observed"))
        if "expected_version" in body:
            _wire_integer(body, "expected_version", positive=True)
        fenced = bool(set(body) & {"attempt_id", "lease_id", "fence", "runtime_epoch", "outputs", "result", "stop_observed"})
        if fenced:
            _wire_string(body, "attempt_id")
            _wire_string(body, "lease_id")
            _wire_integer(body, "fence")
            _wire_integer(body, "runtime_epoch", positive=True)
            if "stop_observed" in body and not isinstance(body["stop_observed"], bool):
                raise ValidationError("stop_observed must be a boolean")
            self._validate_terminal_result_body(body)
        with self.store._mutex:
            current = self.store.get_task(task_id)
            project_id = current["run"].get("project_id") or "unscoped"
            request_hash = hashlib.sha256(canonical_json({"task_id": task_id, "body": body}).encode()).hexdigest()
            replay = self._command_replay("task.cancel", task_id, idempotency_key, request_hash, project_id=project_id)
            if replay is not None:
                return replay
            expected = body.get("expected_version")
            if expected is not None and int(expected) != int(current["task"].get("attempt", 0)) + 1:
                raise ConflictError("stale task version", details={"expected": expected, "actual": int(current["task"].get("attempt", 0)) + 1})
            staged = None
            try:
                options = {}
                if fenced:
                    attempt_id = body["attempt_id"]
                    row = self.store.conn.execute("SELECT * FROM attempts WHERE id=?", (attempt_id,)).fetchone()
                    self._assert_attempt_identity(row, identity)
                    self._validate_attempt_lease(row, body, self.store._current_runtime_epoch())
                    task = self.store.conn.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
                    if row["task_id"] != task_id:
                        raise LeaseError("cancellation attempt does not match task")
                    options = {key: body[key] for key in ("attempt_id", "lease_id", "fence", "runtime_epoch")}
                    options["stop_observed"] = body.get("stop_observed", False)
                    if "outputs" in body or "result" in body:
                        staged = self._stage_outputs(attempt_id, body.get("outputs", []), project_id=current["run"].get("project_id"),
                            attempt_row=row, task_row=task, lease_body=body)
                        result = dict(body.get("result") or {})
                        result["outputs"] = staged["outputs"]
                        self._validate_terminal_manifest(staged, result, task, attempt_id, current["run"].get("project_id"))
                        options.update(result=result,
                            publish=lambda: self._publish_staged_outputs(staged, project_id=current["run"].get("project_id")))
                recorded = None
                def record(value, *, event_ids=(), primary_stream_id=None, resulting_stream_seq=None):
                    nonlocal recorded
                    recorded = self._command_record("task.cancel", task_id, idempotency_key, request_hash, self._task_resource(value), project_id=project_id, event_ids=event_ids, primary_stream_id=primary_stream_id, resulting_stream_seq=resulting_stream_seq)
                self.store.cancel_task(task_id, record=record, **options)
                if staged is not None:
                    staged["committed"] = True
                return recorded
            finally:
                if staged is not None:
                    self._discard_staged_outputs(staged)

    @_durable_mutation
    def abandon_task(self, task_id, body, *, idempotency_key=None, identity=None):
        """Owner decision to lose an unresolved attempt; never remote stop proof."""
        from .daemon import WORKER_ACTOR

        if (not isinstance(identity, dict) or identity.get("actor") != "owner"
                or "admin" not in identity.get("scopes", [])):
            raise AuthorizationError("task abandon requires the Runtime owner actor and admin scope")
        idempotency_key = require_idempotency_key(idempotency_key)
        fields = ("expected_task_version", "attempt_id", "lease_id", "fence", "runtime_epoch", "execution_binding", "reason")
        body = _wire_object(body, required=fields, allowed=fields)
        for field in ("expected_task_version", "fence", "runtime_epoch"):
            _wire_integer(body, field, positive=True)
        for field in ("attempt_id", "lease_id", "reason"):
            _wire_string(body, field)
        if not body["reason"].strip() or len(body["reason"]) > 4096:
            raise ValidationError("reason must be nonblank and at most 4096 characters")
        if not isinstance(body["execution_binding"], dict):
            raise ValidationError("execution_binding must be an object")
        current = self.store.get_task(task_id)
        project_id = current["run"].get("project_id") or "unscoped"
        request_hash = hashlib.sha256(canonical_json({"task_id": task_id, "body": body}).encode()).hexdigest()
        replay = self._command_replay("task.abandon", task_id, idempotency_key, request_hash, project_id=project_id)
        if replay is not None:
            return replay
        disposition, event_ids = self.store._abandon_external_attempt(task_id, body,
            actor=identity["actor"], local_executor_id=WORKER_ACTOR)
        result = {**disposition, "task": self._task_resource(self.store.get_task(task_id))}
        return self._command_record("task.abandon", task_id, idempotency_key, request_hash, result,
            project_id=project_id, event_ids=event_ids, primary_stream_id=current["run"]["id"])

    @_verified_mutation
    def retry_task(self, task_id, body=None, *, idempotency_key=None):
        idempotency_key = require_idempotency_key(idempotency_key)
        body = {} if body is None else body
        self._require_object_body(body)
        with self.store._mutex:
            current = self.store.get_task(task_id)
            project_id = current["run"].get("project_id") or "unscoped"
            request_hash = hashlib.sha256(canonical_json({"task_id": task_id, "body": body}).encode()).hexdigest()
            replay = self._command_replay("task.retry", task_id, idempotency_key, request_hash, project_id=project_id)
            if replay is not None:
                return replay
            if self._task_drain(task_id) is not None:
                raise ConflictError("remote drain blocks fresh task retries")
            status = current["task"]["status"]
            if current["task"].get("waiting_reason") == "provider_state_unknown":
                raise ConflictError(
                    "provider/executor state must be reconciled by authorized checkpoint resume before retry",
                    details={"status": status, "attempt_id": current["task"].get("attempt_id")},
                )
            if status not in {"completed", "cancelled", "failed"}:
                raise ConflictError("task is not retryable", details={"status": status})
            expected = (body or {}).get("expected_version")
            version = int(current["task"].get("attempt", 0)) + 1
            if expected is not None and int(expected) != version:
                raise ConflictError("stale task version", details={"expected": expected, "actual": version})
            with self.store._transaction():
                timestamp = now()
                self.store.assert_delegated_retry_capacity(task_id)
                self.store._release_reservations(task_id, current["task"].get("lease_token"))
                # A retry is a new queue admission attempt for the same
                # immutable task/request.  Keep the task id, spec, and input
                # objects stable, but reset the queue-age anchor so a prior
                # failed wait cannot make every retry fail before execution.
                self.store.conn.execute("UPDATE tasks SET status='queued', lease_token=NULL, executor_id=NULL, lease_expires_at=NULL, waiting_reason=NULL, result_json=NULL, attempt_id=NULL, created_at=?, updated_at=? WHERE id=?", (timestamp, timestamp, task_id))
                self.store.reset_execution_attempt(task_id)
                self.store.conn.execute("UPDATE runs SET status='queued', updated_at=? WHERE id=?", (timestamp, current["run"]["id"]))
                event_id = self.store._append_event(current["run"]["id"], task_id, "task.retried", {"from_status": status, "attempt": version})
                self.store._refresh_continuations_for_predecessor(task_id)
                result = self._task_resource(self.store.get_task(task_id))
                event_seq = self.store.conn.execute("SELECT COUNT(*) FROM events WHERE run_id=?", (current["run"]["id"],)).fetchone()[0]
                return self._command_record("task.retry", task_id, idempotency_key, request_hash, result, project_id=project_id, event_ids=(event_id,), primary_stream_id=current["run"]["id"], resulting_stream_seq=event_seq)

    def events(self, run_id):
        return self.store.list_events(run_id)

    @_verified_mutation
    def cancel_run(self, run_id, body=None, *, idempotency_key=None):
        return self._run_resource(self.store.cancel_run(run_id, idempotency_key=idempotency_key))

    @_verified_mutation
    def retry_run(self, run_id, body=None, *, idempotency_key=None):
        body = body or {}
        return self._run_resource(self.store.retry_run(run_id, selected_task_ids=body.get("selected_task_ids"), idempotency_key=idempotency_key))

    def _run_resource(self, value):
        result = dict(value)
        if result["spec_digest"] is None:
            result["spec_retired"] = True
        result["spec"], generation_intent = public_task_spec(self.store._load_spec(result.pop("spec_digest")))
        if generation_intent is not None:
            result["generation_intent"] = generation_intent
        result["task_ids"] = [task["id"] for task in self.store.conn.execute("SELECT id FROM tasks WHERE run_id=? ORDER BY created_at, id", (result["id"],))]
        return result

    def list_capabilities(self, *, cursor=None, limit=PAGE_DEFAULT_LIMIT):
        # Registration updates capability descriptors and executor visibility
        # in one transaction. Readers share the same fence so the HTTP catalog
        # cannot observe the transaction halfway through.
        with self.store._mutex:
            rows = self.store.conn.execute("SELECT * FROM capabilities ORDER BY id").fetchall()
            return _page_rows(rows, scope="capabilities", cursor=cursor, limit=limit,
                              key_fn=lambda row: (str(row["id"]),),
                              resource_fn=lambda r: self._capability_resource(r))

    def _capability_resource(self, row):
        status = row["status"]
        reason = row["unavailable_reason"]
        if status == "ready" and not self.store.matching_live_executor(row["id"], row["definition_digest"]):
            status, reason = "unavailable", "no_live_matching_executor"
        return {"capability_id": row["id"], "definition_digest": row["definition_digest"], "status": status, "required_resource_keys": json.loads(row["required_resource_keys_json"]), "estimated_scratch_bytes": row["estimated_scratch_bytes"], "estimated_output_bytes": row["estimated_output_bytes"], "unavailable_reason": reason}

    @_verified_mutation
    def register_capability(self, body):
        value = self.store.register_capability(body.get("capability_id", ""), body.get("definition_digest", ""), required_resource_keys=body.get("required_resource_keys", []), status=body.get("status", "ready"), unavailable_reason=body.get("unavailable_reason"), estimated_scratch_bytes=body.get("estimated_scratch_bytes", 0), estimated_output_bytes=body.get("estimated_output_bytes", 0))
        # Registration acknowledges the executor's declared state. Discovery
        # computes liveness-aware availability via ``_capability_resource``.
        return {"capability_id": value["id"], "definition_digest": value["definition_digest"], "status": value["status"], "required_resource_keys": value["required_resource_keys"], "estimated_scratch_bytes": value["estimated_scratch_bytes"], "estimated_output_bytes": value["estimated_output_bytes"], "unavailable_reason": value.get("unavailable_reason")}

    @_durable_mutation
    def register_executor(self, body, *, idempotency_key=None, identity=None):
        body = _wire_object(
            body,
            allowed=(
                "executor_id", "max_concurrency", "resource_keys", "capabilities",
                "protocol", "readiness", "readiness_reason", "runtime_epoch",
                "source_digest", "dependency_digest", "source_epoch", "schema_digest",
                "verified_facts",
            ),
        )
        executor_id = _wire_string(body, "executor_id")
        self._assert_executor_identity(identity, executor_id)
        self._assert_local_claim_admission(executor_id, identity=identity, registration=True)
        max_concurrency = body.get("max_concurrency", 1)
        if isinstance(max_concurrency, bool) or not isinstance(max_concurrency, int) or max_concurrency < 1:
            raise ValidationError("max_concurrency must be positive")
        capabilities = body.get("capabilities", [])
        if not isinstance(capabilities, list):
            raise ValidationError("capabilities must be a list")
        resource_keys = body.get("resource_keys", [])
        if not isinstance(resource_keys, list):
            raise ValidationError("resource_keys must be a list")
        protocol = body.get("protocol", "workspace.v1")
        if not isinstance(protocol, str) or protocol != "workspace.v1":
            raise ValidationError("protocol must be workspace.v1")
        readiness = body.get("readiness", "ready")
        if readiness not in {"ready", "not_ready"}:
            raise ValidationError("readiness must be ready or not_ready")
        if body.get("runtime_epoch") is not None:
            _wire_integer(body, "runtime_epoch", positive=True)
        for field in ("source_digest", "dependency_digest", "source_epoch"):
            if body.get(field) is not None:
                _wire_string(body, field)
        if body.get("schema_digest") is not None:
            if not isinstance(body["schema_digest"], str) or body["schema_digest"] != SCHEMA_DIGEST:
                raise ValidationError("schema_digest does not match the runtime contract")
        verified_facts = normalize_execution_facts(body["verified_facts"], field="verified_facts") if "verified_facts" in body else None
        request_hash = hashlib.sha256(canonical_json(body).encode()).hexdigest()
        # Executor registration is an endpoint-scoped command.  The request
        # hash includes executor identity and all registration fields, so a
        # reused key can only replay the exact durable result.
        aggregate_id = "executors"
        existing = self.store.conn.execute("SELECT runtime_epoch FROM executors WHERE id=?", (body["executor_id"],)).fetchone()
        current_epoch = self.store._current_runtime_epoch()
        if body.get("runtime_epoch") is not None:
            self.store._validate_runtime_epoch(
                body.get("runtime_epoch"), identity="executor",
                identity_id=body.get("executor_id"), required=True,
            )
        prior = None
        if idempotency_key is not None:
            validate_idempotency_key(idempotency_key)
            prior = self.store.conn.execute(
                "SELECT request_hash, result_json, created_at FROM session_command_replay "
                "WHERE command_kind='executor.register' AND aggregate_id=? AND idempotency_key=?",
                (aggregate_id, idempotency_key),
            ).fetchone()
        if prior:
            if prior["request_hash"] != request_hash:
                raise ConflictError("idempotency key was already used with different input")
            replay = command_result(prior["result_json"], kind="executor.register", connection=self.store.conn, created_at=prior["created_at"], window_seconds=SESSION_IDEMPOTENCY_WINDOW_SECONDS)
            # A replay is safe only in the same runtime session.  In
            # particular, do not let a pre-restart registration refresh a
            # dead executor lease merely because its key is known.
            if int(replay.get("runtime_epoch") or 0) != current_epoch:
                self.store._validate_runtime_epoch(
                    body.get("runtime_epoch"), identity="executor",
                    identity_id=body.get("executor_id"), required=True,
                )
            return replay
        # Re-registration is the canonical reconnect path after a runtime
        # restart or a deliberate capability/readiness refresh.  The bearer
        # fence above binds the caller to this executor (or an administrator),
        # while an existing identity must present the current runtime epoch.
        epoch = self.store._validate_runtime_epoch(
            body.get("runtime_epoch"), identity="executor",
            identity_id=body.get("executor_id"), required=existing is not None,
        )
        registered = self.store.upsert_executor(body["executor_id"], capabilities, max_concurrency, body.get("resource_keys", []), protocol=body.get("protocol", "workspace.v1"), readiness=body.get("readiness", "ready"), readiness_reason=body.get("readiness_reason"), runtime_epoch=epoch, source_digest=body.get("source_digest"), dependency_digest=body.get("dependency_digest"), source_epoch=body.get("source_epoch"), verified_facts=verified_facts)
        result = {"executor_id": body["executor_id"], "max_concurrency": max_concurrency, "resource_keys": body.get("resource_keys", []), "capabilities": registered["capabilities"], "protocol": body.get("protocol", "workspace.v1"), "readiness": body.get("readiness", "ready"), "runtime_epoch": epoch, "source_digest": body.get("source_digest"), "dependency_digest": body.get("dependency_digest"), "source_epoch": body.get("source_epoch")}
        if verified_facts is not None:
            result["verified_facts"] = verified_facts
        return self._command_record("executor.register", aggregate_id, idempotency_key, request_hash, result, project_id="unscoped", with_receipt=False)

    def executor_observation(self, executor_id, *, identity):
        """Return one registered executor to the owner or its exact worker."""
        actor = identity.get("actor") if isinstance(identity, dict) else None
        scopes = identity.get("scopes") if isinstance(identity, dict) else None
        if not (isinstance(actor, str) and actor and isinstance(scopes, list) and (
            (actor == "owner" and "admin" in scopes)
            or (actor == executor_id and "worker:execute" in scopes)
        )):
            raise AuthorizationError("executor observation requires owner or exact worker authority")
        if not isinstance(executor_id, str) or not executor_id:
            raise ValidationError("executor_id is required")
        with self.store._mutex:
            row = self.store.conn.execute("SELECT * FROM executors WHERE id=?", (executor_id,)).fetchone()
            if row is None:
                raise NotFoundError("executor not found")
            value = self.store._executor_result(row)
            value["executor_id"] = value.pop("id")
            value["runtime_session_id"] = self.runtime_session_id
            return {key: value[key] for key in (
                "executor_id", "max_concurrency", "resource_keys", "capabilities",
                "protocol", "runtime_epoch", "readiness", "readiness_reason",
                "last_seen_at", "source_digest", "dependency_digest", "source_epoch",
                "runtime_session_id",
            ) if key in value} | ({"verified_facts": value["verified_facts"]} if "verified_facts" in value else {})

    @_durable_mutation(reap_task_lifetimes=True)
    def claim_next(self, body, *, idempotency_key=None, identity=None):
        """Atomically select, claim, fence, and record a canonical claim.

        A claim has no task path, so its command aggregate is the endpoint's
        claim namespace.  The request hash binds executor, capabilities, and
        runtime epoch; a replay can never consume a second queued task.
        """
        _require_runtime_epoch_for_lease(body)
        body = _wire_object(
            body,
            required=("executor_id", "capability_ids", "runtime_epoch"),
            allowed=("executor_id", "capability_ids", "runtime_epoch", "target"),
        )
        executor_id = _wire_string(body, "executor_id")
        capability_ids = body.get("capability_ids")
        runtime_epoch = body.get("runtime_epoch")
        self._assert_executor_identity(identity, executor_id)
        self._assert_local_claim_admission(executor_id, identity=identity)
        if not isinstance(capability_ids, list) or any(not isinstance(value, str) or not value for value in capability_ids) or len(set(capability_ids)) != len(capability_ids):
            raise ValidationError("capability_ids must be a list of unique non-empty strings")
        _wire_integer(body, "runtime_epoch", positive=True)
        requested_target = None
        if body.get("target") is not None:
            requested_target = _normalize_execution_target(body["target"])
        trusted_placement = self._trusted_execution_placement(identity)
        request_hash = hashlib.sha256(canonical_json({
            "executor_id": executor_id, "capability_ids": capability_ids,
            "runtime_epoch": runtime_epoch, "target": requested_target,
            "trusted_execution_placement": trusted_placement,
        }).encode()).hexdigest()
        # Epoch validation intentionally precedes the idempotency lookup: a
        # stale worker must never turn an old claim receipt into a live lease.
        epoch = self.store._validate_runtime_epoch(runtime_epoch, identity="executor", identity_id=executor_id, required=True)
        replayed, replay = self._command_replay_state(
            "task.claim", "claim", idempotency_key, request_hash, with_receipt=False,
        )
        if replayed:
            if isinstance(replay, dict):
                self.store.assert_attempt_not_abandoned(replay.get("attempt_id"))
            if isinstance(replay, dict) and replay.get("task_id"):
                replay_capability = self.store.conn.execute(
                    "SELECT capability FROM tasks WHERE id=?", (replay["task_id"],)
                ).fetchone()
                qualified_identity = (
                    isinstance(identity, dict)
                    and isinstance(identity.get("qualified_activation"), dict)
                )
                if (replay_capability is not None and (
                        self._task_requires_remote_activation(replay["task_id"])
                        or qualified_identity
                    )
                        and not self._remote_activation_matches(
                            replay["task_id"], identity, trusted_placement,
                            require_fresh=not bool(replay.get("attempt_id")),
                        )):
                    raise AuthorizationError("remote activation is missing, revoked, or stale")
            return replay
        # Enforce hard bounds and contain expired authority before selecting
        # work. Ordinary expiry alone does not make a running task claimable.
        self.store._reap_expired_leases()
        caps = set(capability_ids)
        rows = self.store.conn.execute(
            "SELECT id, capability, execution_request_json, spec_digest, waiting_reason "
            "FROM tasks WHERE status='queued' ORDER BY rowid"
        ).fetchall()
        row = None
        selected_binding = None
        for item in rows:
            if caps and item["capability"] not in caps:
                continue
            activation = identity.get("qualified_activation") if isinstance(identity, dict) else None
            if isinstance(activation, dict) and not self._activation_scope_matches(item["id"], activation, trusted_placement):
                # An exact prepared generation cannot block, mutate, or claim
                # an earlier queued sibling merely sharing capability/target.
                try:
                    prepared_actor = self.prepared_child_executor(activation.get("task_id"))
                except (AuthorizationError, ConflictError, LeaseError, ValidationError, NotFoundError):
                    continue
                if prepared_actor is not None:
                    continue
                # Ordinary remote generations retain the existing waiting
                # response; remote activation authorization still runs below.
            binding = self.store.execution_binding(item["id"])
            targeted_request = self.store._execution_request_from_row(item)
            targeted = targeted_request is not None
            if targeted:
                if binding is None:
                    continue
                if requested_target is None:
                    # Ordinary local managed inputs retain a default request.
                    # Only the credential-verified local machine may consume
                    # that exact default binding without a selector.
                    if (targeted_request["target"] != {"kind": "default"}
                            or binding["resolved_target"] != targeted_request["target"]
                            or executor_id != self._local_claim_actor
                            or identity is None or identity.get("actor") != executor_id
                            or identity.get("qualified_activation") is not None
                            or trusted_placement is None
                            or trusted_placement["actual"]["kind"] != "machine"):
                        continue
                elif canonical_json(binding["resolved_target"]) != canonical_json(requested_target):
                    continue
                selected_binding = binding
            row = item
            break
        if row is None:
            # Persist the empty outcome too.  Otherwise a retry after another
            # task is admitted would silently claim new work.
            return self._command_record("task.claim", "claim", idempotency_key, request_hash, None, project_id="unscoped", with_receipt=False)
        if row["waiting_reason"] == "provider_state_unknown":
            value = self.store.get_task(row["id"])
            result = {
                "task": self._task_resource(value),
                "waiting_reason": "provider_state_unknown",
            }
            return self._command_record(
                "task.claim", "claim", idempotency_key, request_hash, result,
                project_id="unscoped", with_receipt=False,
            )
        qualified_identity = (
            isinstance(identity, dict)
            and isinstance(identity.get("qualified_activation"), dict)
        )
        if selected_binding is not None or qualified_identity:
            if trusted_placement is None:
                reason = "execution_binding_missing"
            elif selected_binding is None:
                reason = "execution_binding_missing"
            elif not execution_placement_matches(
                selected_binding["resolved_target"], trusted_placement
            ):
                reason = "execution_binding_mismatch"
            elif not self._placement_recovery_qualification_matches(
                row["id"], trusted_placement
            ):
                reason = "execution_qualification_mismatch"
            elif (
                self._task_requires_remote_activation(row["id"])
                or qualified_identity
            ) and not self._remote_activation_matches(
                row["id"], identity, trusted_placement, require_fresh=True
            ):
                reason = "remote_activation_missing"
            else:
                reason = None
            if reason is not None:
                self.store._set_waiting_reason(row["id"], reason)
                value = self.store.get_task(row["id"])
                result = {"task": self._task_resource(value), "waiting_reason": reason}
                return self._command_record(
                    "task.claim", "claim", idempotency_key, request_hash, result,
                    project_id="unscoped", with_receipt=False,
                )
        attempt_id, lease_id = new_id(), new_id()
        value = self.store._claim_task(row["id"], executor_id, lease_id, runtime_epoch=epoch, _transactional=False)
        if value["task"]["status"] == "failed":
            result = None
        elif value["task"]["status"] != "running":
            result = {"task": self._task_resource(value), "waiting_reason": value["task"].get("waiting_reason") or "waiting_for_worker"}
        else:
            task = value["task"]
            fence = int(task.get("lease_fence") or task.get("attempt") or 1)
            expires = task.get("lease_expires_at") or now()
            self.store.conn.execute("INSERT INTO attempts(id, task_id, lease_id, fence, executor_id, lease_expires_at, settled, runtime_epoch) VALUES (?, ?, ?, ?, ?, ?, 0, ?)", (attempt_id, row["id"], lease_id, fence, executor_id, expires, epoch))
            self.store.conn.execute("UPDATE tasks SET attempt_id=? WHERE id=?", (attempt_id, row["id"]))
            binding = self.store.bind_execution_attempt(
                row["id"], attempt_id=attempt_id, lease_id=lease_id,
                fence=fence, executor_id=executor_id, runtime_epoch=epoch,
                placement=trusted_placement,
            )
            if binding is not None:
                self.store._append_event(
                    value["run"]["id"], row["id"], "task.execution_bound",
                    {
                        "attempt_id": attempt_id,
                        "lease_id": lease_id,
                        "fence": fence,
                        "runtime_epoch": epoch,
                        "execution_binding": binding,
                    },
                )
            # Return the immutable admitted spec alongside the lease. Workers
            # must execute exactly what was claimed, without a racy second read.
            admitted_spec, generation_intent = public_task_spec(task.get("spec") or {})
            from .capture_validation import claim_capture_view
            admitted_spec = claim_capture_view(self, admitted_spec)
            if task.get("generation_intent") is not None:
                generation_intent = task["generation_intent"]
            run_id = admitted_run_id(task.get("run_id"), value["run"].get("id"))
            result = {"attempt_id": attempt_id, "task_id": row["id"], "run_id": run_id, "project_id": value["run"].get("project_id"), "lease_id": lease_id, "fence": fence, "lease_expires_at": expires, "deadline_at": self.store._task_absolute_deadline(task).isoformat(), "runtime_epoch": epoch, "input_object_ids": list(admitted_spec.get("input_object_ids") or []), "spec": admitted_spec}
            if task.get("execution_request") is not None:
                result["execution_request"] = dict(task["execution_request"])
            if binding is not None:
                result["execution_binding"] = binding
            if generation_intent is not None:
                result["generation_intent"] = generation_intent
            if task.get("expected_effect") is not None:
                result["expected_effect"] = dict(task["expected_effect"])
            if "required_facts" in admitted_spec:
                result["required_facts"] = dict(admitted_spec["required_facts"])
            if "storage_estimate" in admitted_spec:
                result["storage_estimate"] = dict(admitted_spec["storage_estimate"])
        return self._command_record("task.claim", "claim", idempotency_key, request_hash, result, project_id="unscoped", with_receipt=False)

    @_durable_mutation
    def claim_delegated_child(self, task_id, body, *, idempotency_key, identity):
        """Claim only the named admitted child under its still-live parent.

        Authority, immutable lineage, verified machine placement, exact target,
        shared store preflight, attempt fence and command receipt share one
        transaction. A rejected claim rolls back and never searches the queue.
        Replays authenticate the parent again and require the same live child
        attempt; a historical command receipt is never fresh lease authority.
        """
        fields = ("executor_id", "capability_ids", "runtime_epoch", "target", "authority")
        body = _wire_object(body, required=fields, allowed=fields)
        executor_id = _wire_string(body, "executor_id")
        _wire_string(body, "authority")
        _wire_integer(body, "runtime_epoch", positive=True)
        idempotency_key = require_idempotency_key(idempotency_key)
        caps = body["capability_ids"]
        if (not isinstance(caps, list) or not caps
                or any(not isinstance(cap, str) or not cap for cap in caps)
                or len(set(caps)) != len(caps)):
            raise ValidationError("capability_ids must contain unique non-empty strings")
        target = _normalize_execution_target(body["target"])
        # Unlike ordinary administrative claim, delegated authority belongs to
        # the authenticated executor itself. Admin scope cannot impersonate it.
        if not isinstance(identity, dict) or identity.get("actor") != executor_id:
            raise AuthorizationError("delegated claim requires the parent executor actor")
        self._assert_local_claim_admission(executor_id, identity=identity)
        placement = self._trusted_execution_placement(identity)
        if placement is None or placement["actual"]["kind"] != "machine":
            raise AuthorizationError("delegated claim requires verified machine placement")
        epoch = self.store._validate_runtime_epoch(body["runtime_epoch"], identity="executor", identity_id=executor_id, required=True)
        registered = self.store.conn.execute("SELECT runtime_epoch FROM executors WHERE id=?", (executor_id,)).fetchone()
        if registered is None or int(registered["runtime_epoch"]) != epoch:
            raise LeaseError("delegated claim executor registration belongs to another runtime epoch")
        payload, parent_attempt, parent, project, policy, _, placement_version, effective_target = self._live_child_authority(body["authority"], identity=identity)
        if executor_id != parent_attempt["executor_id"]:
            raise AuthorizationError("delegated claim must use the verified parent executor")
        if (not parent_attempt["lease_expires_at"]
                or parent["lease_expires_at"] != parent_attempt["lease_expires_at"]):
            raise LeaseError("parent attempt lease deadline is missing or inconsistent")
        parent_binding = self.store.execution_binding(parent["id"])
        if self.store._execution_request_from_row(parent) is not None and parent_binding is None:
            raise LeaseError("parent execution binding is missing")
        if parent_binding is not None and (
                parent_binding["status"] != "claimed"
                or parent_binding.get("actual_target") != placement["actual"]
                or parent_binding.get("verification") != placement["verification"]
                or parent_binding.get("executor_incarnation") != placement["executor_incarnation"]
                or any(parent_binding.get(field) != parent_attempt[source] for field, source in (
                    ("attempt_id", "id"), ("lease_id", "lease_id"), ("fence", "fence"),
                    ("executor_id", "executor_id"), ("runtime_epoch", "runtime_epoch")))):
            raise LeaseError("parent execution binding fence is stale")
        child = self.store.conn.execute("SELECT * FROM tasks WHERE id=?", (str(task_id),)).fetchone()
        if child is None:
            raise NotFoundError("delegated child not found")
        lineage = self.store._spec(child).get("delegated_parent")
        expected_lineage = {
            "parent_task_id": parent["id"], "parent_attempt_id": parent_attempt["id"],
            "parent_lease_id": parent_attempt["lease_id"], "parent_fence": int(parent_attempt["fence"]),
            "runtime_epoch": epoch, "executor_id": executor_id, "project_id": project,
            "parent_placement": placement, "parent_effective_target": effective_target,
            "parent_placement_version": placement_version, "policy_digest": payload["policy_digest"],
        }
        child_run = self.store.conn.execute("SELECT * FROM runs WHERE id=?", (child["run_id"],)).fetchone()
        if lineage != expected_lineage or child_run["project_id"] != project:
            raise AuthorizationError("delegated child lineage or project does not match parent authority")
        if (child["capability"] not in caps
                or {"capability_id": child["capability"], "capability_digest": child["capability_digest"]} not in policy["capabilities"]):
            raise AuthorizationError("delegated child capability is outside claim or parent policy")
        exact_child = payload.get("child")
        if exact_child is not None and (exact_child["child_id"] != child_run["idempotency_key"]
                or exact_child["capability_id"] != child["capability"]
                or exact_child["capability_digest"] != child["capability_digest"]):
            raise AuthorizationError("child authority is bound to another exact child")
        selected = self.store.effective_execution_target(str(task_id))
        # Untargeted scalar children retain their ordinary path; explicit
        # default is the only selector for their exact delegated claim.
        if target not in policy["targets"] or target != (selected if selected is not None else {"kind": "default"}):
            raise AuthorizationError("delegated child target does not match explicit selector")
        binding = self.store.execution_binding(str(task_id))
        if (not execution_placement_matches(target, placement)
                or (selected is not None and binding is None)
                or (binding is not None and binding["resolved_target"] != target)
                or not self._placement_recovery_qualification_matches(str(task_id), placement)
                or not self._placement_recovery_qualification_matches(parent["id"], placement)):
            raise AuthorizationError("delegated child execution placement does not match")
        if self._task_drain(str(task_id)) is not None or self._task_drain(parent["id"]) is not None:
            raise ConflictError("remote drain blocks fresh delegated claims")
        if (self._task_requires_remote_activation(str(task_id))
                or isinstance(identity.get("qualified_activation"), dict)) and not self._remote_activation_matches(str(task_id), identity, placement, require_fresh=True):
            raise AuthorizationError("delegated child activation is missing, revoked, or stale")
        failure = self.store._task_lifetime_failure(child, datetime.now(timezone.utc))
        if failure is not None or child["waiting_reason"] in {"provider_state_unknown", "runtime_recovery"}:
            raise ConflictError("delegated child requires recovery or exhausted its lifetime", details=failure or {"waiting_reason": child["waiting_reason"]})
        accounting = self.store.delegated_child_accounting(parent["id"], parent_attempt["id"])
        if (accounting["lifetime"] > policy["limits"]["max_children"]
                or accounting["active"] > policy["limits"]["max_active_children"]):
            raise ConflictError("delegated child exceeds parent child capacity")
        request_hash = sha256_bytes(canonical_json({
            "task_id": str(task_id), "body": body, "target": target,
            "trusted_execution_placement": placement,
        }).encode())
        replayed, replay = self._command_replay_state("task.claim_delegated_child", "claim", idempotency_key, request_hash, with_receipt=False)
        if replayed:
            # Reuse the store's readiness/resource predicates, but count the
            # replayed attempt's own occupied slot and reservation as its own.
            executor = self.store.conn.execute("SELECT * FROM executors WHERE id=?", (executor_id,)).fetchone()
            child_spec = self.store._spec(child)
            active = self.store.conn.execute("SELECT COUNT(*) FROM tasks WHERE executor_id=? AND status='running'", (executor_id,)).fetchone()[0]
            if (not self.store._executor_can_run(executor, child["capability"], child["capability_digest"], include_storage=False, required_facts=child_spec.get("required_facts"))
                    or active > executor["max_concurrency"]
                    or not self.store.storage_preflight(child["capability"], storage_estimate=child_spec.get("storage_estimate"))["ok"]):
                raise ConflictError("delegated child replay preflight rejected claim")
            for key in self.store._required_resource_keys(child["capability"]):
                reservations = self.store.conn.execute("SELECT * FROM reservations WHERE executor_id=? AND resource_key=? AND released_at IS NULL", (executor_id, key)).fetchall()
                if (key not in json.loads(executor["resource_keys_json"]) or len(reservations) != 1
                        or any(reservations[0][field] != replay[source] for field, source in (
                            ("task_id", "task_id"), ("lease_token", "lease_id"), ("fence", "fence"), ("runtime_epoch", "runtime_epoch"), ("lease_expires_at", "lease_expires_at")))):
                    raise ConflictError("delegated child replay resource reservation changed")
            attempt = self.store.conn.execute("SELECT * FROM attempts WHERE id=?", (replay["attempt_id"],)).fetchone()
            self._assert_attempt_identity(attempt, identity)
            self._validate_attempt_lease(attempt, replay, epoch)
            if (attempt["task_id"] != str(task_id) or attempt["executor_id"] != executor_id
                    or attempt["lease_expires_at"] != replay["lease_expires_at"]
                    or child["status"] != "running" or child["attempt_id"] != replay["attempt_id"]
                    or child["lease_token"] != replay["lease_id"] or child["lease_fence"] != replay["fence"]
                    or child["executor_id"] != executor_id or child["runtime_epoch"] != epoch
                    or child["lease_expires_at"] != replay["lease_expires_at"]
                    or binding != replay.get("execution_binding")):
                raise LeaseError("delegated child claim is no longer the same live attempt")
            return replay
        if child["status"] != "queued":
            raise ConflictError("delegated child is not queued")
        if binding is not None and binding["status"] != "prepared":
            raise ConflictError("delegated child binding requires recovery")
        if self.store.conn.execute("SELECT 1 FROM attempts WHERE task_id=? AND settled=0 LIMIT 1", (str(task_id),)).fetchone():
            raise ConflictError("delegated child has an unresolved prior attempt")
        attempt_id, lease_id = new_id(), new_id()
        value = self.store._claim_task(str(task_id), executor_id, lease_id, runtime_epoch=epoch, _transactional=False)
        task = value["task"]
        if task["status"] != "running":
            raise ConflictError("delegated child preflight rejected claim", details={"waiting_reason": task.get("waiting_reason")})
        executor = self.store.conn.execute("SELECT * FROM executors WHERE id=?", (executor_id,)).fetchone()
        if not self.store._executor_can_run(executor, child["capability"], child["capability_digest"], include_storage=False, required_facts=self.store._spec(child).get("required_facts")):
            raise ConflictError("delegated child executor qualification changed")
        # Shared preflight can reap expired leases; recheck parent before any
        # attempt or receipt is committed, including a deadline crossing here.
        self._live_child_authority(body["authority"], identity=identity)
        fence, expires = int(task["lease_fence"]), task["lease_expires_at"]
        self.store.conn.execute("INSERT INTO attempts(id, task_id, lease_id, fence, executor_id, lease_expires_at, settled, runtime_epoch) VALUES (?, ?, ?, ?, ?, ?, 0, ?)", (attempt_id, str(task_id), lease_id, fence, executor_id, expires, epoch))
        self.store.conn.execute("UPDATE tasks SET attempt_id=? WHERE id=?", (attempt_id, str(task_id)))
        binding = self.store.bind_execution_attempt(str(task_id), attempt_id=attempt_id, lease_id=lease_id, fence=fence, executor_id=executor_id, runtime_epoch=epoch, placement=placement)
        if binding is not None:
            self.store._append_event(value["run"]["id"], str(task_id), "task.execution_bound", {
                "attempt_id": attempt_id, "lease_id": lease_id, "fence": fence,
                "runtime_epoch": epoch, "execution_binding": binding,
            })
        admitted_spec, generation_intent = public_task_spec(task.get("spec") or {})
        generation_intent = task.get("generation_intent") or generation_intent
        run_id = admitted_run_id(task.get("run_id"), value["run"].get("id"))
        result = {"attempt_id": attempt_id, "task_id": str(task_id), "run_id": run_id, "project_id": project, "lease_id": lease_id, "fence": fence, "lease_expires_at": expires, "runtime_epoch": epoch, "input_object_ids": list(admitted_spec.get("input_object_ids") or []), "spec": admitted_spec}
        for field in ("execution_request", "expected_effect"):
            if task.get(field) is not None:
                result[field] = dict(task[field])
        for field in ("required_facts", "storage_estimate"):
            if field in admitted_spec:
                result[field] = dict(admitted_spec[field])
        if binding is not None:
            result["execution_binding"] = binding
        if generation_intent is not None:
            result["generation_intent"] = generation_intent
        return self._command_record("task.claim_delegated_child", "claim", idempotency_key, request_hash, result, project_id="unscoped", with_receipt=False)

    @_durable_mutation(reap_task_lifetimes=True)
    def settle_attempt(self, attempt_id, body, *, idempotency_key=None, identity=None, _verified_objects=None):
        idempotency_key = require_idempotency_key(idempotency_key)
        body = dict(_wire_object(
            body,
            allowed=("attempt_id", "lease_id", "fence", "runtime_epoch", "outputs", "effect", "result"),
        ))
        supplied_attempt_id = body.get("attempt_id")
        if supplied_attempt_id is not None and str(supplied_attempt_id) != str(attempt_id):
            raise ConflictError("attempt_id does not match the attempt path")
        body["attempt_id"] = str(attempt_id)
        _wire_string(body, "lease_id")
        _require_runtime_epoch_for_lease(body)
        # Keep a numerically typed stale fence on the lease path. A worker
        # presenting fence 0 (or another old fence) is a fenced lease error,
        # not a request-shape error; this preserves one guard taxonomy.
        _wire_integer(body, "fence")
        _wire_integer(body, "runtime_epoch", positive=True)
        if "outputs" in body and not isinstance(body["outputs"], list):
            raise ValidationError("outputs must be a list")
        if "result" in body and not isinstance(body["result"], dict):
            raise ValidationError("result must be an object")
        if isinstance(body.get("result"), dict) and "outputs" in body["result"]:
            raise ValidationError("result.outputs is reserved; send outputs at the settlement top level")
        with self.store._mutex:
            row = self.store.conn.execute("SELECT * FROM attempts WHERE id=?", (attempt_id,)).fetchone()
            self._assert_attempt_identity(row, identity)
            if not row:
                raise LeaseError("attempt lease is stale or already settled")
            current_epoch = self.store._current_runtime_epoch()
            task = self.store.conn.execute("SELECT * FROM tasks WHERE id=?", (row["task_id"],)).fetchone()
            project_id = self.store.conn.execute("SELECT project_id FROM runs WHERE id=?", (task["run_id"],)).fetchone()[0] if task else "unscoped"
            request_hash = hashlib.sha256(canonical_json({"attempt_id": attempt_id, "body": body}).encode()).hexdigest()
            replay = self._command_replay("attempt.settle", attempt_id, idempotency_key, request_hash, project_id=project_id or "unscoped")
            if replay is not None:
                return replay
            self._validate_attempt_lease(row, body, current_epoch)
            if not task or (task["runtime_epoch"] is not None and int(task["runtime_epoch"]) != current_epoch):
                raise LeaseError("attempt belongs to a stale runtime epoch")
            if task["status"] != "running" or task["attempt_id"] != attempt_id or task["lease_token"] != row["lease_id"] or int(task["lease_fence"] or 0) != int(row["fence"]):
                raise LeaseError("attempt lease is stale or already settled")
            declared = json.loads(task["expected_effect_json"]) if task["expected_effect_json"] else None
            effect = body.get("effect")
            if effect is not None and declared != effect:
                raise ValidationError("settlement effect was not predeclared", details={"declared": declared})
            if declared is not None and effect is None:
                raise ValidationError("declared settlement effect is required")
            if effect is not None:
                self.store._validate_settlement_effect(effect)
            admitted_spec = self.store._spec(task)
            if admitted_spec.get("delegation_closed_attempt_id") == attempt_id:
                raise AuthorizationError("parent attempt child authority has ended")
            lineage = admitted_spec.get("delegated_parent")
            policy = None
            if lineage is not None:
                _, parent, _, policy = self._live_delegating_parent(lineage["parent_attempt_id"], {
                    "lease_id": lineage["parent_lease_id"], "fence": lineage["parent_fence"],
                    "runtime_epoch": lineage["runtime_epoch"],
                }, identity=None)
                publications = policy.get("publications")
                if publications is not None:
                    raw, final = publications["raw"], publications["final"]
                    consumer = final["candidate_stage"] if final["candidate_stage"] != raw["stage"] else final["verify_stage"]
                    if admitted_spec.get("delegated_stage") == consumer:
                        siblings = self._delegated_stage_rows(project_id, lineage)
                        producer = siblings[raw["stage"]]
                        selected = self._named_publication_association(producer, raw)
                        consumed = [ref for ref in admitted_spec.get("delegated_inputs", [])
                                    if ref.get("producer_stage") == raw["stage"]
                                    and ref.get("output_port") == raw["output_port"]]
                        matching = [ref for ref in consumed if ref.get("association_id") == selected["association_id"]]
                        if len(matching) != 1:
                            raise AuthorizationError("candidate settlement omitted or substituted the selected raw publication")
                        self._read_delegated_publication(matching[0], raw["effect"], project_id)
            self.store.assert_delegated_children_completed(task["id"], attempt_id)
            for child in self.store.delegated_children(task["id"], attempt_id):
                for association in self.store.list_managed_outputs(child["id"]):
                    if association["role"] == "recoverable_snapshot":
                        continue
                    digest = association["object_id"].removeprefix("sha256:")
                    obj = self.store.conn.execute("SELECT size FROM objects WHERE digest=?", (digest,)).fetchone()
                    if (obj is None or int(obj["size"]) != association["size"]
                            or association["project_id"] != project_id
                            or (project_id is not None and not self.store.conn.execute("SELECT 1 FROM project_objects WHERE project_id=? AND digest=?", (project_id, digest)).fetchone())):
                        raise ConflictError("accepted child managed output metadata changed")
                    self._verify_child_object_bytes(digest, association["size"], label="accepted child output CAS object")
            verified_source = admitted_spec.get("verified_publication_source")
            if verified_source is not None and "publication_name" not in verified_source:
                lineage = admitted_spec["delegated_parent"]
                self._live_delegating_parent(lineage["parent_attempt_id"], {
                    "lease_id": lineage["parent_lease_id"], "fence": lineage["parent_fence"],
                    "runtime_epoch": lineage["runtime_epoch"],
                }, identity=None)
                association = self.store.get_managed_output(verified_source["association_id"])
                producer = self.store.conn.execute("SELECT status, attempt_id FROM tasks WHERE id=?", (verified_source["producer_task_id"],)).fetchone()
                if (association["task_id"] != verified_source["producer_task_id"]
                        or association["attempt_id"] != verified_source["producer_attempt_id"]
                        or association["project_id"] != project_id
                        or association["object_id"] != verified_source["object_id"]
                        or association["output_port"] != verified_source["output_port"]
                        or association["durability"] != "durable"
                        or association["lifecycle"]["state"] not in {"available", "promoted"}
                        or producer is None or producer["status"] != "completed"
                        or producer["attempt_id"] != verified_source["producer_attempt_id"]):
                    raise ConflictError("verified publication source is no longer available")
                outputs = body.get("outputs")
                if (not isinstance(outputs, list) or len(outputs) != 1 or not isinstance(outputs[0], dict)
                        or outputs[0].get("digest") != verified_source["object_id"]
                        or outputs[0].get("output_port") != verified_source["output_port"]
                        or outputs[0].get("kind", "object") != "object"
                        or outputs[0].get("durability", "durable") != "durable"):
                    raise AuthorizationError("final publication must use the declared verified output")
            publication_binding = None
            if verified_source is not None and "publication_name" in verified_source:
                name = verified_source["publication_name"]
                outputs = body.get("outputs") or []
                selected = self._named_publication_output(declared, outputs)
                if (selected.get("kind", "object") != "object"
                        or selected.get("durability", "durable") != "durable"
                        or selected.get("role") == "recoverable_snapshot"):
                    raise AuthorizationError("named publication must use its one declared durable output")
                publication_binding = {"name": name, **{key: lineage[key] for key in ("parent_task_id", "parent_attempt_id", "parent_fence", "runtime_epoch")}}
                if name == "final":
                    self._validate_named_publication_lineage(verified_source, project_id, lineage)
                    if selected.get("digest") != verified_source["candidate"]["object_id"]:
                        raise AuthorizationError("final publication must use the declared candidate bytes")
                    publication_binding.update({key: verified_source[key] for key in ("candidate", "verification", "raw", "raw_publication")})
            parent_publication = None
            publications = admitted_spec.get("child_delegation", {}).get("publications")
            if publications is not None:
                result = body.get("result") or {}
                statuses = [result[key] for key in ("status", "overall_status") if key in result]
                if not statuses or any(not isinstance(status, str) or status != statuses[0] for status in statuses):
                    raise ValidationError("named publication parent requires one consistent H3 outcome")
                if statuses[0] == "task_failed":
                    raise ValidationError("task_failed must use fail_attempt, not successful settlement")
                if statuses[0] not in {"candidate_verified", "complete"}:
                    raise ValidationError("named publication parent H3 outcome is invalid")
                if statuses[0] == "complete":
                    states = result.get("states")
                    if not isinstance(states, dict) or any(
                            not isinstance(states.get(key), dict) or states[key].get("status") != "passed"
                            or not isinstance(states[key].get("evidence"), dict) or not states[key]["evidence"]
                            for key in ("editorially_approved", "cleanup_verified")):
                        raise ValidationError("complete requires editorial approval and cleanup evidence")
                    resources = states["cleanup_verified"]["evidence"].get("resources")
                    if (not isinstance(resources, list) or not resources
                            or any(not isinstance(resource, dict) or resource.get("verified") is not True for resource in resources)):
                        raise ValidationError("complete requires editorial approval and verified cleanup evidence")
                children = self.store.delegated_children(task["id"], attempt_id)
                final_children = [child for child in children if self.store._spec(child).get("delegated_stage") == publications["final"]["stage"]]
                if len(final_children) != 1:
                    raise ConflictError("parent requires its actual settled final publication")
                final_output = self._named_publication_association(final_children[0], publications["final"])
                if not isinstance(final_output["provenance"].get("delegated_publication"), dict):
                    raise ConflictError("parent requires its actual settled final publication")
                final_spec = self.store._spec(final_children[0])
                final_source = final_spec.get("verified_publication_source")
                final_lineage = final_spec.get("delegated_parent")
                expected_parent = {"parent_task_id": task["id"], "parent_attempt_id": attempt_id, "parent_fence": int(row["fence"]), "runtime_epoch": int(row["runtime_epoch"])}
                if (not isinstance(final_source, dict) or final_source.get("publication_name") != "final"
                        or not isinstance(final_lineage, dict) or any(final_lineage.get(key) != value for key, value in expected_parent.items())
                        or any(final_output["provenance"]["delegated_publication"].get(key) != value for key, value in expected_parent.items())):
                    raise ConflictError("parent final publication lineage does not match its current attempt")
                self._validate_named_publication_lineage(final_source, project_id, final_lineage)
                final_ref = {"producer_task_id": final_children[0]["id"], "producer_attempt_id": final_children[0]["attempt_id"], "association_id": final_output["association_id"], "object_id": final_output["object_id"], "output_port": final_output["output_port"]}
                final_effect = self._bound_named_final_publication_effect(publications["final"]["effect"], final_source)
                self._read_delegated_publication(final_ref, final_effect, project_id)
                if (final_output["object_id"] != final_source["candidate"]["object_id"]
                        or any(final_output["provenance"]["delegated_publication"].get(key) != final_source[key] for key in ("candidate", "verification", "raw", "raw_publication"))):
                    raise ConflictError("parent final publication binding no longer matches its frozen sources")
                parent_selected = self._named_publication_output(final_effect, body.get("outputs", []))
                if (parent_selected.get("digest") != final_output["object_id"]
                        or parent_selected.get("kind", "object") != "object"
                        or parent_selected.get("durability", "durable") != "durable"):
                    raise AuthorizationError("parent must retain the actual final publication output")
                parent_publication = final_output
            if _verified_objects is not None and (row["executor_id"] != MEDIA_IMPORT_EXECUTOR or task["capability"] != MEDIA_IMPORT_CAPABILITY):
                raise AuthorizationError("verified import proof requires the host import executor")
            staged = self._stage_outputs(
                attempt_id,
                body.get("outputs", []),
                project_id=project_id,
                attempt_row=row,
                task_row=task,
                lease_body=body,
                verified_objects=_verified_objects,
            )
            if publication_binding is not None:
                selected_staged = self._named_publication_output(declared, staged["outputs"])
                selected_staged["provenance"] = {**(selected_staged.get("provenance") or {}), "delegated_publication": publication_binding}
            if parent_publication is not None:
                output = self._named_publication_output(final_effect, staged["outputs"])
                binding = dict(parent_publication["provenance"]["delegated_publication"])
                binding.update({"source_association_id": parent_publication["association_id"], "source_task_id": parent_publication["task_id"], "source_attempt_id": parent_publication["attempt_id"]})
                output["provenance"] = {**(output.get("provenance") or {}), "delegated_publication": binding}
            try:
                # Persist one flat result object. Outputs are the only
                # reserved field and are added atomically with user fields.
                result = dict(body.get("result") or {})
                result["outputs"] = staged["outputs"]
                self._validate_terminal_manifest(staged, result, task, attempt_id, project_id)
                receipt_writer = (self._verification_receipt_writer(policy, admitted_spec, staged, result, project_id)
                                  if policy is not None else None)
                if verified_source is not None and verified_source.get("publication_name", "final") == "final":
                    manifest_digest = self.store._validated_manifest_digest(result, project_id=project_id)
                    self._require_candidate_verification_receipt(verified_source, manifest_digest)
                recorded = None
                def record(value, *, event_ids=(), primary_stream_id=None, resulting_stream_seq=None, created_at=None):
                    nonlocal recorded
                    recorded = self._command_record(
                        "attempt.settle", attempt_id, idempotency_key, request_hash,
                        self._task_resource(value), project_id=project_id or "unscoped",
                        event_ids=event_ids, primary_stream_id=primary_stream_id,
                        resulting_stream_seq=resulting_stream_seq,
                        created_at=created_at,
                    )
                self.store._settle_attempt(
                    row["task_id"], row["lease_id"], result,
                    effect=effect, fence=body["fence"], attempt_id=attempt_id,
                    duration_seconds_presence=staged["duration_seconds_presence"],
                    publish=lambda: self._publish_staged_outputs(staged, project_id=project_id),
                    record=record,
                    verification_receipt=receipt_writer,
                )
                staged["committed"] = True
                return recorded
            finally:
                self._discard_staged_outputs(staged)

    def publish_timeline_render(self, attempt_id, body, *, idempotency_key=None, identity=None):
        self._require_timeline_command()

    def _is_authorized_generic_output(
        self, digest, size, media_type, *, name, output_port, filename,
        recorded_filename, attempt_row, task_row, project_id, lease_body,
    ):
        """Recognize the worker's unscoped output upload receipt.

        Generic producers cannot create a project association during their
        upload. Settlement may adopt that exact object only when the
        unscoped upload's request hash carries the current task/run/project,
        attempt, executor, lease/fence, filename, and deterministic output
        key, and its durable result matches the descriptor.
        """
        if attempt_row is None or task_row is None or lease_body is None:
            return False
        try:
            canonical_recorded_filename = _canonical_managed_output_filename(recorded_filename)
        except ValidationError:
            return False
        if canonical_recorded_filename != filename:
            return False
        binding = {
            "project_id": project_id,
            "run_id": task_row["run_id"],
            "task_id": task_row["id"],
            "attempt_id": attempt_row["id"],
            "executor_id": attempt_row["executor_id"],
            "lease_id": lease_body["lease_id"],
            "fence": int(lease_body["fence"]),
            "runtime_epoch": int(lease_body["runtime_epoch"]),
            "output_key": name,
            "output_port": output_port,
            # Upload receipts are keyed by the producer's original name;
            # settlement stores its canonical flat managed name.
            "filename": recorded_filename,
            "digest": "sha256:" + digest,
            "size": int(size),
            "media_type": media_type,
        }
        idempotency_key = self._generic_output_idempotency_key(binding)
        row = self.store.conn.execute(
            "SELECT request_hash, result_json FROM command_idempotency "
            "WHERE command_kind='object.ingest' AND aggregate_id='objects' "
            "AND idempotency_key=?",
            (idempotency_key,),
        ).fetchone()
        if not row:
            return False
        try:
            result = json.loads(row["result_json"])
        except (TypeError, ValueError):
            return False
        if not isinstance(result, dict):
            return False
        expected_hash = self._generic_output_request_hash(
            digest, media_type, recorded_filename, None, binding,
        )
        if row["request_hash"] != expected_hash:
            return False
        try:
            recorded_size = int(result.get("size", -1))
        except (TypeError, ValueError):
            return False
        return (
            result.get("object_id") == "sha256:" + digest
            and result.get("digest") == "sha256:" + digest
            and recorded_size == int(size)
            and result.get("media_type") == media_type
        )

    @staticmethod
    def _validate_terminal_result_body(body):
        if "outputs" in body and not isinstance(body["outputs"], list):
            raise ValidationError("outputs must be a list")
        if "result" in body and not isinstance(body["result"], dict):
            raise ValidationError("result must be an object")
        if "outputs" in body.get("result", {}):
            raise ValidationError("result.outputs is reserved; send outputs at the top level")

    def _validate_terminal_manifest(self, staged, result, task, attempt_id, project_id):
        """Check managed producer correlation and refs against verified CAS bytes.

        Runtime validates portable identity, never producer scratch paths. Generic
        manifests remain opaque; the existing managed profile has a closed envelope.
        """
        manifest_digest = self.store._validated_manifest_digest(result, project_id=project_id)
        if manifest_digest is not None and not any(item["digest"] == manifest_digest for item in staged["items"]):
            self._verify_child_object_bytes(manifest_digest, result["manifest_ref"]["size"], label="result manifest CAS object")
        candidates = [item for item in staged["items"] if item["output_port"] == "result_manifest"]
        if not candidates:
            return
        if len(candidates) != 1:
            raise ValidationError("one result_manifest is required")
        manifest = candidates[0]
        if manifest["output"]["kind"] != "object" or manifest["durability"] != "durable":
            raise ValidationError("result_manifest must be a durable CAS object")
        if manifest["size"] > 16 * 1024 * 1024:
            raise ValidationError("result_manifest exceeds 16 MiB")
        path = manifest["path"] or self.cas.path_for(manifest["digest"])
        parent_fd = _open_directory_chain(path.parent)
        try:
            fd = os.open(path.name, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0), dir_fd=parent_fd)
            try:
                self._verify_open_file(fd, manifest["digest"], manifest["size"], label="result manifest")
                os.lseek(fd, 0, os.SEEK_SET)
                with os.fdopen(fd, "rb", closefd=False) as stream:
                    payload = json.load(stream)
            finally:
                os.close(fd)
        except (ValueError, UnicodeError) as exc:
            raise ValidationError("result_manifest must contain JSON") from exc
        finally:
            os.close(parent_fd)
        if not isinstance(payload, dict) or payload.get("kind") != "managed-generation-result.v1":
            return
        fields = {"schema_version", "kind", "inputs", "outputs", "created", "warnings", "task_id",
                  "attempt_id", "producer_run_id", "outcomes", "evidence"}
        if set(payload) != fields or type(payload["schema_version"]) is not int or payload["schema_version"] != 1:
            raise ValidationError("managed result has an invalid outer envelope")
        if payload["task_id"] != task["id"] or payload["attempt_id"] != attempt_id:
            raise ConflictError("managed result task/attempt identity does not match publication")
        if not isinstance(payload["producer_run_id"], str) or not payload["producer_run_id"].strip():
            raise ValidationError("managed result requires producer_run_id")
        try:
            created = datetime.fromisoformat(payload["created"].replace("Z", "+00:00"))
            if created.utcoffset() != timedelta(0):
                raise ValueError("UTC required")
        except (AttributeError, TypeError, ValueError) as exc:
            raise ValidationError("managed result created must be UTC") from exc
        if not isinstance(payload["warnings"], list) or any(not isinstance(w, str) for w in payload["warnings"]):
            raise ValidationError("managed result warnings must be strings")
        evidence = payload["evidence"]
        if (not isinstance(evidence, dict) or set(evidence) != {"producer", "transport"}
                or any(not isinstance(value, dict) for value in evidence.values())):
            raise ValidationError("managed result evidence namespaces are invalid")
        phases = {"execution", "retrieval", "verification", "publication"}
        outcomes = payload["outcomes"]
        if not isinstance(outcomes, dict) or set(outcomes) != phases:
            raise ValidationError("managed result outcomes are invalid")
        for outcome in outcomes.values():
            if (not isinstance(outcome, dict) or set(outcome) - {"status", "code", "message"}
                    or outcome.get("status") not in {"not_started", "pending", "succeeded", "failed", "cancelled", "interrupted"}
                    or any(not isinstance(value, str) for value in outcome.values())):
                raise ValidationError("managed result outcome is invalid")
        by_digest = {item["digest"]: item for item in staged["items"]}

        def verify_ref(reference):
            if not isinstance(reference, dict):
                raise ValidationError("managed result object ref must be an object")
            digest = reference.get("object_id", reference.get("digest", reference.get("sha256")))
            digest = digest.removeprefix("sha256:") if isinstance(digest, str) else ""
            size = reference.get("bytes", reference.get("size"))
            if not re.fullmatch("[0-9a-f]{64}", digest) or type(size) is not int or size < 0:
                raise ValidationError("managed result object ref requires sha256 and bytes")
            for key in ("sha256", "digest", "object_id"):
                if key in reference and reference[key] not in (digest, "sha256:" + digest):
                    raise ConflictError("managed result object ref hashes differ")
            if "bytes" in reference and "size" in reference and reference["bytes"] != reference["size"]:
                raise ConflictError("managed result object ref sizes differ")
            if digest in by_digest:
                if by_digest[digest]["size"] != size:
                    raise ConflictError("managed result ref size differs from output")
            else:
                obj = self.store.conn.execute("SELECT size FROM objects WHERE digest=?", (digest,)).fetchone()
                if not obj or obj["size"] != size or (project_id and not self.store.conn.execute(
                        "SELECT 1 FROM project_objects WHERE project_id=? AND digest=?", (project_id, digest)).fetchone()):
                    raise ConflictError("managed result ref is outside the task project")
                self._verify_child_object_bytes(digest, size, label="managed result evidence CAS object")
            return digest

        inputs = payload["inputs"]
        if not isinstance(inputs, dict):
            raise ValidationError("managed result inputs must be an object")
        for key in ("source", "effective_settings"):
            if key in inputs:
                verify_ref(inputs[key])
        outputs = payload["outputs"]
        if not isinstance(outputs, list):
            raise ValidationError("managed result outputs must be a list")
        seen = set()
        for output in outputs:
            required = {"producer_output_id", "output_port", "ordinal", "path", "media_type", "bytes", "sha256"}
            if (not isinstance(output, dict) or set(output) != required
                    or not isinstance(output["producer_output_id"], str) or not output["producer_output_id"]
                    or output["producer_output_id"] in seen or type(output["ordinal"]) is not int or output["ordinal"] < 0
                    or not isinstance(output["output_port"], str) or not output["output_port"]
                    or not isinstance(output["path"], str) or not output["path"]
                    or Path(output["path"]).is_absolute() or ".." in Path(output["path"]).parts
                    or not isinstance(output["media_type"], str)
                    or not isinstance(output["sha256"], str) or not re.fullmatch("[0-9a-f]{64}", output["sha256"])):
                raise ValidationError("managed result output identity is invalid")
            seen.add(output["producer_output_id"])
            digest = verify_ref(output)
            matched = [item for item in staged["items"] if item["digest"] == digest
                       and item["output"]["kind"] == "object"
                       and item["output_port"] == output["output_port"]
                       and item["output"].get("ordinal", 0) == output["ordinal"]
                       and item["media_type"] == output["media_type"]]
            if len(matched) != 1:
                raise ConflictError("managed result output differs from published output")
        expected_ref = {"object_id": "sha256:" + manifest["digest"], "size": manifest["size"]}
        if result.get("manifest_ref", expected_ref) != expected_ref:
            raise ConflictError("managed result manifest_ref differs from published manifest")
        result["manifest_ref"] = expected_ref

    def _stage_outputs(self, attempt_id, outputs, *, project_id=None, attempt_row=None, task_row=None, lease_body=None, verified_objects=None):
        """Validate and stage every output without making it globally reachable."""
        if not isinstance(outputs, list):
            raise ValidationError("outputs must be a list")
        stage_dir = self.store.attempt_staging_dir(attempt_id)
        stage_dir.mkdir(parents=True, exist_ok=True)
        if stage_dir.is_symlink() or not stage_dir.is_dir():
            raise ValidationError("attempt staging directory is invalid")
        platform.owner_only(stage_dir)
        staged = []
        duration_seconds_presence = {}
        seen = set()
        seen_digests = set()
        non_object_digests = set()
        try:
            for index, output in enumerate(outputs):
                if not isinstance(output, dict):
                    raise ValidationError("each output must be an object")
                allowed = {
                    "name", "filename", "output_port", "selector", "group_key", "variant_key", "generation_id",
                    "kind", "digest", "media_type", "size", "data_base64", "ordinal", "role",
                    "is_primary", "duration_seconds", "durability", "producer", "provenance",
                    "regeneration", "coverage",
                }
                unknown = sorted(set(output) - allowed)
                if unknown:
                    raise ValidationError("output contains unsupported fields", details={"fields": unknown})
                if output.get("role") == "recoverable_snapshot":
                    raise ValidationError("recoverable_snapshot is a Runtime-reserved output role")
                digest_value = output.get("digest")
                if not isinstance(digest_value, str) or not digest_value.startswith("sha256:"):
                    raise ValidationError("each output requires a sha256 digest")
                digest = digest_value.removeprefix("sha256:")
                if len(digest) != 64 or any(char not in "0123456789abcdef" for char in digest):
                    raise ValidationError("each output requires a valid SHA-256 digest")
                kind = output.get("kind", "object")
                if not isinstance(kind, str) or kind not in {"object", "document", "value"}:
                    raise ValidationError("output kind is invalid")
                if digest in non_object_digests or (kind != "object" and digest in seen_digests):
                    raise ValidationError("outputs must not contain duplicate digests")
                if kind != "object":
                    non_object_digests.add(digest)
                name = output.get("name", "output")
                if not isinstance(name, str) or not name or len(name) > 512:
                    raise ValidationError("output name must be a non-empty string")
                filename = _canonical_managed_output_filename(output.get("filename", name))
                media_type = output.get("media_type", "application/octet-stream")
                if not isinstance(media_type, str) or not media_type or len(media_type) > 255 or any(ord(char) < 32 for char in media_type):
                    raise ValidationError("output media_type is invalid")
                declared_size = output.get("size")
                if declared_size is not None and (isinstance(declared_size, bool) or not isinstance(declared_size, int) or declared_size < 0 or declared_size > OBJECT_MAX_BYTES):
                    raise ValidationError("output size must be an integer between 0 and 5 GiB")
                data_field = output.get("data_base64")
                stage_path = None
                if data_field is not None:
                    if not isinstance(data_field, str):
                        raise ValidationError("output data_base64 is invalid")
                    try:
                        data = base64.b64decode(data_field, validate=True)
                    except (ValueError, TypeError) as exc:
                        raise ValidationError("output data_base64 is invalid") from exc
                    if len(data) > OBJECT_MAX_BYTES:
                        raise ValidationError("output exceeds 5 GiB object limit")
                    actual_digest = sha256_bytes(data)
                    if actual_digest != digest:
                        raise ConflictError("output content hash does not match declared digest", details={"expected": digest_value, "actual": "sha256:" + actual_digest})
                    if declared_size is not None and declared_size != len(data):
                        raise ValidationError("output size does not match staged bytes")
                    stage_path = stage_dir / f"{index:08d}.stage"
                    with open(stage_path, "xb") as stream:
                        stream.write(data)
                        stream.flush()
                        os.fsync(stream.fileno())
                    size = len(data)
                else:
                    root_fd = prefix_fd = file_fd = -1
                    try:
                        try:
                            root_fd, prefix_fd = self._cas_prefix_fds(digest, create=False)
                        except (FileNotFoundError, OSError) as exc:
                            raise ConflictError(
                                "output must be staged or published to runtime CAS before settlement",
                                details={"digest": digest_value},
                            ) from exc
                        try:
                            file_fd = os.open(
                                digest[2:],
                                os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0),
                                dir_fd=prefix_fd,
                            )
                        except OSError as exc:
                            raise ConflictError(
                                "output must be staged or published to runtime CAS before settlement",
                                details={"digest": digest_value},
                            ) from exc
                        size = int(os.fstat(file_fd).st_size)
                        if size > OBJECT_MAX_BYTES:
                            raise ValidationError("output exceeds 5 GiB object limit")
                        if verified_objects is not None and digest in verified_objects:
                            if file_identity(os.fstat(file_fd)) != verified_objects[digest]:
                                raise ConflictError("verified imported CAS object changed")
                        else:
                            self._verify_open_file(file_fd, digest, size, label="CAS object")
                    finally:
                        if file_fd >= 0:
                            os.close(file_fd)
                        if prefix_fd >= 0:
                            os.close(prefix_fd)
                        if root_fd >= 0:
                            os.close(root_fd)
                    if declared_size is not None and declared_size != size:
                        raise ValidationError("output size does not match CAS bytes")
                # A digest identifies verified bytes, not an output descriptor.
                # Object outputs may share bytes while retaining their own
                # association filename and media type. Non-object outputs keep
                # their established uniqueness rule above.
                seen_digests.add(digest)
                ordinal = output.get("ordinal")
                if ordinal is not None and (isinstance(ordinal, bool) or not isinstance(ordinal, int) or ordinal < 0):
                    raise ValidationError("output ordinal must be a non-negative integer")
                role = output.get("role")
                if role is not None and (not isinstance(role, str) or not role or len(role) > 255 or any(ord(char) < 32 for char in role)):
                    raise ValidationError("output role is invalid")
                is_primary = output.get("is_primary")
                if is_primary is not None and not isinstance(is_primary, bool):
                    raise ValidationError("output is_primary must be a boolean")
                duration_seconds = output.get("duration_seconds")
                if duration_seconds is not None and (
                    isinstance(duration_seconds, bool)
                    or not isinstance(duration_seconds, (int, float))
                    or not math.isfinite(float(duration_seconds))
                    or float(duration_seconds) <= 0
                ):
                    raise ValidationError("output duration_seconds must be a positive finite number")
                output_port = output.get("output_port", name)
                if not isinstance(output_port, str) or not output_port or len(output_port) > 255 or any(ord(char) < 32 for char in output_port):
                    raise ValidationError("output_port is invalid")
                selector = output.get("selector")
                if selector is not None:
                    if not isinstance(selector, dict) or set(selector) != {"group_key", "variant_key"}:
                        raise ValidationError("output selector requires exactly group_key and variant_key")
                    if "group_key" not in output:
                        output["group_key"] = selector["group_key"]
                    if "variant_key" not in output:
                        output["variant_key"] = selector["variant_key"]
                group_key = output.get("group_key", "default")
                if not isinstance(group_key, str) or not group_key or len(group_key) > 255 or any(ord(char) < 32 for char in group_key):
                    raise ValidationError("output group_key is invalid")
                variant_key = output.get("variant_key", str(ordinal if ordinal is not None else 0))
                if not isinstance(variant_key, str) or len(variant_key) > 255 or any(ord(char) < 32 for char in variant_key):
                    raise ValidationError("output variant_key is invalid")
                # Content identity is shared by CAS objects; association
                # identity follows the existing port/group/variant/ordinal key.
                association_key = (output_port, group_key, variant_key, ordinal if ordinal is not None else 0)
                if kind == "object":
                    if association_key in seen:
                        raise ValidationError("outputs must not contain duplicate associations")
                    seen.add(association_key)
                generation_id = output.get("generation_id")
                if generation_id is not None and (not isinstance(generation_id, str) or not generation_id or len(generation_id) > 255):
                    raise ValidationError("output generation_id is invalid")
                durability = output.get("durability", "durable")
                if durability not in MANAGED_DURABILITIES:
                    raise ValidationError("output durability is invalid")
                if durability == "temporary" and is_primary is True:
                    raise ValidationError("primary outputs must be durable")
                producer = output.get("producer", {})
                provenance = output.get("provenance", {})
                if not isinstance(producer, dict) or not isinstance(provenance, dict):
                    raise ValidationError("output producer and provenance must be objects")
                if "delegated_publication" in provenance:
                    raise AuthorizationError("delegated publication provenance is Runtime-owned")
                regeneration = output.get("regeneration")
                if regeneration is not None:
                    regeneration = _validate_regeneration(regeneration)
                coverage = output.get("coverage")
                if coverage is not None:
                    coverage = _validate_coverage(coverage)
                existing = self.store.conn.execute("SELECT size, original_name FROM objects WHERE digest=?", (digest,)).fetchone()
                if existing:
                    if int(existing["size"]) != size:
                        raise ConflictError("output size does not match existing object", details={"digest": digest_value})
                    if project_id and not self.store.conn.execute("SELECT 1 FROM project_objects WHERE project_id=? AND digest=?", (project_id, digest)).fetchone():
                        has_project_owner = self.store.conn.execute(
                            "SELECT 1 FROM project_objects WHERE digest=? LIMIT 1", (digest,)
                        ).fetchone()
                        # The CAS row retains the first ingest's filename.
                        # Each association still needs its own exact receipt;
                        # retain the recorded filename for legacy normalization.
                        if has_project_owner or not any(self._is_authorized_generic_output(
                            digest,
                            size,
                            media_type,
                            name=name,
                            output_port=output_port,
                            filename=filename,
                            recorded_filename=recorded_filename,
                            attempt_row=attempt_row,
                            task_row=task_row,
                            project_id=project_id,
                            lease_body=lease_body,
                        ) for recorded_filename in (output.get("filename", name), existing["original_name"])):
                            raise ConflictError("output object is outside the task project", details={"project_id": project_id, "digest": digest_value})
                elif project_id and stage_path is None and not self.store.conn.execute("SELECT 1 FROM project_objects WHERE project_id=? AND digest=?", (project_id, digest)).fetchone():
                    raise ConflictError("output object is outside the task project", details={"project_id": project_id, "digest": digest_value})
                normalized = {
                    "name": name, "kind": kind, "digest": digest_value,
                    "media_type": media_type, "size": size,
                }
                # Keep the established settlement result wire stable.  The
                # association table/readback carries the defaulted filename,
                # port, group, and variant identity; echo an extended field
                # only when the producer explicitly supplied it.
                if "filename" in output:
                    normalized["filename"] = filename
                if "output_port" in output:
                    normalized["output_port"] = output_port
                if selector is not None:
                    normalized["selector"] = {"group_key": group_key, "variant_key": variant_key}
                if "group_key" in output:
                    normalized["group_key"] = group_key
                if "variant_key" in output:
                    normalized["variant_key"] = variant_key
                if generation_id is not None:
                    normalized["generation_id"] = generation_id
                if ordinal is not None:
                    normalized["ordinal"] = ordinal
                if role is not None:
                    normalized["role"] = role
                if is_primary is not None:
                    normalized["is_primary"] = is_primary
                if duration_seconds is not None:
                    normalized["duration_seconds"] = duration_seconds
                if "duration_seconds" in output:
                    duration_seconds_presence[(
                        output_port,
                        group_key,
                        variant_key,
                        int(ordinal if ordinal is not None else 0),
                    )] = duration_seconds
                if durability != "durable":
                    normalized["durability"] = durability
                if producer:
                    normalized["producer"] = producer
                if provenance:
                    normalized["provenance"] = provenance
                if regeneration is not None:
                    normalized["regeneration"] = regeneration
                if coverage is not None:
                    normalized["coverage"] = coverage
                staged.append({
                    "digest": digest, "path": stage_path, "size": size, "media_type": media_type,
                    "verified_identity": (verified_objects or {}).get(digest),
                    "name": name, "filename": filename, "output": normalized,
                    "output_port": output_port, "group_key": group_key, "variant_key": variant_key,
                    "generation_id": generation_id, "durability": durability, "producer": producer,
                    "provenance": provenance, "regeneration": regeneration, "coverage": coverage,
                })
            return {
                "stage_dir": stage_dir,
                "attempt_id": attempt_id,
                "items": staged,
                "outputs": [item["output"] for item in staged],
                # Keep explicit null presence transiently for missing-only
                # settlement enrichment; it is not part of the wire result.
                "duration_seconds_presence": duration_seconds_presence,
            }
        except Exception:
            self._discard_staged_outputs({"stage_dir": stage_dir, "items": staged})
            raise


    @staticmethod
    def _verify_open_file(file_fd, digest, expected_size, *, label):
        """Hash one already-open file without reopening its pathname."""
        try:
            initial = os.fstat(file_fd)
            if not stat.S_ISREG(initial.st_mode):
                raise ConflictError(f"{label} must be a regular file")
            if initial.st_size != expected_size:
                raise ConflictError(f"{label} size does not match staged metadata")
            os.lseek(file_fd, 0, os.SEEK_SET)
            hasher = hashlib.sha256()
            while True:
                chunk = os.read(file_fd, 1024 * 1024)
                if not chunk:
                    break
                hasher.update(chunk)
            final = os.fstat(file_fd)
        except OSError as exc:
            raise ConflictError(f"{label} is unavailable") from exc
        if (
            final.st_dev != initial.st_dev
            or final.st_ino != initial.st_ino
            or final.st_size != expected_size
            or final.st_mtime_ns != initial.st_mtime_ns
            or final.st_ctime_ns != initial.st_ctime_ns
            or hasher.hexdigest() != digest
        ):
            raise ConflictError(f"{label} hash or size does not match staged metadata")
        return initial

    def _cas_prefix_fds(self, digest, *, create):
        """Open a CAS digest prefix below descriptors, never through a path."""
        root_fd = _open_directory_chain(self.cas.root)
        try:
            prefix = digest[:2]
            if create:
                prefix_fd = _mkdir_chain_at(root_fd, prefix)
            else:
                prefix_fd = os.open(
                    prefix,
                    os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0),
                    dir_fd=root_fd,
                )
            try:
                if not stat.S_ISDIR(os.fstat(prefix_fd).st_mode):
                    raise ConflictError("CAS destination directory is invalid")
            except Exception:
                os.close(prefix_fd)
                raise
            return root_fd, prefix_fd
        except Exception:
            os.close(root_fd)
            raise

    @staticmethod
    def _copy_open_file_at(source_fd, destination_fd, destination_name, digest, expected_size, *, label):
        """Copy verified bytes to a private file, then atomically link it."""
        temporary_name = f".{destination_name}.{os.getpid()}-{uuid.uuid4().hex}.tmp"
        temporary_fd = -1
        linked = False
        try:
            initial = RuntimeService._verify_open_file(source_fd, digest, expected_size, label=label)
            temporary_fd = os.open(
                temporary_name,
                os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
                0o600,
                dir_fd=destination_fd,
            )
            os.lseek(source_fd, 0, os.SEEK_SET)
            hasher = hashlib.sha256()
            copied = 0
            while True:
                chunk = os.read(source_fd, 1024 * 1024)
                if not chunk:
                    break
                hasher.update(chunk)
                copied += len(chunk)
                view = memoryview(chunk)
                while view:
                    written = os.write(temporary_fd, view)
                    view = view[written:]
            final = os.fstat(source_fd)
            if (
                final.st_dev != initial.st_dev
                or final.st_ino != initial.st_ino
                or copied != expected_size
                or hasher.hexdigest() != digest
            ):
                raise ConflictError(f"{label} hash or size does not match staged metadata")
            os.fsync(temporary_fd)
            os.close(temporary_fd)
            temporary_fd = -1
            RuntimeService._verify_file_at(
                destination_fd, temporary_name, digest, expected_size, label="temporary CAS object",
            )
            try:
                os.stat(destination_name, dir_fd=destination_fd, follow_symlinks=False)
            except FileNotFoundError:
                pass
            else:
                raise ConflictError("CAS destination appeared during publication")
            os.link(
                temporary_name,
                destination_name,
                src_dir_fd=destination_fd,
                dst_dir_fd=destination_fd,
                follow_symlinks=False,
            )
            linked = True
            os.unlink(temporary_name, dir_fd=destination_fd)
        except OSError as exc:
            raise ConflictError(f"{label} is unavailable") from exc
        finally:
            if temporary_fd >= 0:
                os.close(temporary_fd)
            try:
                os.unlink(temporary_name, dir_fd=destination_fd)
            except OSError:
                pass
        RuntimeService._verify_file_at(destination_fd, destination_name, digest, expected_size, label="CAS object")
        return initial

    @staticmethod
    def _verify_file_at(directory_fd, name, digest, expected_size, *, label):
        try:
            file_fd = os.open(name, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0), dir_fd=directory_fd)
        except OSError as exc:
            raise ConflictError(f"{label} is unavailable") from exc
        try:
            RuntimeService._verify_open_file(file_fd, digest, expected_size, label=label)
        finally:
            os.close(file_fd)

    @staticmethod
    def _unlink_stage_entry(stage_fd, name, expected_stat=None):
        try:
            current = os.stat(name, dir_fd=stage_fd, follow_symlinks=False)
            if expected_stat is not None and (
                current.st_dev != expected_stat.st_dev or current.st_ino != expected_stat.st_ino
            ):
                return
            os.unlink(name, dir_fd=stage_fd)
        except FileNotFoundError:
            pass

    def _unlink_cas_destination(self, digest, *, create_prefix=False):
        """Unlink a CAS object relative to a descriptor-pinned prefix."""
        root_fd = prefix_fd = -1
        try:
            try:
                root_fd, prefix_fd = self._cas_prefix_fds(digest, create=create_prefix)
            except FileNotFoundError:
                return False
            try:
                os.unlink(digest[2:], dir_fd=prefix_fd)
            except FileNotFoundError:
                return False
            os.fsync(prefix_fd)
            return True
        finally:
            if prefix_fd >= 0:
                os.close(prefix_fd)
            if root_fd >= 0:
                os.close(root_fd)
    def _publish_staged_outputs(self, staged, *, project_id=None):
        """Publish already validated bytes as part of the settlement transaction."""
        staged.setdefault("published", [])
        candidate_entries = []
        task_id = None
        attempt_id = staged.get("attempt_id")
        if attempt_id:
            row = self.store.conn.execute("SELECT task_id FROM attempts WHERE id=?", (attempt_id,)).fetchone()
            task_id = row["task_id"] if row else None

        stage_identity = None
        stage_fd = -1
        cas_handles = {}
        try:
            if any(item["path"] is not None for item in staged["items"]):
                stage_identity, stage_fd, _ = _pin_directory(staged["stage_dir"])

            for item in staged["items"]:
                digest = item["digest"]
                if digest in cas_handles:
                    continue
                root_fd, prefix_fd = self._cas_prefix_fds(digest, create=True)
                cas_handles[digest] = (root_fd, prefix_fd)
                destination_name = digest[2:]
                try:
                    os.stat(destination_name, dir_fd=prefix_fd, follow_symlinks=False)
                    destination_exists = True
                except FileNotFoundError:
                    destination_exists = False
                except OSError as exc:
                    raise ConflictError("CAS destination is unavailable") from exc
                if item["path"] is not None and not destination_exists:
                    candidate_entries.append({"digest": digest})

            if candidate_entries:
                staged["journal_path"] = self._begin_cas_publication_journal(
                    "settlement", candidate_entries, project_id=project_id or "unscoped", task_id=task_id,
                )

            for item in staged["items"]:
                digest = item["digest"]
                _root_fd, prefix_fd = cas_handles[digest]
                destination_name = digest[2:]
                if item["path"] is not None:
                    source_name = item["path"].name
                    try:
                        source_fd = os.open(
                            source_name,
                            os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0),
                            dir_fd=stage_fd,
                        )
                    except OSError as exc:
                        raise ConflictError("staged output is unavailable") from exc
                    try:
                        source_stat = self._verify_open_file(
                            source_fd, digest, item["size"], label="staged output",
                        )
                        try:
                            destination_exists = os.stat(
                                destination_name, dir_fd=prefix_fd, follow_symlinks=False,
                            )
                        except FileNotFoundError:
                            destination_exists = None
                        except OSError as exc:
                            raise ConflictError("CAS destination is unavailable") from exc
                        if destination_exists is not None:
                            self._verify_file_at(
                                prefix_fd, destination_name, digest, item["size"], label="CAS object",
                            )
                        else:
                            self._copy_open_file_at(
                                source_fd, prefix_fd, destination_name, digest, item["size"],
                                label="staged output",
                            )
                            staged["published"].append(digest)
                            os.fsync(prefix_fd)
                        self._unlink_stage_entry(stage_fd, source_name, source_stat)
                    finally:
                        os.close(source_fd)
                else:
                    if item.get("verified_identity") is not None:
                        value = os.stat(destination_name, dir_fd=prefix_fd, follow_symlinks=False)
                        if not stat.S_ISREG(value.st_mode) or file_identity(value) != item["verified_identity"]:
                            raise ConflictError("verified imported CAS object changed")
                    else:
                        self._verify_file_at(
                            prefix_fd, destination_name, digest, item["size"], label="CAS object",
                        )
                # The output's filename (defaulted to its name), not the port
                # name: "vibecomfy_run" is a port, "0000-SaveVideo.mp4" a file.
                self.store.conn.execute(
                    "INSERT OR IGNORE INTO objects(digest, size, media_type, original_name, created_at) VALUES (?, ?, ?, ?, ?)",
                    (digest, item["size"], item["media_type"], item["filename"], now()),
                )
                if project_id:
                    self.store.conn.execute(
                        "INSERT OR IGNORE INTO project_objects(project_id, digest, relation, created_at) VALUES (?, ?, 'managed', ?)",
                        (project_id, digest, now()),
                    )
        finally:
            if stage_fd >= 0:
                os.close(stage_fd)
            if stage_identity is not None:
                _close_pinned(stage_identity)
            for root_fd, prefix_fd in cas_handles.values():
                os.close(prefix_fd)
                os.close(root_fd)


    def _discard_staged_outputs(self, staged):
        stage_dir = staged.get("stage_dir") if isinstance(staged, dict) else None
        committed = bool(staged.get("committed")) if isinstance(staged, dict) else False

        if stage_dir is not None:
            stage_identity = None
            stage_fd = -1
            try:
                stage_identity, stage_fd, stage_stat = _pin_directory(stage_dir)
            except (OSError, ConflictError):
                # Never fall back to pathname unlinking when the staging
                # directory cannot be descriptor-pinned.
                pass
            else:
                try:
                    try:
                        for entry in os.scandir(stage_fd):
                            entry_stat = entry.stat(follow_symlinks=False)
                            if stat.S_ISREG(entry_stat.st_mode) or stat.S_ISLNK(entry_stat.st_mode):
                                os.unlink(entry.name, dir_fd=stage_fd)
                        os.fsync(stage_fd)
                    except OSError:
                        pass
                    parent_fd = stage_identity.get("_parent_fd")
                    if parent_fd is not None:
                        try:
                            current = os.stat(
                                stage_dir.name, dir_fd=int(parent_fd), follow_symlinks=False,
                            )
                            if (
                                stat.S_ISDIR(current.st_mode)
                                and current.st_dev == stage_stat.st_dev
                                and current.st_ino == stage_stat.st_ino
                            ):
                                os.rmdir(stage_dir.name, dir_fd=int(parent_fd))
                                os.fsync(int(parent_fd))
                        except OSError:
                            pass
                finally:
                    os.close(stage_fd)
                    _close_pinned(stage_identity)

        if not committed:
            for digest in (staged.get("published", []) if isinstance(staged, dict) else []):
                try:
                    if len(digest) == 64 and all(char in "0123456789abcdef" for char in digest):
                        self._unlink_cas_destination(digest)
                except (FileNotFoundError, OSError, ConflictError):
                    continue

    def _checkpoint_row(self, checkpoint_id=None, attempt_id=None):
        if checkpoint_id:
            row = self.store.conn.execute("SELECT * FROM recovery_checkpoints WHERE id=?", (checkpoint_id,)).fetchone()
            if row and attempt_id is not None and row["attempt_id"] != attempt_id:
                raise LeaseError("checkpoint is bound to a different attempt")
        else:
            row = self.store.conn.execute("SELECT * FROM recovery_checkpoints WHERE attempt_id=? ORDER BY created_at DESC LIMIT 1", (attempt_id,)).fetchone()
        if not row:
            raise NotFoundError("recovery checkpoint not found")
        attempt = self.store.conn.execute("SELECT task_id, executor_id, lease_id, fence FROM attempts WHERE id=?", (row["attempt_id"],)).fetchone()
        if not attempt or attempt["task_id"] != row["task_id"] or attempt["executor_id"] != row["executor_id"] or attempt["lease_id"] != row["lease_id"] or int(attempt["fence"]) != int(row["fence"]):
            raise ConflictError("recovery checkpoint identity is inconsistent")
        return row

    def _reboot_authorized(self, body, attempt_id, expected_nonce=None, *, allow_consumed=False):
        """Validate durable, attempt-bound recovery authorization.

        A nonce supplied by a caller is not sufficient by itself.  It must be
        the nonce persisted by ``prepare_reboot`` for this exact attempt and
        must still be within its short validity window.
        """
        self.store.assert_attempt_not_abandoned(attempt_id)
        attempt = self.store.conn.execute("SELECT recovery_nonce, recovery_nonce_expires_at, recovery_nonce_used FROM attempts WHERE id=?", (attempt_id,)).fetchone()
        nonce = attempt["recovery_nonce"] if attempt else None
        if "authorization_nonce" in body:
            raise ValidationError("authorization_nonce is not supported; use authorization")
        authorization = body.get("authorization")
        supplied = body.get("nonce")
        if not nonce:
            raise ValidationError("prepare_reboot is required before recovery")
        if attempt["recovery_nonce_used"] and not allow_consumed:
            raise ConflictError("recovery authorization has already been consumed")
        if attempt["recovery_nonce_expires_at"] and attempt["recovery_nonce_expires_at"] <= now():
            raise ValidationError("recovery authorization has expired")
        if not supplied or not authorization or str(supplied) != str(nonce) or str(authorization) != str(nonce) or (expected_nonce is not None and str(expected_nonce) != str(nonce)):
            raise ValidationError("recovery nonce authorization is required")
        return nonce

    def _validate_attempt_lease(self, row, body, current, *, require_epoch=True, allow_expired=False):
        """Validate the complete attempt fence before a mutating side effect."""
        if require_epoch:
            self.store._validate_runtime_epoch(
                body.get("runtime_epoch"),
                identity="executor",
                identity_id=row["executor_id"] if row else None,
                required=True,
            )
        if not row or row["settled"] or int(row["runtime_epoch"]) != current:
            raise LeaseError("attempt lease is stale or already settled")
        try:
            supplied_fence = int(body.get("fence", 0))
        except (TypeError, ValueError) as exc:
            raise LeaseError("attempt fence is invalid") from exc
        if row["lease_id"] != body.get("lease_id") or int(row["fence"]) != supplied_fence:
            raise LeaseError("attempt lease is stale or already settled")
        if not allow_expired and row["lease_expires_at"]:
            try:
                if datetime.fromisoformat(row["lease_expires_at"]) <= datetime.now(timezone.utc):
                    raise LeaseError("attempt lease has expired")
            except ValueError as exc:
                raise LeaseError("attempt lease deadline is invalid") from exc
    @_verified_mutation
    def prepare_reboot(self, body=None, *, identity=None):
        """Issue a one-shot nonce for an attempt's recovery handshake."""
        raw_body = {} if body is None else body
        _require_runtime_epoch_for_lease(raw_body)
        body = _wire_object(
            raw_body,
            required=("attempt_id", "lease_id", "fence", "runtime_epoch"),
            allowed=("attempt_id", "lease_id", "fence", "runtime_epoch"),
        )
        attempt_id = _wire_string(body, "attempt_id")
        _wire_string(body, "lease_id")
        _wire_integer(body, "fence")
        _wire_integer(body, "runtime_epoch", positive=True)
        with self.store._mutex:
            row = self.store.conn.execute("SELECT * FROM attempts WHERE id=?", (attempt_id,)).fetchone()
            self._assert_attempt_identity(row, identity)
            if not row or row["settled"]:
                raise LeaseError("attempt lease is stale or already settled")
            current = self.store._current_runtime_epoch()
            self._validate_attempt_lease(row, body, current)
            with self.store._transaction():
                current_row = self.store.conn.execute("SELECT recovery_nonce, recovery_nonce_expires_at, recovery_nonce_used FROM attempts WHERE id=?", (attempt_id,)).fetchone()
                if current_row["recovery_nonce"] and not current_row["recovery_nonce_used"] and (not current_row["recovery_nonce_expires_at"] or current_row["recovery_nonce_expires_at"] > now()):
                    nonce = current_row["recovery_nonce"]
                    expires_at = current_row["recovery_nonce_expires_at"]
                else:
                    nonce = new_id() + new_id()
                    expires_at = (datetime.now(timezone.utc) + timedelta(seconds=300)).isoformat(timespec="milliseconds")
                    self.store.conn.execute("UPDATE attempts SET recovery_nonce=?, recovery_nonce_expires_at=?, recovery_nonce_used=0 WHERE id=? AND settled=0", (nonce, expires_at, attempt_id))
        expires_in = max(0, int((datetime.fromisoformat(expires_at) - datetime.now(timezone.utc)).total_seconds()))
        return {"attempt_id": attempt_id, "task_id": row["task_id"], "executor_id": row["executor_id"], "runtime_epoch": current, "nonce": nonce, "expires_in_seconds": expires_in}

    @_verified_mutation
    def checkpoint_attempt(self, attempt_id, body, *, identity=None):
        """Persist a bounded, fsync'd R1 checkpoint before a reboot request."""
        body = _wire_object(
            body,
            required=("lease_id", "fence", "nonce", "authorization", "runtime_epoch"),
            allowed=("lease_id", "fence", "nonce", "authorization", "runtime_epoch", "checkpoint", "state"),
        )
        if not isinstance(attempt_id, str) or not attempt_id:
            raise ValidationError("attempt_id is required")
        _wire_string(body, "lease_id")
        _wire_integer(body, "fence")
        _wire_string(body, "nonce")
        _wire_string(body, "authorization")
        _wire_integer(body, "runtime_epoch", positive=True)
        with self.store._mutex:
            row = self.store.conn.execute("SELECT * FROM attempts WHERE id=?", (attempt_id,)).fetchone()
            self._assert_attempt_identity(row, identity)
            current = self.store._current_runtime_epoch()
            self._validate_attempt_lease(row, body, current)
            nonce = self._reboot_authorized(body, attempt_id)
            payload = body.get("checkpoint", body.get("state", {}))
            if not isinstance(payload, (dict, list)):
                raise ValidationError("checkpoint must be an object or array")
            durable_bytes = durable_json_bytes(payload)
            if len(durable_bytes) > CHECKPOINT_MAX_BYTES:
                raise ValidationError("recovery checkpoint exceeds 1 MiB bound")
            # A repeated request with the same durable authorization and bytes
            # is idempotent.  A different payload is a conflict, never a new
            # checkpoint that could be resumed accidentally.
            existing = self.store.conn.execute("SELECT * FROM recovery_checkpoints WHERE attempt_id=? AND nonce=? ORDER BY created_at DESC LIMIT 1", (attempt_id, nonce)).fetchone()
            if existing:
                existing_bytes = Path(existing["checkpoint_path"]).read_bytes()
                if sha256_bytes(existing_bytes) != existing["checkpoint_digest"] or json.loads(existing_bytes.decode("utf-8")) != payload:
                    raise ConflictError("recovery checkpoint authorization already binds different bytes")
                return {"checkpoint_id": existing["id"], "attempt_id": existing["attempt_id"], "task_id": existing["task_id"], "runtime_epoch": existing["runtime_epoch"], "nonce": nonce, "digest": "sha256:" + existing["checkpoint_digest"], "size": existing["checkpoint_size"], "state": existing["state"], "path": existing["checkpoint_path"]}
            checkpoint_id = new_id()
            path = self.store.root / "checkpoints" / f"{checkpoint_id}.json"
            root_identity, root_fd, _ = _pin_directory(self.store.root)
            checkpoints_fd = -1
            try:
                checkpoints_fd = _mkdir_chain_at(root_fd, "checkpoints")
                _write_bytes_at(checkpoints_fd, f"{checkpoint_id}.json", durable_bytes)
                os.fsync(checkpoints_fd)
            finally:
                if checkpoints_fd >= 0:
                    os.close(checkpoints_fd)
                os.close(root_fd)
                _close_pinned(root_identity)
            if durable_bytes != durable_json_bytes(payload):
                raise ConflictError("checkpoint serializer changed while writing")
            digest = sha256_bytes(durable_bytes)
            # atomic_json_write fsyncs the file; fsync the containing directory
            # as well so the rename survives a sudden power loss.
            timestamp = now()
            with self.store._transaction():
                self.store.conn.execute("INSERT INTO recovery_checkpoints(id, attempt_id, task_id, executor_id, runtime_epoch, lease_id, fence, nonce, checkpoint_path, checkpoint_digest, checkpoint_size, state, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'durable', ?, ?)", (checkpoint_id, attempt_id, row["task_id"], row["executor_id"], current, row["lease_id"], row["fence"], nonce, str(path), digest, len(durable_bytes), timestamp, timestamp))
            return {"checkpoint_id": checkpoint_id, "attempt_id": attempt_id, "task_id": row["task_id"], "runtime_epoch": current, "nonce": nonce, "digest": "sha256:" + digest, "size": len(durable_bytes), "state": "durable", "path": str(path)}

    create_checkpoint = checkpoint_attempt

    def request_reboot(self, body, *, identity=None):
        """Execute only an allowlisted reboot command after durable checkpointing."""
        body = _wire_object(
            body,
            required=("nonce", "authorization", "runtime_epoch"),
            allowed=("checkpoint_id", "attempt_id", "nonce", "authorization", "runtime_epoch", "command"),
        )
        _wire_string(body, "nonce")
        _wire_string(body, "authorization")
        _wire_integer(body, "runtime_epoch", positive=True)
        for field in ("checkpoint_id", "attempt_id"):
            if field in body and body[field] is not None:
                _wire_string(body, field)
        if "command" in body and body["command"] is not None:
            _wire_string(body, "command")
        # Claim and consume the one-shot authorization in the same SQLite
        # transaction as the durable-state transition.  The executor is
        # intentionally called after commit (it may block or terminate the
        # process), but no competing request can pass the claim meanwhile.
        with self.store._mutex:
            self._assert_mutation_admitted()
            current = self.store._validate_runtime_epoch(body.get("runtime_epoch"), identity="executor", required=True)
            row = self._checkpoint_row(body.get("checkpoint_id"), body.get("attempt_id"))
            self._assert_attempt_identity(row, identity)
            if row["state"] in {"executed", "resumed"} and row["recovery_receipt_json"]:
                # A completed request is safely replayable, but still require
                # the exact original nonce and authorization.
                self._reboot_authorized(body, row["attempt_id"], row["nonce"], allow_consumed=True)
                return json.loads(row["recovery_receipt_json"])
            self._reboot_authorized(body, row["attempt_id"], row["nonce"])
            command = str(body.get("command") or "reboot")
            if command not in self.reboot_allowlist:
                raise ValidationError("reboot command is not allowlisted", details={"command": command, "allowlist": sorted(self.reboot_allowlist)})
            if int(row["runtime_epoch"]) != self.store._current_runtime_epoch():
                raise LeaseError("reboot checkpoint belongs to a stale runtime epoch")
            attempt = self.store.conn.execute("SELECT * FROM attempts WHERE id=?", (row["attempt_id"],)).fetchone()
            self._validate_attempt_lease(attempt, {**body, "lease_id": row["lease_id"], "fence": row["fence"]}, current)
            checkpoint_bytes = Path(row["checkpoint_path"]).read_bytes()
            if sha256_bytes(checkpoint_bytes) != row["checkpoint_digest"]:
                raise ConflictError("recovery checkpoint digest mismatch")
            checkpoint = json.loads(checkpoint_bytes.decode("utf-8"))
            if row["state"] != "durable":
                raise ConflictError("reboot has already been requested", details={"state": row["state"]})
            if self.reboot_executor is None:
                raise ConflictError("reboot executor is unavailable; tests must inject a safe executor")
            timestamp = now()
            with self.store._transaction():
                consumed = self.store.conn.execute("UPDATE attempts SET recovery_nonce_used=1 WHERE id=? AND recovery_nonce_used=0", (row["attempt_id"],))
                if consumed.rowcount != 1:
                    raise ConflictError("recovery authorization has already been consumed")
                claimed = self.store.conn.execute("UPDATE recovery_checkpoints SET state='reboot_requested', updated_at=? WHERE id=? AND state='durable'", (timestamp, row["id"]))
                if claimed.rowcount != 1:
                    raise ConflictError("reboot has already been requested", details={"state": row["state"]})
        executor = self.reboot_executor
        import inspect
        try:
            signature = inspect.signature(executor)
        except (TypeError, ValueError):
            # Some extension/callable objects do not expose a signature.  A
            # single positional invocation is the only safe fallback; never
            # retry after a TypeError raised by the executor itself.
            call = lambda: executor(command, checkpoint)
        else:
            try:
                signature.bind(command=command, checkpoint=checkpoint)
            except TypeError:
                signature.bind(command, checkpoint)
                call = lambda: executor(command, checkpoint)
            else:
                call = lambda: executor(command=command, checkpoint=checkpoint)
        try:
            outcome = call()
        except Exception as exc:
            failure = {"type": "runtime.recovery.receipt", "version": 1, "checkpoint_id": row["id"], "attempt_id": row["attempt_id"], "task_id": row["task_id"], "runtime_epoch": current, "command": command, "status": "failed", "error": {"type": type(exc).__name__, "message": str(exc)}}
            with self.store._mutex:
                with self.store._transaction():
                    self.store.conn.execute("UPDATE recovery_checkpoints SET state='executor_failed', recovery_receipt_json=?, updated_at=? WHERE id=? AND state='reboot_requested'", (canonical_json(failure), now(), row["id"]))
            raise
        receipt = {"type": "runtime.recovery.receipt", "version": 1, "checkpoint_id": row["id"], "attempt_id": row["attempt_id"], "task_id": row["task_id"], "runtime_epoch": self.store._current_runtime_epoch(), "command": command, "status": "executed", "executor_result": outcome}
        with self.store._mutex:
            with self.store._transaction():
                self.store.conn.execute("UPDATE recovery_checkpoints SET state='executed', recovery_receipt_json=?, updated_at=? WHERE id=? AND state='reboot_requested'", (canonical_json(receipt), now(), row["id"]))
        return receipt

    @_verified_mutation
    def resume_attempt(self, body, *, identity=None):
        if isinstance(identity, dict):
            self._assert_local_claim_admission(identity.get("actor"), identity=identity)
        body = _wire_object(
            body,
            required=("nonce", "authorization", "runtime_epoch"),
            allowed=("checkpoint_id", "attempt_id", "nonce", "authorization", "runtime_epoch"),
        )
        _wire_string(body, "nonce")
        _wire_string(body, "authorization")
        _wire_integer(body, "runtime_epoch", positive=True)
        for field in ("checkpoint_id", "attempt_id"):
            if field in body and body[field] is not None:
                _wire_string(body, field)
        def attempt_resource(attempt):
            task_value = self.store.get_task(attempt["task_id"])
            admitted_spec, generation_intent = public_task_spec(task_value["task"].get("spec") or {})
            if task_value["task"].get("generation_intent") is not None:
                generation_intent = task_value["task"]["generation_intent"]
            resource = {
                "attempt_id": attempt["id"],
                "task_id": attempt["task_id"],
                "run_id": task_value["run"]["id"],
                "project_id": task_value["run"].get("project_id"),
                "lease_id": attempt["lease_id"],
                "fence": attempt["fence"],
                "lease_expires_at": attempt["lease_expires_at"],
                "runtime_epoch": attempt["runtime_epoch"],
                "input_object_ids": list(admitted_spec.get("input_object_ids") or []),
                "spec": admitted_spec,
            }
            if generation_intent is not None:
                resource["generation_intent"] = generation_intent
            binding = self.store.execution_binding(attempt["task_id"])
            if binding is not None:
                resource["execution_binding"] = binding
            return resource

        with self.store._mutex:
            current = self.store._validate_runtime_epoch(body.get("runtime_epoch"), identity="executor", required=True)
            row = self._checkpoint_row(body.get("checkpoint_id"), body.get("attempt_id"))
            self._assert_attempt_identity(row, identity)
            attempt_owner = self.store.conn.execute("SELECT executor_id FROM attempts WHERE id=?", (row["attempt_id"],)).fetchone()
            if attempt_owner is None:
                raise ConflictError("resume executor is unresolved")
            self._assert_local_claim_admission(attempt_owner["executor_id"], identity=identity)
            # Fence validation precedes even a consumed checkpoint replay.
            # request_reboot consumes the one-shot authorization. The exact
            # consumed token remains the authorization for this checkpoint's
            # one successful resume; it is not a newly reusable nonce.
            self._reboot_authorized(body, row["attempt_id"], row["nonce"], allow_consumed=True)
            if row["state"] == "resumed" and row["recovery_receipt_json"]:
                receipt = json.loads(row["recovery_receipt_json"])
                self.store.assert_attempt_not_abandoned(receipt["attempt_id"])
                attempt = self.store.conn.execute("SELECT * FROM attempts WHERE id=?", (receipt["attempt_id"],)).fetchone()
                if attempt:
                    return {"receipt": receipt, "attempt": attempt_resource(attempt)}
            activation = identity.get("qualified_activation") if isinstance(identity, dict) else None
            owner_id = activation.get("task_id") if isinstance(activation, dict) else row["task_id"]
            if self._task_drain(owner_id) is not None:
                raise ConflictError("remote drain blocks fresh checkpoint resume")
            if row["state"] not in {"recovered", "reboot_requested", "executed"}:
                raise ConflictError("checkpoint is not ready for resume", details={"state": row["state"]})
            checkpoint_bytes = Path(row["checkpoint_path"]).read_bytes()
            if sha256_bytes(checkpoint_bytes) != row["checkpoint_digest"]:
                raise ConflictError("recovery checkpoint digest mismatch")
            checkpoint = json.loads(checkpoint_bytes.decode("utf-8"))
            binding = self.store.execution_binding(row["task_id"])
            placement = self._trusted_execution_placement(identity)
            if binding is not None:
                if placement is None:
                    raise AuthorizationError("worker credential has no execution placement")
                if not execution_placement_matches(binding["resolved_target"], placement):
                    raise AuthorizationError("worker credential placement cannot resume this task")
                if not self._placement_recovery_qualification_matches(row["task_id"], placement):
                    raise AuthorizationError("worker credential qualification cannot resume this task")
                self.store.reset_execution_attempt(row["task_id"], runtime_epoch=current)
            # Claim this exact task.  Never use claim_next here: a mismatch
            # must not consume an unrelated queued task.
            lease_id = new_id()
            claim = self.store._claim_task(
                row["task_id"], row["executor_id"], lease_id,
                runtime_epoch=current, allow_provider_recovery=True,
            )
            task = claim["task"]
            if task.get("status") != "running" or task.get("id") != row["task_id"]:
                raise ConflictError("checkpoint task is not queued for resume")
            attempt_id = new_id()
            with self.store._transaction():
                self.store.conn.execute("INSERT INTO attempts(id, task_id, lease_id, fence, executor_id, lease_expires_at, settled, runtime_epoch) VALUES (?, ?, ?, ?, ?, ?, 0, ?)", (attempt_id, row["task_id"], lease_id, task["lease_fence"], row["executor_id"], task["lease_expires_at"], current))
                self.store.conn.execute("UPDATE tasks SET attempt_id=? WHERE id=? AND status='running'", (attempt_id, row["task_id"]))
                resumed_binding = self.store.bind_execution_attempt(
                    row["task_id"], attempt_id=attempt_id, lease_id=lease_id,
                    fence=task["lease_fence"], executor_id=row["executor_id"],
                    runtime_epoch=current, placement=placement,
                ) if binding is not None else None
                if resumed_binding is not None:
                    self.store._append_event(
                        task["run_id"], row["task_id"], "task.execution_bound",
                        {
                            "attempt_id": attempt_id,
                            "lease_id": lease_id,
                            "fence": task["lease_fence"],
                            "runtime_epoch": current,
                            "execution_binding": resumed_binding,
                            "recovery": "checkpoint_authorized_resume",
                        },
                    )
            resumed_attempt = self.store.conn.execute("SELECT * FROM attempts WHERE id=?", (attempt_id,)).fetchone()
            receipt = {"type": "runtime.recovery.receipt", "version": 1, "checkpoint_id": row["id"], "attempt_id": resumed_attempt["id"], "task_id": row["task_id"], "runtime_epoch": current, "command": "resume", "status": "resumed", "checkpoint_digest": "sha256:" + row["checkpoint_digest"], "checkpoint": checkpoint}
            with self.store._transaction():
                self.store.conn.execute("UPDATE recovery_checkpoints SET state='resumed', recovery_receipt_json=?, updated_at=? WHERE id=? AND state IN ('recovered', 'reboot_requested', 'executed')", (canonical_json(receipt), now(), row["id"]))
            return {"receipt": receipt, "attempt": attempt_resource(resumed_attempt)}

    resume = resume_attempt

    @_verified_mutation
    def heartbeat_attempt(self, attempt_id, body, *, idempotency_key=None, identity=None):
        idempotency_key = require_idempotency_key(idempotency_key)
        _require_runtime_epoch_for_lease(body)
        body = _wire_object(
            body,
            required=("lease_id", "fence", "runtime_epoch"),
            allowed=("lease_id", "fence", "runtime_epoch", "lease_seconds", "progress"),
        )
        _wire_string(body, "lease_id")
        # Fence zero is deliberately accepted as a typed stale fence. The
        # lease validator must classify it as LeaseError, not ValidationError.
        _wire_integer(body, "fence")
        _wire_integer(body, "runtime_epoch", positive=True)
        if "lease_seconds" in body and (
            isinstance(body["lease_seconds"], bool)
            or not isinstance(body["lease_seconds"], int)
            or body["lease_seconds"] <= 0
        ):
            raise ValidationError("lease_seconds must be a positive integer")
        progress = body.get("progress")
        if progress is not None:
            if not isinstance(progress, Mapping):
                raise ValidationError("progress must be an object")
            unexpected = set(progress) - {"phase", "percent", "current", "total"}
            if unexpected:
                raise ValidationError("progress contains unsupported fields", details={"fields": sorted(unexpected)})
            normalized_progress = {}
            if "phase" in progress:
                phase = progress["phase"]
                if not isinstance(phase, str) or not phase.strip() or len(phase) > 128:
                    raise ValidationError("progress.phase must be a non-empty string of at most 128 characters")
                normalized_progress["phase"] = phase.strip()
            for key in ("percent", "current", "total"):
                if key not in progress:
                    continue
                value = progress[key]
                if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(float(value)):
                    raise ValidationError(f"progress.{key} must be a finite number")
                if key == "percent" and not 0 <= float(value) <= 100:
                    raise ValidationError("progress.percent must be between 0 and 100")
                if key == "total" and float(value) < 1:
                    raise ValidationError("progress.total must be at least 1")
                if key == "current" and float(value) < 0:
                    raise ValidationError("progress.current must be non-negative")
                normalized_progress[key] = value
            if not normalized_progress:
                raise ValidationError("progress must contain phase, percent, current, or total")
            body["progress"] = normalized_progress
        with self.store._mutex:
            row = self.store.conn.execute("SELECT * FROM attempts WHERE id=?", (attempt_id,)).fetchone()
            self._assert_attempt_identity(row, identity)
            current = self.store._current_runtime_epoch()
            self.store._validate_runtime_epoch(body.get("runtime_epoch"), identity="executor", identity_id=row["executor_id"] if row else None, required=True)
            task = self.store.conn.execute("SELECT * FROM tasks WHERE id=?", (row["task_id"],)).fetchone() if row else None
            project_id = self.store.conn.execute("SELECT project_id FROM runs WHERE id=?", (task["run_id"],)).fetchone()[0] if task else "unscoped"
            request_hash = hashlib.sha256(canonical_json({"attempt_id": attempt_id, "body": body}).encode()).hexdigest()
            replay = self._command_replay("attempt.heartbeat", attempt_id, idempotency_key, request_hash, project_id=project_id or "unscoped")
            if replay is not None:
                return replay
            self.store.reap_overdue_leases()
            row = self.store.conn.execute("SELECT * FROM attempts WHERE id=?", (attempt_id,)).fetchone()
            self._validate_attempt_lease(row, body, current)
            recorded = None
            def record(value):
                nonlocal recorded
                expires = value["task"].get("lease_expires_at")
                self.store.conn.execute("UPDATE attempts SET lease_expires_at=? WHERE id=?", (expires, attempt_id))
                if progress is not None:
                    self.store._append_event(task["run_id"], row["task_id"], "task.progress", progress)
                result = {"attempt_id": attempt_id, "task_id": row["task_id"], "lease_id": row["lease_id"], "fence": row["fence"], "lease_expires_at": expires, "runtime_epoch": self.store._current_runtime_epoch()}
                recorded = self._command_record("attempt.heartbeat", attempt_id, idempotency_key, request_hash, result, project_id=project_id or "unscoped")
            self.store.heartbeat_task(row["task_id"], row["lease_id"], fence=row["fence"], lease_seconds=body.get("lease_seconds", 30), record=record)
            return recorded

    @_verified_mutation
    def fail_attempt(self, attempt_id, body, *, idempotency_key=None, identity=None):
        idempotency_key = require_idempotency_key(idempotency_key)
        _require_runtime_epoch_for_lease(body)
        body = _wire_object(
            body,
            required=("lease_id", "fence", "runtime_epoch"),
            allowed=("lease_id", "fence", "runtime_epoch", "error", "reason", "outputs", "result"),
        )
        _wire_string(body, "lease_id")
        # A typed fence of zero is stale lease state, not malformed wire.
        _wire_integer(body, "fence")
        _wire_integer(body, "runtime_epoch", positive=True)
        self._validate_terminal_result_body(body)
        with self.store._mutex:
            row = self.store.conn.execute("SELECT * FROM attempts WHERE id=?", (attempt_id,)).fetchone()
            self._assert_attempt_identity(row, identity)
            if not row:
                raise LeaseError("attempt lease is stale or already settled")
            current = self.store._current_runtime_epoch()
            task = self.store.conn.execute("SELECT * FROM tasks WHERE id=?", (row["task_id"],)).fetchone() if row else None
            project_id = self.store.conn.execute("SELECT project_id FROM runs WHERE id=?", (task["run_id"],)).fetchone()[0] if task else "unscoped"
            request_hash = hashlib.sha256(canonical_json({"attempt_id": attempt_id, "body": body}).encode()).hexdigest()
            replay = self._command_replay("attempt.fail", attempt_id, idempotency_key, request_hash, project_id=project_id or "unscoped")
            if replay is not None:
                return replay
            publishing = "outputs" in body or "result" in body
            self._validate_attempt_lease(row, body, current, allow_expired=not publishing)
            if "reason" in body:
                raise ValidationError("reason is not supported; use error")
            failure = body.get("error") or {"code": "executor_failed"}
            if isinstance(failure, Mapping):
                failure = dict(failure)
                if not isinstance(failure.get("code"), str) or not failure["code"].strip():
                    failure["code"] = "executor_failed"
            else:
                failure = {"code": "executor_failed", "message": str(failure)}
            recorded = None
            def record(value, *, event_ids=(), primary_stream_id=None, resulting_stream_seq=None):
                nonlocal recorded
                recorded = self._command_record("attempt.fail", attempt_id, idempotency_key, request_hash, self._task_resource(value), project_id=project_id or "unscoped", event_ids=event_ids, primary_stream_id=primary_stream_id, resulting_stream_seq=resulting_stream_seq)
            staged = None
            try:
                result = None
                if publishing:
                    staged = self._stage_outputs(attempt_id, body.get("outputs", []), project_id=project_id,
                        attempt_row=row, task_row=task, lease_body=body)
                    result = dict(body.get("result") or {})
                    result["outputs"] = staged["outputs"]
                    self._validate_terminal_manifest(staged, result, task, attempt_id, project_id)
                self.store.fail_task(row["task_id"], row["lease_id"], failure, fence=row["fence"], attempt_id=attempt_id,
                    record=record, result=result,
                    publish=(lambda: self._publish_staged_outputs(staged, project_id=project_id)) if staged is not None else None)
                if staged is not None:
                    staged["committed"] = True
                return recorded
            finally:
                if staged is not None:
                    self._discard_staged_outputs(staged)

    def events_page(self, aggregate_id=None, *, cursor=None, limit=50, from_=None):
        scope = f"events:{aggregate_id or '*'}"
        limit, decoded = _page_args(cursor, limit)
        if decoded is not None and decoded.get("s") != scope:
            raise InvalidRequestError("cursor does not belong to this collection")
        if from_ not in (None, "latest") or (from_ == "latest" and decoded is not None):
            raise InvalidRequestError("from must be latest and cannot be combined with cursor")
        where = " WHERE task_id = ? OR run_id = ?" if aggregate_id else ""
        filter_args = (aggregate_id, aggregate_id) if aggregate_id else ()
        if from_ == "latest":
            row = self.store.conn.execute(
                "SELECT id FROM events" + where + " ORDER BY id DESC LIMIT 1", filter_args
            ).fetchone()
            return {"items": [], "next_cursor": _page_cursor(scope, (str(row["id"] if row else 0),), numeric=True)}
        after = 0
        if decoded is not None:
            key = decoded["k"]
            if len(key) != 1 or not isinstance(key[0], str) or not key[0].isdecimal():
                raise InvalidRequestError("cursor is invalid")
            try:
                after = int(key[0])
            except ValueError as exc:
                raise InvalidRequestError("cursor is invalid") from exc
            if after > 2**63 - 1:
                raise InvalidRequestError("cursor is invalid")
        polling = decoded is not None and decoded.get("numeric") is True
        where = " WHERE id > ?" + (" AND (task_id = ? OR run_id = ?)" if aggregate_id else "")
        args = (after, *filter_args)
        if decoded is not None and not polling:
            # Old cursors used string keys; preserve their historical page bytes.
            where += " AND CAST(id AS TEXT) > ?"
            args += (key[0],)
        rows = self.store.conn.execute(
            "SELECT * FROM events" + where + " ORDER BY id LIMIT ?",
            (*args, limit + 1),
        ).fetchall()
        has_more = len(rows) > limit
        selected = rows[:limit]
        return {
            "items": [{"event_id": str(row["id"]), "sequence": int(row["id"]), "cursor": str(row["id"]), "event_type": row["kind"], "aggregate_type": "task" if row["task_id"] else "run", "aggregate_id": row["task_id"] or row["run_id"], "payload": json.loads(row["payload_json"]), "occurred_at": row["created_at"]} for row in selected],
            "next_cursor": _page_cursor(scope, (str(selected[-1]["id"]),), numeric=polling) if (has_more or (polling and selected)) else (cursor if polling else None),
        }
