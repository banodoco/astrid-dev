# A-6a fixture environment correction

The initial W smoke warmup returned `packages:missing=vibecomfy`; the isolated worker strips inherited `PYTHONPATH`. On 22 November 2026 the task interpreter's persistent site path was changed to match the prior A-4 source fixture, without installing or changing dependencies.

- File: `/root/codex/plan-81m/attribution-a3.env/venv/lib/python3.13/site-packages/vibecomfy-source.pth`
- Exact content: `/root/codex/plan-81m/VibeComfy` plus newline; SHA-256 `723f85cac0b554fe08fc9596ba8309c2acec33432d93661fe91d7b5ca2432d53`.
- Checkout: VibeComfy `799d90f619a6723d0b376b7e77aef09c244a0821`, verified clean before writing; checkout itself was not modified.
- Interpreter: `/root/codex/plan-81m/attribution-a3.env/venv/bin/python`, SHA-256 `3fff8e682225671f0ab9659e9a0f540f7c81491352004fc1397b16f57bed56ca`.
- Verification: `env -u PYTHONPATH <interpreter> -I -c 'import importlib.util; print(importlib.util.find_spec("vibecomfy").origin)'` returned `/root/codex/plan-81m/VibeComfy/vibecomfy/__init__.py` and an assertion checked that exact root.
- This changes import visibility only; it does not add package distribution metadata or establish a successful generation. The failed smoke remains under `run/a6a-smoke-w/`.
